﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Configuration;
using DRI_JODA_TDT.PROVIDERS;
using System.Web.Security;

using DRI_JODA_TDT.MODELS;

namespace DRI_JODA_TDT
{




    /// <summary>
    /// Summary description for LoginService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]

    public class LoginService : System.Web.Services.WebService
    {
        static DRIProvider dRIProvider = new DRIProvider();

        USER USER = new USER();




        public static OracleConnection con = new OracleConnection("Data Source=(DESCRIPTION="
                  + "(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=10.163.30.60)(PORT=1521)))"
                  + "(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=autdevtsbsl)));"
                  + "User Id=dril2;Password=dril22;");


        //static string con = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;

        // OracleConnection connection = new OracleConnection(con);




        [WebMethod(EnableSession = true)]

        public string LoginValidation(string USERID, string PASSWORD)
        {
           List<USER> objuser = new List<USER>();

            try
            {

                USER.USER_NAME = USERID;
                USER.PASSWORD = PASSWORD;
                objuser = dRIProvider.Validate_Login_Data(USER);



              if(objuser.Count>0)
                {

                    Session["user"] = USERID.ToString();
                    FormsAuthentication.SetAuthCookie(USERID, true);


                    return "True";
                }
                else
                {
                    return "False";
                }

            }
            catch (Exception ex)
            {
                return "Error";

            }



        }

    }





    //[WebMethod(EnableSession = true)]
    //public string LoginValidation(string USERID, string PASSWORD)
    //{

    //    string message = "";
    //    try
    //    {
    //        string sqlvalidateuser = "";
    //        OracleDataAdapter QMCPDA;


    //   USER.USER_NAME = USERID;
    //        USER.PASSWORD = PASSWORD;


    //       // message = dRIProvider.Validate_Login_Data(USER);

    //       // return message;


    //        DataTable QMCPDT = new DataTable();
    //        sqlvalidateuser = "select * from T_USR_INFORMATION where USER_NAME= '" + USERID + "' and PASSWORD='" + PASSWORD + "' ";

    //        if (con.State != ConnectionState.Open)
    //        { con.Open(); }

    //        QMCPDA = new OracleDataAdapter(sqlvalidateuser, con);
    //        QMCPDA.Fill(QMCPDT);

    //        if (QMCPDT.Rows.Count > 0)
    //        {
    //            Session["user"] = USERID.ToString();
    //            FormsAuthentication.SetAuthCookie(USERID, true);
    //            return "True";
    //        }
    //        else
    //        {

    //            return "False";
    //        }
    //    }

    //    catch (Exception ex)
    //    {





    //        return null;


    //    }


    //}
}

    

