﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using DRI_JODA_TDT.MODELS;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;

namespace DRI_JODA_TDT
{
    /// <summary>
    /// Summary description for FormModuleService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class FormModuleService : System.Web.Services.WebService
    {
        public static OracleConnection con = new OracleConnection("Data Source=(DESCRIPTION="
              + "(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=10.163.30.60)(PORT=1521)))"
              + "(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=autdevtsbsl)));"
              + "User Id=dril2;Password=dril22;");

        [WebMethod]
        public string HelloWorld()
        {

            return "Hello";
        }

        [WebMethod]
        public List<FORM_MODULE> GetFORMMODULEData()
        {
            IEnumerable<FORM_MODULE> resp_DataModule = null;
            IEnumerable<FormDetails> resp_DataForm = null;

           // i_dbBO = new DBBO();
            resp_DataModule = GetFORM_MODULE();//parentconfig

            resp_DataForm =   GetFORM_MODULEFORM();//child


            List<FORM_MODULE> FMlist = new List<FORM_MODULE>(); //Main parenent list output
            FORM_MODULE FMOBJCLASS = new FORM_MODULE();
            List<FormDetails> formdetaillist = new List<FormDetails>();
            // foreach (var itemmodue in resp_DataModule)
            var resp_DataModulelst = resp_DataModule.ToList();//IENUM TO LIST
            var resp_DataFormlst = resp_DataForm.ToList();
            for (int i = 0; i < resp_DataModulelst.Count(); i++)
            {
                FMOBJCLASS = new FORM_MODULE();

               


                FMOBJCLASS.MODULE_CODE = resp_DataModulelst[i].MODULE_CODE;
                FMOBJCLASS.MODULE_NAME = resp_DataModulelst[i].MODULE_NAME;
                FMOBJCLASS.MODULE_ICON = resp_DataModulelst[i].MODULE_ICON;
                FMOBJCLASS.MODULE_URL = resp_DataModulelst[i].MODULE_URL;
                FMOBJCLASS.MODULE_LEVEL = resp_DataModulelst[i].MODULE_LEVEL;




                FMlist.Add(FMOBJCLASS);

                formdetaillist = null; //before adding new index null child list
                formdetaillist = new List<FormDetails>();
                // foreach (var itemform in resp_DataForm)


                for (int j = 0; j < resp_DataFormlst.Count(); j++)
                {


                    FormDetails Frmdtl = new FormDetails  //child item add
                    {




                        FORM_URL = resp_DataFormlst[j].FORM_URL,
                        FORM_CODE = resp_DataFormlst[j].FORM_CODE,
                        FORM_ORDER = resp_DataFormlst[j].FORM_ORDER,
                        FORM_NAME = resp_DataFormlst[j].FORM_NAME,
                        FORM_ICON = resp_DataFormlst[j].FORM_ICON,
                        MODULE_CODE=resp_DataFormlst[j].MODULE_CODE,
                        FORM_LEVEL= resp_DataFormlst[j].FORM_LEVEL

                    };
                    if (resp_DataFormlst[j].MODULE_CODE == resp_DataModulelst[i].MODULE_CODE)
                    {
                        formdetaillist.Add(Frmdtl);//child list add

                        FMOBJCLASS.FormDetails = formdetaillist;


                    }




                    else
                    {





                    }


                }

            }


            //return JsonConvert.SerializeObject(FMlist);

            return FMlist;

        }


        private List<FORM_MODULE> GetFORM_MODULE()
        {
            OracleDataAdapter QMFeMTDA;
            DataTable QMFeMTDT = new DataTable();
            List<FORM_MODULE> finalFORM_MODULE = new List<FORM_MODULE>();
            try
            {



                string sqlcmd = "SELECT * from T_MODULE order by MODULE_LEVEL";

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }

                QMFeMTDA = new OracleDataAdapter(sqlcmd, con);
                DataTable ds = new DataTable();
                QMFeMTDA.Fill(ds);

                if (ds.Rows.Count > 0)
                {
                    foreach (DataRow Rows in ds.Rows)
                    {
                       FORM_MODULE obj = new FORM_MODULE();
                       // DateTime date = Rows["TIME_STAMP"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(Rows["TIME_STAMP"].ToString());
                        //obj.TIME_STAMP = date.ToString("dd MMM HH: mm");

                        obj.MODULE_CODE = Rows["MODULE_CODE"] == DBNull.Value ?"" : (Rows["MODULE_CODE"].ToString());
                        obj.MODULE_NAME = Rows["MODULE_NAME"] == DBNull.Value ? "" : (Rows["MODULE_NAME"].ToString());

                        obj.MODULE_URL = Rows["MODULE_URL"] == DBNull.Value ? "" : (Rows["MODULE_URL"].ToString());
                        obj.MODULE_ICON = Rows["MODULE_ICON"] == DBNull.Value ? "" : (Rows["MODULE_ICON"].ToString());
                        obj.MODULE_LEVEL = Rows["MODULE_LEVEL"] == DBNull.Value ? "" : (Rows["MODULE_LEVEL"].ToString());
                        finalFORM_MODULE.Add(obj);

                    }


                }

               

            }
           
            catch (Exception ex)
            {

            }

          return  finalFORM_MODULE;
        }


        private List<FormDetails> GetFORM_MODULEFORM()
        {
            OracleDataAdapter QMFeMTDA;
            DataTable QMFeMTDT = new DataTable();
            List<FormDetails> finalFORM_MODULEFORM = new List<FormDetails>();
            try
            {



                string sqlcmd = "SELECT * from T_FORM ORDER BY FORM_ORDER";

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }

                QMFeMTDA = new OracleDataAdapter(sqlcmd, con);
                DataTable ds = new DataTable();
                QMFeMTDA.Fill(ds);

                if (ds.Rows.Count > 0)
                {
                    foreach (DataRow Rows in ds.Rows)
                    {
                       FormDetails objform = new FormDetails();
                       

                        objform.FORM_CODE = Rows["FORM_CODE"] == DBNull.Value ? "" : (Rows["FORM_CODE"].ToString());
                        objform.FORM_ICON = Rows["FORM_ICON"] == DBNull.Value ? "" : (Rows["FORM_ICON"].ToString());

                        objform.FORM_ORDER = Rows["FORM_ORDER"] == DBNull.Value ? "" : (Rows["FORM_ORDER"].ToString());
                        objform.FORM_URL = Rows["FORM_URL"] == DBNull.Value ? "" : (Rows["FORM_URL"].ToString());
                        objform.MODULE_CODE = Rows["MODULE_CODE"] == DBNull.Value ? "" : (Rows["MODULE_CODE"].ToString());
                        objform.FORM_NAME = Rows["FORM_NAME"] == DBNull.Value ? "" : (Rows["FORM_NAME"].ToString());
                        objform.FORM_LEVEL = Rows["FORM_LEVEL"] == DBNull.Value ? "" : (Rows["FORM_LEVEL"].ToString());
                        finalFORM_MODULEFORM.Add(objform);

                    }


                }



            }

            catch (Exception ex)
            {

            }

            return finalFORM_MODULEFORM;
        }
    }
}
