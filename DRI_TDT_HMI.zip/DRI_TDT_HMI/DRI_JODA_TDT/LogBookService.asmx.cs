﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using DRI_JODA_TDT.MODELS;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Web.UI;
using DRI_JODA_TDT.PROVIDERS;

namespace DRI_JODA_TDT
{
    /// <summary>
    /// Summary description for LogBookService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class LogBookService : System.Web.Services.WebService
    {
        static DRIProvider dRIProvider = new DRIProvider();
        public static OracleConnection con = new OracleConnection("Data Source=(DESCRIPTION="
             + "(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=10.163.30.60)(PORT=1521)))"
             + "(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=autdevtsbsl)));"
             + "User Id=dril2;Password=dril22;");
        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }




        [WebMethod]
        public List<ParamConfig> GetLossEQuipment(string selectedValueLoc)
        {


            OracleDataAdapter QMFeMTDA;
            DataTable QMFeMTDT = new DataTable();
            List<ParamConfig> lstdatagroup = new List<ParamConfig>();
            try
            {




                string sqlcmd = "Select * from T_EQUIP_CONFIG WHERE LOCATION_ID='"+ selectedValueLoc + "' order by PARAM_NAME";
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }



                QMFeMTDA = new OracleDataAdapter(sqlcmd, con);
                DataTable ds = new DataTable();
                QMFeMTDA.Fill(ds);

                if (ds.Rows.Count > 0)
                {
                    foreach (DataRow Rows in ds.Rows)
                    {
                        ParamConfig objlogbook = new ParamConfig();


                        objlogbook.PARAM_ID   = Rows["PARAM_ID"] == DBNull.Value ? "" : (Rows["PARAM_ID"].ToString());
                        objlogbook.PARAM_NAME = Rows["PARAM_NAME"] == DBNull.Value ? "" : (Rows["PARAM_NAME"].ToString());
                        objlogbook.PARAM_DESC = Rows["PARAM_DESC"] == DBNull.Value ? "" : (Rows["PARAM_DESC"].ToString());

                        lstdatagroup.Add(objlogbook);

                    }


                }



            }

            catch (Exception ex)
            {

            }

            return lstdatagroup;


        }
        [WebMethod]
        public string SubmitFeedBook(string KILN, string FromDate, string ToDate, string Duration, string EQUIPMENT, string DEPARTMENT, string REASON, string TYPE)
        {
            string result = null;

            OracleDataAdapter QMFeMTDA;
            DataTable QMFeMTDT = new DataTable();
            try
            {
                LossBook lossBook = new LossBook();

                DateTime frmdate = Convert.ToDateTime(FromDate);
                DateTime todate = Convert.ToDateTime(ToDate);
                lossBook.FROM_DATE = frmdate;
                lossBook.TO_DATE = todate;
                lossBook.DURATION = Duration;
                lossBook.EQUIPMENT = EQUIPMENT;
                lossBook.DEPARTMENT = DEPARTMENT;
                lossBook.REASON = REASON;
                lossBook.TYPE = TYPE;

                int rowsUpdated = 0;

                OracleParameter[] oracleParameters = null;



                string v_Query = string.Empty;



                oracleParameters = new OracleParameter[8];

                oracleParameters[0] = new OracleParameter(@"ID_KILN", KILN);
                oracleParameters[1] = new OracleParameter(@"FROM_DATE", frmdate);
                oracleParameters[2] = new OracleParameter(@"TO_DATE", todate);
                oracleParameters[3] = new OracleParameter(@"DURATION", Duration);
                oracleParameters[4] = new OracleParameter(@"EQUIPMENT", EQUIPMENT);
                oracleParameters[5] = new OracleParameter(@"DEPARTMENT", DEPARTMENT);
                oracleParameters[6] = new OracleParameter(@"DELAY_REASON", REASON);
                oracleParameters[7] = new OracleParameter(@"TYPE", TYPE);

                string sqlcmd = "Select * from T_FEED_LOG_BOOK WHERE ID_KILN = '" + KILN + "' AND FROM_DATE = TO_DATE('" + frmdate + "', 'MM/DD/YYYY HH:MI:SS AM') " +
                    "AND TO_DATE = TO_DATE('" + todate + "', 'MM/DD/YYYY HH:MI:SS AM') and TYPE='" + TYPE + "'";

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }



                QMFeMTDA = new OracleDataAdapter(sqlcmd, con);
                DataTable ds = new DataTable();
                QMFeMTDA.Fill(ds);

                if (ds.Rows.Count == 0)
                {

                    v_Query = @"INSERT INTO T_FEED_LOG_BOOK (ID_KILN, FROM_DATE, TO_DATE, DURATION,EQUIPMENT,DEPARTMENT,DELAY_REASON,TYPE) VALUES (:ID_KILN,:FROM_DATE,:TO_DATE,:DURATION,:EQUIPMENT,:DEPARTMENT,:DELAY_REASON,:TYPE)";
                }
                else
                {
                    oracleParameters = new OracleParameter[8];


                    oracleParameters[0] = new OracleParameter(@"DURATION", Duration);
                    oracleParameters[1] = new OracleParameter(@"EQUIPMENT", EQUIPMENT);
                    oracleParameters[2] = new OracleParameter(@"DEPARTMENT", DEPARTMENT);
                    oracleParameters[3] = new OracleParameter(@"DELAY_REASON", REASON);

                    oracleParameters[4] = new OracleParameter(@"ID_KILN", KILN);
                    oracleParameters[5] = new OracleParameter(@"FROM_DATE", frmdate);
                    oracleParameters[6] = new OracleParameter(@"TO_DATE", todate);
                    oracleParameters[7] = new OracleParameter(@"TYPE", TYPE);
                    v_Query = @"UPDATE T_FEED_LOG_BOOK SET DURATION=:DURATION,EQUIPMENT=:EQUIPMENT, DEPARTMENT=:DEPARTMENT, DELAY_REASON=:DELAY_REASON WHERE ID_KILN=:ID_KILN and FROM_DATE=:FROM_DATE and TO_DATE=:TO_DATE and TYPE=:TYPE";

                }





                rowsUpdated = Execute_Non_Query_DB(v_Query, oracleParameters);

                if (rowsUpdated > 0)
                    result = "Updated Successfully!";
                else
                    result = "Failed";
                return result;
            }
            catch (Exception ex)
            {
                return result;
            }


        }
        private int Execute_Non_Query_DB(string sqlCommand, OracleParameter[] dbParams)
        {
            int rowsUpdated = 0;
            List<string> result_message = new List<string>();
            try
            {
                con.Close();
                // DBConnect();
                con.Open();
                if (con == null)
                    // DBConnect();
                    con.Open();
                using (OracleCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = sqlCommand;
                    cmd.CommandType = CommandType.Text;
                    if (dbParams != null)
                        cmd.Parameters.AddRange(dbParams);
                    rowsUpdated = cmd.ExecuteNonQuery();
                }
            }
            catch (OracleException ex)
            {
                result_message.Add(ex.Message);
            }
            catch (Exception ex)
            {
                result_message.Add(ex.Message);
            }
            finally
            {
                con.Close();
                // DBClose();
            }
            return rowsUpdated;
        }

        [WebMethod]
        public LogBook[] GetLConfigurationTableData(string KILN, string Date)
        {

            DataTable dt = new DataTable();
            DateTime d = Convert.ToDateTime(Date);
            string fromDate1 = d.ToString("d") + " " + "06:00:00:AM";

            string toDate1 = d.AddDays(1).ToString("d") + " " + "05:59:59:AM";

            string fromDate = d.ToString("MM/dd/yyyy") + " " + "06:00:00 AM";

            string toDate = d.AddDays(1).ToString("MM/dd/yyyy") + " " + "05:59:59 AM";

            List<LogBook> lstDataSource = new List<LogBook>(); //datasource    Parent

            List<LogBookGroup> lstDataGroup = new List<LogBookGroup>(); //datagroup  child1

            List<LogBookName> lstDataName = new List<LogBookName>(); //dataname  child2


            LogBook logBook = new LogBook(); // parent class
            lstDataSource = GetData_Source(KILN, Date);//parent

            lstDataGroup = GetData_Group(KILN, Date);// child1
            lstDataName = GetData_Name_Configuration(KILN, fromDate, toDate);// child2






            LogBookGroup[] lstgroup = lstDataGroup.Select(x => new LogBookGroup //child

            {

                DATA_SOURCE = x.DATA_SOURCE,
                DATA_GROUP = x.DATA_GROUP,

                lstDataName = lstDataName == null || lstDataName.Count == 0 ? new List<LogBookName>() :

                lstDataName.Where(a => a.DATA_GROUP == x.DATA_GROUP && a.DATA_SOURCE == x.DATA_SOURCE).Count() == 0 ? new List<LogBookName>() :

                lstDataName.Where(a => a.DATA_GROUP == x.DATA_GROUP && a.DATA_SOURCE == x.DATA_SOURCE).Select(y => new LogBookName

                {



                    DATA_NAME = y.DATA_NAME,
                    DATA_SOURCE = y.DATA_SOURCE,
                    DATA_GROUP = y.DATA_GROUP,

                    MIN_VALUE = y.MIN_VALUE,
                    MAX_VALUE = y.MAX_VALUE



                }).ToList()

            }).ToArray();





            LogBook[] lstsource = lstDataSource.Select(x => new LogBook  // parent

            {

                DATA_SOURCE = x.DATA_SOURCE,
                //  DATA_GROUP = x.DATA_GROUP,

                lstDataGroup = lstgroup == null || lstgroup.Length == 0 ? new List<LogBookGroup>() :

                lstgroup.Where(a => a.DATA_SOURCE == x.DATA_SOURCE).Count() == 0 ? new List<LogBookGroup>() :

                lstgroup.Where(a => a.DATA_SOURCE == x.DATA_SOURCE).Select(y => new LogBookGroup

                {

                    DATA_SOURCE = y.DATA_SOURCE,
                    DATA_GROUP = y.DATA_GROUP,
                    lstDataName = y.lstDataName,




                }).ToList()

            }).ToArray();









            return lstsource;

        }






        [WebMethod]
        public LogBook[] GetLMonitoringTableData(string KILN, string Date)
        {
            //string Date = "";
            DataTable dt = new DataTable();
            DateTime d = Convert.ToDateTime(Date);
            string fromDate1 = d.ToString("d") + " " + "06:00:00:AM";

            string toDate1 = d.AddDays(1).ToString("d") + " " + "05:59:59:AM";

            string fromDate = d.ToString("MM/dd/yyyy") + " " + "06:00:00 AM";

            string toDate = d.AddDays(1).ToString("MM/dd/yyyy") + " " + "05:59:59 AM";

            List<LogBook> lstDataSource = new List<LogBook>(); //datasource    Parent

            List<LogBookGroup> lstDataGroup = new List<LogBookGroup>(); //datagroup  child1

            List<LogBookName> lstDataName = new List<LogBookName>(); //dataname  child2


            LogBook logBook = new LogBook(); // parent class
            lstDataSource = GetData_Source(KILN, Date);//parent

            lstDataGroup = GetData_Group(KILN, Date);// child1
            lstDataName = GetData_Name_Monitoring(KILN, fromDate, toDate);// child2






            LogBookGroup[] lstgroup = lstDataGroup.Select(x => new LogBookGroup //child

            {

                DATA_SOURCE = x.DATA_SOURCE,
                DATA_GROUP = x.DATA_GROUP,

                lstDataName = lstDataName == null || lstDataName.Count == 0 ? new List<LogBookName>() :

                lstDataName.Where(a => a.DATA_GROUP == x.DATA_GROUP && a.DATA_SOURCE == x.DATA_SOURCE).Count() == 0 ? new List<LogBookName>() :

                lstDataName.Where(a => a.DATA_GROUP == x.DATA_GROUP && a.DATA_SOURCE == x.DATA_SOURCE).Select(y => new LogBookName

                {



                    DATA_NAME = y.DATA_NAME,
                    DATA_SOURCE = y.DATA_SOURCE,
                    DATA_GROUP = y.DATA_GROUP,
                    MIN_VALUE = y.MIN_VALUE,
                    MAX_VALUE = y.MAX_VALUE,
                    //entry1.SHIFTB == "0" ? "-" : entry1.SHIFTB,
                    TAG_VALUE = y.TAG_VALUE==""?"0" :y.TAG_VALUE,
                    DATA_TIME = y.DATA_TIME
                    //SHIFT_A = y.SHIFT_A,
                    //SHIFT_B = y.SHIFT_B,
                    //SHIFT_C = y.SHIFT_C,
                    //ON_DATE = y.ON_DATE,
                    //TO_DATE = y.TO_DATE


                })
                
                .ToList()

            }).ToArray();





            LogBook[] lstsource = lstDataSource.Select(x => new LogBook  // parent

            {

                DATA_SOURCE = x.DATA_SOURCE,
                //  DATA_GROUP = x.DATA_GROUP,

                lstDataGroup = lstgroup == null || lstgroup.Length == 0 ? new List<LogBookGroup>() :

                lstgroup.Where(a => a.DATA_SOURCE == x.DATA_SOURCE).Count() == 0 ? new List<LogBookGroup>() :

                lstgroup.Where(a => a.DATA_SOURCE == x.DATA_SOURCE).Select(y => new LogBookGroup

                {

                    DATA_SOURCE = y.DATA_SOURCE,
                    DATA_GROUP = y.DATA_GROUP,
                    lstDataName = y.lstDataName,




                }).ToList()

            }).ToArray();









            return lstsource;





        }





        [WebMethod]
        public LogBook[] GetLogbookTableData(string KILN, string Date)
        {


            







            DataTable dt = new DataTable();
            DateTime d = Convert.ToDateTime(Date);
            string fromDate1 = d.ToString("d") + " " + "06:00:00:AM";

            string toDate1 = d.AddDays(1).ToString("d") + " " + "05:59:59:AM";

            string fromDate = d.ToString("MM/dd/yyyy") + " " + "06:00:00 AM";

            string toDate = d.AddDays(1).ToString("MM/dd/yyyy") + " " + "05:59:59 AM";

            List<LogBook> lstDataSource = new List<LogBook>(); //datasource    Parent

            List<LogBookGroup> lstDataGroup = new List<LogBookGroup>(); //datagroup  child1

            List<LogBookName> lstDataName = new List<LogBookName>(); //dataname  child2


            LogBook logBook = new LogBook(); // parent class
            lstDataSource = GetData_Source(KILN, Date);//parent

            lstDataGroup = GetData_Group(KILN, Date);// child1
            lstDataName = GetData_Name(KILN, fromDate, toDate);// child2






            LogBookGroup[] lstgroup = lstDataGroup.Select(x => new LogBookGroup //child

            {

                DATA_SOURCE = x.DATA_SOURCE,
                DATA_GROUP = x.DATA_GROUP,

                lstDataName = lstDataName == null || lstDataName.Count == 0 ? new List<LogBookName>() :

                lstDataName.Where(a => a.DATA_GROUP == x.DATA_GROUP && a.DATA_SOURCE == x.DATA_SOURCE).Count() == 0 ? new List<LogBookName>() :

                lstDataName.Where(a => a.DATA_GROUP == x.DATA_GROUP && a.DATA_SOURCE == x.DATA_SOURCE).Select(y => new LogBookName

                {



                    DATA_NAME = y.DATA_NAME,
                    DATA_SOURCE = y.DATA_SOURCE,
                    DATA_GROUP = y.DATA_GROUP,

                    SHIFT_A = y.SHIFT_A,
                    SHIFT_B = y.SHIFT_B,
                    SHIFT_C = y.SHIFT_C,
                    ON_DATE = y.ON_DATE,
                    TO_DATE = y.TO_DATE


                }).ToList()

            }).ToArray();





            LogBook[] lstsource = lstDataSource.Select(x => new LogBook  // parent

            {

                DATA_SOURCE = x.DATA_SOURCE,


                lstDataGroup = lstgroup == null || lstgroup.Length == 0 ? new List<LogBookGroup>() :

                lstgroup.Where(a => a.DATA_SOURCE == x.DATA_SOURCE).Count() == 0 ? new List<LogBookGroup>() :

                lstgroup.Where(a => a.DATA_SOURCE == x.DATA_SOURCE).Select(y => new LogBookGroup

                {

                    DATA_SOURCE = y.DATA_SOURCE,
                    DATA_GROUP = y.DATA_GROUP,
                    lstDataName = y.lstDataName,




                }).ToList()

            }).ToArray();









            return lstsource;





















        }
        [WebMethod]
        public LogBook[] GetQualityTableData(string KILN, string Date)
        {





            DateTime d = Convert.ToDateTime(Date);
            string fromDate1 = d.ToString("d") + " " + "06:00:00:AM";

            string toDate1 = d.AddDays(1).ToString("d") + " " + "05:59:59:AM";

            string fromDate = d.ToString("MM/dd/yyyy") + " " + "06:00:00 AM";

            string toDate = d.AddDays(1).ToString("MM/dd/yyyy") + " " + "05:59:59 AM";















            List<LogBook> lstDatatableMaterial = new List<LogBook>(); //datasource    Parent

            List<LogBookGroup> lstDataDescMaterial = new List<LogBookGroup>(); //datagroup  child



            LogBook logBook1 = new LogBook(); // parent class
            lstDatatableMaterial = GetData_Material(KILN, Date);//parent

            lstDataDescMaterial = GetData_Material_Desc(KILN, fromDate,toDate);// child


            LogBook[] logBookarray = (from logbook in lstDatatableMaterial
                                  join datagroup in lstDataDescMaterial on logbook.TABLE_NAME equals datagroup.TABLE_NAME into logbooksAndGroups
                                  select new LogBook
                                  {
                                      TABLE_NAME = logbook.TABLE_NAME,
                                      lstDataGroup = logbooksAndGroups.Select(lg => new LogBookGroup
                                      {
                                          DESC_LAB_DATA = lg.DESC_LAB_DATA,
                                          SHIFTA=lg.SHIFTA,
                                          SHIFTB=lg.SHIFTB,
                                          SHIFTC=lg.SHIFTC,
                                          ON_DATE=lg.ON_DATE,
                                         TO_DATE=lg.TO_DATE
                                      }).ToList()
                                  }).ToArray();




            

            


            







            return logBookarray;


}


















        
        [WebMethod]
        public LogBook[] GetMMLogbookTableData(string KILN, string Date)
        {


            DataTable dt = new DataTable();
            DateTime d = Convert.ToDateTime(Date);
            string fromDate1 = d.ToString("d") + " " + "06:00:00:AM";

            string toDate1 = d.AddDays(1).ToString("d") + " " + "05:59:59:AM";

            string fromDate = d.ToString("MM/dd/yyyy") + " " + "06:00:00 AM";

            string toDate = d.AddDays(1).ToString("MM/dd/yyyy") + " " + "05:59:59 AM";

            List<LogBook> lstDataSource = new List<LogBook>(); //datasource    Parent

            List<LogBookGroup> lstDataGroup = new List<LogBookGroup>(); //datagroup  child1

            List<LogBookName> lstDataName = new List<LogBookName>(); //dataname  child2


            LogBook logBook = new LogBook(); // parent class
            lstDataSource = GetData_Source(KILN, Date);//parent

            lstDataGroup = GetData_Group(KILN, Date);// child1
            lstDataName = GetData_Name(KILN, fromDate, toDate);// child2






            LogBookGroup[] lstgroup = lstDataGroup.Select(x => new LogBookGroup //child

            {

                DATA_SOURCE = x.DATA_SOURCE,
                DATA_GROUP = x.DATA_GROUP,

                lstDataName = lstDataName == null || lstDataName.Count == 0 ? new List<LogBookName>() :

                lstDataName.Where(a => a.DATA_GROUP == x.DATA_GROUP && a.DATA_SOURCE == x.DATA_SOURCE).Count() == 0 ? new List<LogBookName>() :

                lstDataName.Where(a => a.DATA_GROUP == x.DATA_GROUP && a.DATA_SOURCE == x.DATA_SOURCE).Select(y => new LogBookName

                {



                    DATA_NAME = y.DATA_NAME,
                    DATA_SOURCE = y.DATA_SOURCE,
                    DATA_GROUP = y.DATA_GROUP,

                    SHIFT_A = y.SHIFT_A,
                    SHIFT_B = y.SHIFT_B,
                    SHIFT_C = y.SHIFT_C,
                    ON_DATE = y.ON_DATE,
                    TO_DATE = y.TO_DATE


                }).ToList()

            }).ToArray();





            LogBook[] lstsource = lstDataSource.Select(x => new LogBook  // parent

            {

                DATA_SOURCE = x.DATA_SOURCE,


                lstDataGroup = lstgroup == null || lstgroup.Length == 0 ? new List<LogBookGroup>() :

                lstgroup.Where(a => a.DATA_SOURCE == x.DATA_SOURCE).Count() == 0 ? new List<LogBookGroup>() :

                lstgroup.Where(a => a.DATA_SOURCE == x.DATA_SOURCE).Select(y => new LogBookGroup

                {

                    DATA_SOURCE = y.DATA_SOURCE,
                    DATA_GROUP = y.DATA_GROUP,
                    lstDataName = y.lstDataName,




                }).ToList()

            }).ToArray();









            return lstsource;





















        }


        [WebMethod]
        public LogBook[] GetLogbookIEMTableData(string KILN, string Date)
        {


            DataTable dt = new DataTable();
            DateTime d = Convert.ToDateTime(Date);
            string fromDate1 = d.ToString("d") + " " + "06:00:00:AM";

            string toDate1 = d.AddDays(1).ToString("d") + " " + "05:59:59:AM";

            string fromDate = d.ToString("MM/dd/yyyy") + " " + "06:00:00 AM";

            string toDate = d.AddDays(1).ToString("MM/dd/yyyy") + " " + "05:59:59 AM";

            List<LogBook> lstDataSource = new List<LogBook>(); //datasource    Parent

            List<LogBookGroup> lstDataGroup = new List<LogBookGroup>(); //datagroup  child1

            List<LogBookName> lstDataName = new List<LogBookName>(); //dataname  child2


            LogBook logBook = new LogBook(); // parent class
            lstDataSource = GetData_Source(KILN, Date);//parent

            lstDataGroup = GetData_Group(KILN, Date);// child1
            lstDataName = GetData_Name(KILN, fromDate, toDate);// child2






            LogBookGroup[] lstgroup = lstDataGroup.Select(x => new LogBookGroup //child

            {

                DATA_SOURCE = x.DATA_SOURCE,
                DATA_GROUP = x.DATA_GROUP,

                lstDataName = lstDataName == null || lstDataName.Count == 0 ? new List<LogBookName>() :

                lstDataName.Where(a => a.DATA_GROUP == x.DATA_GROUP && a.DATA_SOURCE == x.DATA_SOURCE).Count() == 0 ? new List<LogBookName>() :

                lstDataName.Where(a => a.DATA_GROUP == x.DATA_GROUP && a.DATA_SOURCE == x.DATA_SOURCE).Select(y => new LogBookName

                {



                    DATA_NAME = y.DATA_NAME,
                    DATA_SOURCE = y.DATA_SOURCE,
                    DATA_GROUP = y.DATA_GROUP,

                    SHIFT_A = y.SHIFT_A,
                    SHIFT_B = y.SHIFT_B,
                    SHIFT_C = y.SHIFT_C,
                    ON_DATE = y.ON_DATE,
                    TO_DATE = y.TO_DATE


                }).ToList()

            }).ToArray();





            LogBook[] lstsource = lstDataSource.Select(x => new LogBook  // parent

            {

                DATA_SOURCE = x.DATA_SOURCE,


                lstDataGroup = lstgroup == null || lstgroup.Length == 0 ? new List<LogBookGroup>() :

                lstgroup.Where(a => a.DATA_SOURCE == x.DATA_SOURCE).Count() == 0 ? new List<LogBookGroup>() :

                lstgroup.Where(a => a.DATA_SOURCE == x.DATA_SOURCE).Select(y => new LogBookGroup

                {

                    DATA_SOURCE = y.DATA_SOURCE,
                    DATA_GROUP = y.DATA_GROUP,
                    lstDataName = y.lstDataName,




                }).ToList()

            }).ToArray();









            return lstsource;





















        }




        private List<LogBook> GetData_Source(string KILN, string Date)
        {



            OracleDataAdapter QMFeMTDA;
            DataTable QMFeMTDT = new DataTable();
            List<LogBook> lstdatagroup = new List<LogBook>();
            try
            {




                string sqlcmd = "select distinct data_source from t_dri_data_config where id_kiln=" + KILN + "  order by data_source";
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }



                QMFeMTDA = new OracleDataAdapter(sqlcmd, con);
                DataTable ds = new DataTable();
                QMFeMTDA.Fill(ds);

                if (ds.Rows.Count > 0)
                {
                    foreach (DataRow Rows in ds.Rows)
                    {
                        LogBook objlogbook = new LogBook();


                        objlogbook.DATA_SOURCE = Rows["DATA_SOURCE"] == DBNull.Value ? "" : (Rows["DATA_SOURCE"].ToString());

                        lstdatagroup.Add(objlogbook);

                    }


                }



            }

            catch (Exception ex)
            {

            }

            return lstdatagroup;


        }
        private List<LogBookGroup> GetData_Group(string KILN, string Date)
        {



            OracleDataAdapter QMFeMTDA;
            DataTable QMFeMTDT = new DataTable();
            List<LogBookGroup> lstdatagroup = new List<LogBookGroup>();
            try
            {




                string sqlcmd = "select distinct data_source,data_group from t_dri_data_config where id_kiln=" + KILN + "";

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }



                QMFeMTDA = new OracleDataAdapter(sqlcmd, con);
                DataTable ds = new DataTable();
                QMFeMTDA.Fill(ds);

                if (ds.Rows.Count > 0)
                {
                    foreach (DataRow Rows in ds.Rows)
                    {
                        LogBookGroup objlogbook = new LogBookGroup();


                        objlogbook.DATA_SOURCE = Rows["DATA_SOURCE"] == DBNull.Value ? "" : (Rows["DATA_SOURCE"].ToString());
                        objlogbook.DATA_GROUP = Rows["DATA_GROUP"] == DBNull.Value ? "" : (Rows["DATA_GROUP"].ToString());
                        //  objlogbook.
                        lstdatagroup.Add(objlogbook);

                    }


                }



            }

            catch (Exception ex)
            {

            }

            return lstdatagroup;


        }
        private List<LogBookName> GetData_Name(string KILN, string fromDate, string toDate)
        {

            OracleDataAdapter QMFeMTDA;
            OracleDataAdapter frmmonthQMFeMTDA;
            DataTable QMFeMTDT = new DataTable();
            List<LogBookName> lstdataname = new List<LogBookName>();
            List<LogBookName> lstdatanametodate = new List<LogBookName>();
            List<LogBookName> Mrglstdataname = new List<LogBookName>();
            try
            {


                DateTime dtDate;
                DateTime dateTime1;
                DateTime dateTime2;



                if (DateTime.TryParse(fromDate, out dtDate))
                {
                    dtDate = dtDate.AddDays(-(dtDate.Day - 1)).Date;
                    Console.WriteLine("First Day of Month: " + dtDate.ToString("MM/dd/yyyy"));
                }
                else
                {
                    Console.WriteLine("Invalid date format.");
                }
                string frmmonthdate = dtDate.ToString("MM/dd/yyyy") + " " + "6:00:00 :AM";

                if (DateTime.TryParse(fromDate, out dateTime1))
                {
                    dateTime1 = dateTime1.Date;

                }

                if (DateTime.TryParse(toDate, out dateTime2))
                {
                    dateTime2 = dateTime2.Date;

                }
                string fromdate = dateTime1.ToString("d") + " " + "6:00:00 :AM";
                string todate = dateTime2.ToString("d") + " " + "5:59:59 :AM";



                string sqlcmd = @" SELECT B.DATA_SOURCE, B.DATA_GROUP, B.DATA_NAME, A.ID_PLC_DATA_SEQ,
        Round(AVG(CASE WHEN A.SHIFT LIKE 'A' THEN A.AVGVALUE ELSE NULL END),2) AS SHIFTA,
       Round(AVG(CASE WHEN A.SHIFT LIKE 'B' THEN A.AVGVALUE ELSE NULL END),2) AS SHIFTB,
       Round(AVG(CASE WHEN A.SHIFT LIKE 'C' THEN A.AVGVALUE ELSE NULL END),2) AS SHIFTC,
       Round(
       (AVG(CASE WHEN A.SHIFT LIKE 'A' THEN A.AVGVALUE ELSE 0 END) +
              AVG(CASE WHEN A.SHIFT LIKE 'B' THEN A.AVGVALUE ELSE 0 END) +
              AVG(CASE WHEN A.SHIFT LIKE 'C' THEN A.AVGVALUE ELSE 0 END)
              )
              ,2)AS ON_DATE
             FROM T_DRI_SHIFT_WISE_DATA A RIGHT JOIN T_DRI_DATA_CONFIG B ON B.ID_PLC_DATA_SEQ = A.ID_PLC_DATA_Seq
             WHERE A.ID_KILN = '" + KILN + "'  and A.DATA_TIME >= TO_DATE('" + fromDate + "', 'MM/dd/yyyy HH:MI:SS :AM') and A.DATA_TIME  <= TO_DATE('" + toDate + "', 'MM/dd/yyyy HH:MI:SS :AM') OR A.ID_PLC_DATA_SEQ IS NULL GROUP BY B.DATA_SOURCE, B.DATA_GROUP, B.DATA_NAME, A.ID_PLC_DATA_SEQ, A.ID_KILN ORDER BY B.DATA_SOURCE, B.DATA_GROUP, B.DATA_NAME ASC";









                string frmmonth = @" SELECT B.DATA_SOURCE, B.DATA_GROUP, B.DATA_NAME, A.ID_PLC_DATA_SEQ,
        Round(AVG(CASE WHEN A.SHIFT LIKE 'A' THEN A.AVGVALUE ELSE NULL END),2) AS SHIFTA,
       Round(AVG(CASE WHEN A.SHIFT LIKE 'B' THEN A.AVGVALUE ELSE NULL END),2) AS SHIFTB,
       Round(AVG(CASE WHEN A.SHIFT LIKE 'C' THEN A.AVGVALUE ELSE NULL END),2) AS SHIFTC,
       Round(
       (AVG(CASE WHEN A.SHIFT LIKE 'A' THEN A.AVGVALUE ELSE 0 END) +
              AVG(CASE WHEN A.SHIFT LIKE 'B' THEN A.AVGVALUE ELSE 0 END) +
              AVG(CASE WHEN A.SHIFT LIKE 'C' THEN A.AVGVALUE ELSE 0 END)
              )
              ,2)AS TO_DATE
                  FROM T_DRI_SHIFT_WISE_DATA A RIGHT JOIN T_DRI_DATA_CONFIG B ON B.ID_PLC_DATA_SEQ = A.ID_PLC_DATA_Seq
                    WHERE A.ID_KILN = '" + KILN + "' and A.DATA_TIME >= TO_DATE('" + frmmonthdate + "', 'MM/dd/yyyy HH:MI:SS :AM') and A.DATA_TIME  <= TO_DATE('" + toDate + "', 'MM/dd/yyyy HH:MI:SS :AM') OR A.ID_PLC_DATA_SEQ IS NULL GROUP BY B.DATA_SOURCE, B.DATA_GROUP, B.DATA_NAME, A.ID_PLC_DATA_SEQ, A.ID_KILN ORDER BY B.DATA_SOURCE, B.DATA_GROUP, B.DATA_NAME ASC";


                QMFeMTDA = new OracleDataAdapter(sqlcmd, con);
                frmmonthQMFeMTDA = new OracleDataAdapter(frmmonth, con);
                DataTable ds = new DataTable();
                DataTable ds1 = new DataTable();
                QMFeMTDA.Fill(ds);
                frmmonthQMFeMTDA.Fill(ds1);
                if (ds.Rows.Count > 0)
                {
                    foreach (DataRow Rows in ds.Rows)
                    {
                        LogBookName objlogbook = new LogBookName();


                        objlogbook.DATA_SOURCE = Rows["DATA_SOURCE"] == DBNull.Value ? "" : (Rows["DATA_SOURCE"].ToString());
                        objlogbook.DATA_GROUP = Rows["DATA_GROUP"] == DBNull.Value ? "" : (Rows["DATA_GROUP"].ToString());
                        objlogbook.DATA_NAME = Rows["DATA_NAME"] == DBNull.Value ? "" : (Rows["DATA_NAME"].ToString());
                        objlogbook.SHIFT_A = Rows["SHIFTA"] == DBNull.Value ? "" : (Rows["SHIFTA"].ToString());
                        objlogbook.SHIFT_B = Rows["SHIFTB"] == DBNull.Value ? "" : (Rows["SHIFTB"].ToString());
                        objlogbook.SHIFT_C = Rows["SHIFTC"] == DBNull.Value ? "" : (Rows["SHIFTC"].ToString());
                        //objlogbook.AVGVALUE = Rows["AVGVALUE"] == DBNull.Value ? "" : (Rows["AVGVALUE"].ToString());
                        objlogbook.ON_DATE = Rows["ON_DATE"] == DBNull.Value ? "" : (Rows["ON_DATE"].ToString());
                        objlogbook.ID_PLC_DATA_SEQ = Rows["ID_PLC_DATA_SEQ"] == DBNull.Value ? "" : (Rows["ID_PLC_DATA_SEQ"].ToString());

                        lstdataname.Add(objlogbook);

                    }


                }

                if (ds1.Rows.Count > 0)
                {
                    foreach (DataRow Rows in ds1.Rows)
                    {
                        LogBookName objlogbooktodate = new LogBookName();


                        objlogbooktodate.DATA_SOURCE = Rows["DATA_SOURCE"] == DBNull.Value ? "" : (Rows["DATA_SOURCE"].ToString());
                        objlogbooktodate.DATA_GROUP = Rows["DATA_GROUP"] == DBNull.Value ? "" : (Rows["DATA_GROUP"].ToString());
                        objlogbooktodate.DATA_NAME = Rows["DATA_NAME"] == DBNull.Value ? "" : (Rows["DATA_NAME"].ToString());
                        objlogbooktodate.SHIFT_A = Rows["SHIFTA"] == DBNull.Value ? "" : (Rows["SHIFTA"].ToString());
                        objlogbooktodate.SHIFT_B = Rows["SHIFTB"] == DBNull.Value ? "" : (Rows["SHIFTB"].ToString());
                        objlogbooktodate.SHIFT_C = Rows["SHIFTC"] == DBNull.Value ? "" : (Rows["SHIFTC"].ToString());
                        //objlogbook.AVGVALUE = Rows["AVGVALUE"] == DBNull.Value ? "" : (Rows["AVGVALUE"].ToString());
                        objlogbooktodate.TO_DATE = Rows["TO_DATE"] == DBNull.Value ? "" : (Rows["TO_DATE"].ToString());
                        objlogbooktodate.ID_PLC_DATA_SEQ = Rows["ID_PLC_DATA_SEQ"] == DBNull.Value ? "" : (Rows["ID_PLC_DATA_SEQ"].ToString());

                        lstdatanametodate.Add(objlogbooktodate);

                    }


                }








            }

            catch (Exception ex)
            {

            }


            List<LogBookName> logBookNames = lstdataname
                .GroupBy(x => new { x.DATA_SOURCE, x.DATA_GROUP, x.DATA_NAME })
                .Select(g => g.First())
                .ToList();

            List<LogBookName> logBookNamestodate = lstdatanametodate
               .GroupBy(x => new { x.DATA_SOURCE, x.DATA_GROUP, x.DATA_NAME })
               .Select(g => g.First())
               .ToList();
            List<LogBookName> result = (from entry1 in logBookNames
                                        join entry2 in logBookNamestodate
                                        on new { entry1.ID_PLC_DATA_SEQ } equals new { entry2.ID_PLC_DATA_SEQ }
                                        select new LogBookName
                                        {
                                            DATA_SOURCE = entry1.DATA_SOURCE,
                                            DATA_GROUP = entry1.DATA_GROUP,
                                            DATA_NAME = entry1.DATA_NAME,
                                            SHIFT_A = entry1.SHIFT_A,
                                            SHIFT_B = entry1.SHIFT_B,
                                            SHIFT_C = entry1.SHIFT_C,
                                            ON_DATE = entry1.ON_DATE,
                                            TO_DATE = entry2.TO_DATE
                                        }).GroupBy(x => new { x.DATA_SOURCE, x.DATA_GROUP, x.DATA_NAME })
               .Select(g => g.First())
               .ToList();


            return result;


        }

        private List<LogBookName> GetData_Name_Monitoring(string KILN, string fromDate, string toDate)
        {
            OracleDataAdapter QMFeMTDA;
            OracleDataAdapter frmmonthQMFeMTDA;
            DataTable QMFeMTDT = new DataTable();
            List<LogBookName> lstdatanamemonitoring = new List<LogBookName>();



            //string sqlcmd=  @"SELECT B.DATA_SOURCE, B.DATA_GROUP, B.DATA_NAME, A.tag_id, A.tag_value, A.data_time AS MAX_DATA_TIME
            //         FROM V_DRI_DATA A
            //         JOIN T_DRI_DATA_CONFIG B ON B.ID_PLC_DATA_SEQ = A.tag_id
            //            WHERE B.ID_KILN = 5
            //                  AND A.data_time > SYSDATE - INTERVAL '15' MINUTE
            //                  AND A.data_time = (
            //                 SELECT MAX(data_time)
            //                         FROM V_DRI_DATA
            //                       WHERE tag_id = A.tag_id
            //              AND data_time > SYSDATE - INTERVAL '15' MINUTE
            //                         )
            //                       GROUP BY B.DATA_SOURCE, B.DATA_GROUP, B.DATA_NAME, A.tag_id, A.tag_value, A.data_time
            //                   ORDER BY B.DATA_SOURCE, B.DATA_GROUP, B.DATA_NAME ASC";

            //            string sqlcmd1= @"SELECT B.DATA_SOURCE, B.DATA_GROUP, B.DATA_NAME, A.TAG_ID, A.TAG_VALUE, A.DATA_TIME AS MAX_DATA_TIME FROM V_DRI_DATA A JOIN T_DRI_DATA_CONFIG B ON B.ID_PLC_DATA_SEQ = A.TAG_ID 
            //WHERE B.ID_KILN = '" + KILN  + "'  AND A.DATA_TIME > SYSDATE - INTERVAL '15' MINUTE AND A.DATA_TIME = (SELECT MAX(DATA_TIME) FROM V_DRI_DATA WHERE TAG_ID = A.TAG_ID AND DATA_TIME > SYSDATE - INTERVAL '15' MINUTE) GROUP BY B.DATA_SOURCE, B.DATA_GROUP, B.DATA_NAME, A.TAG_ID, A.TAG_VALUE, A.DATA_TIME ORDER BY B.DATA_SOURCE, B.DATA_GROUP, B.DATA_NAME ASC
            string sqlcmd = @"SELECT 
    B.DATA_SOURCE, 
    B.DATA_GROUP, 
    B.DATA_NAME, 
    B.MIN_VALUE,
    B.MAX_VALUE,
    A.TAG_ID, 
    A.TAG_VALUE, 
    A.DATA_TIME AS MAX_DATA_TIME 
FROM 
    V_DRI_DATA A 
    JOIN T_DRI_DATA_CONFIG B ON B.ID_PLC_DATA_SEQ = A.TAG_ID 
WHERE 
    B.ID_KILN = " + KILN + @"
    AND A.DATA_TIME > SYSDATE - INTERVAL '15' MINUTE 
    AND A.DATA_TIME = (
        SELECT 
            MAX(DATA_TIME) 
        FROM 
            V_DRI_DATA 
        WHERE 
            TAG_ID = A.TAG_ID 
            AND DATA_TIME > SYSDATE - INTERVAL '15' MINUTE 
    )
GROUP BY 
    B.DATA_SOURCE, 
    B.DATA_GROUP, 
    B.DATA_NAME, 
    B.MIN_VALUE,
    B.MAX_VALUE,
    A.TAG_ID, 
    A.TAG_VALUE, 
    A.DATA_TIME
ORDER BY 
    B.DATA_SOURCE, 
    B.DATA_GROUP, 
    B.DATA_NAME ASC";
            QMFeMTDA = new OracleDataAdapter(sqlcmd, con);
            // frmmonthQMFeMTDA = new OracleDataAdapter(frmmonth, con);
            DataTable ds = new DataTable();
            DataTable ds1 = new DataTable();
            QMFeMTDA.Fill(ds);
            //frmmonthQMFeMTDA.Fill(ds1);
            if (ds.Rows.Count > 0)
            {
                foreach (DataRow Rows in ds.Rows)
                {
                    LogBookName objlogbook = new LogBookName();


                    objlogbook.DATA_SOURCE = Rows["DATA_SOURCE"] == DBNull.Value ? "" : (Rows["DATA_SOURCE"].ToString());
                    objlogbook.DATA_GROUP = Rows["DATA_GROUP"] == DBNull.Value ? "" : (Rows["DATA_GROUP"].ToString());
                    objlogbook.DATA_NAME = Rows["DATA_NAME"] == DBNull.Value ? "" : (Rows["DATA_NAME"].ToString());
                    objlogbook.TAG_VALUE = Rows["TAG_VALUE"] == DBNull.Value ? "" : (Rows["TAG_VALUE"].ToString());
                    objlogbook.MIN_VALUE = Rows["MIN_VALUE"] == DBNull.Value ? "0" : (Rows["MIN_VALUE"].ToString());
                    objlogbook.MAX_VALUE = Rows["MAX_VALUE"] == DBNull.Value ? "0" : (Rows["MAX_VALUE"].ToString());
                    objlogbook.DATA_TIME = Rows["MAX_DATA_TIME"] == DBNull.Value ? "" : (Rows["MAX_DATA_TIME"].ToString());


                    lstdatanamemonitoring.Add(objlogbook);

                }


            }




            return lstdatanamemonitoring;



        }



        private List<LogBookName> GetData_Name_Configuration(string KILN, string fromDate, string toDate)
        {
            OracleDataAdapter QMFeMTDA;
            OracleDataAdapter frmmonthQMFeMTDA;
            DataTable QMFeMTDT = new DataTable();
            List<LogBookName> lstdatanamemonitoring = new List<LogBookName>();



            //string sqlcmd=  @"SELECT B.DATA_SOURCE, B.DATA_GROUP, B.DATA_NAME, A.tag_id, A.tag_value, A.data_time AS MAX_DATA_TIME
            //         FROM V_DRI_DATA A
            //         JOIN T_DRI_DATA_CONFIG B ON B.ID_PLC_DATA_SEQ = A.tag_id
            //            WHERE B.ID_KILN = 5
            //                  AND A.data_time > SYSDATE - INTERVAL '15' MINUTE
            //                  AND A.data_time = (
            //                 SELECT MAX(data_time)
            //                         FROM V_DRI_DATA
            //                       WHERE tag_id = A.tag_id
            //              AND data_time > SYSDATE - INTERVAL '15' MINUTE
            //                         )
            //                       GROUP BY B.DATA_SOURCE, B.DATA_GROUP, B.DATA_NAME, A.tag_id, A.tag_value, A.data_time
            //                   ORDER BY B.DATA_SOURCE, B.DATA_GROUP, B.DATA_NAME ASC";

            //            string sqlcmd1= @"SELECT B.DATA_SOURCE, B.DATA_GROUP, B.DATA_NAME, A.TAG_ID, A.TAG_VALUE, A.DATA_TIME AS MAX_DATA_TIME FROM V_DRI_DATA A JOIN T_DRI_DATA_CONFIG B ON B.ID_PLC_DATA_SEQ = A.TAG_ID 
            //WHERE B.ID_KILN = '" + KILN  + "'  AND A.DATA_TIME > SYSDATE - INTERVAL '15' MINUTE AND A.DATA_TIME = (SELECT MAX(DATA_TIME) FROM V_DRI_DATA WHERE TAG_ID = A.TAG_ID AND DATA_TIME > SYSDATE - INTERVAL '15' MINUTE) GROUP BY B.DATA_SOURCE, B.DATA_GROUP, B.DATA_NAME, A.TAG_ID, A.TAG_VALUE, A.DATA_TIME ORDER BY B.DATA_SOURCE, B.DATA_GROUP, B.DATA_NAME ASC
            string sqlcmd = @"SELECT 
                 DATA_SOURCE, 
                 DATA_GROUP, 
                    DATA_NAME, 
                  MIN_VALUE,
                  MAX_VALUE 
                  from t_dri_data_config  where ID_KILN = " + KILN + @"
                          GROUP BY 
                         DATA_SOURCE, 
                        DATA_GROUP, 
                        DATA_NAME, 
                        MIN_VALUE,
                        MAX_VALUE 
       
    
                         ORDER BY 
                       DATA_SOURCE, 
                        DATA_GROUP, 
                      DATA_NAME ASC";
            QMFeMTDA = new OracleDataAdapter(sqlcmd, con);
            // frmmonthQMFeMTDA = new OracleDataAdapter(frmmonth, con);
            DataTable ds = new DataTable();
            // DataTable ds1 = new DataTable();
            QMFeMTDA.Fill(ds);
            //frmmonthQMFeMTDA.Fill(ds1);
            if (ds.Rows.Count > 0)
            {
                foreach (DataRow Rows in ds.Rows)
                {
                    LogBookName objlogbook = new LogBookName();


                    objlogbook.DATA_SOURCE = Rows["DATA_SOURCE"] == DBNull.Value ? "" : (Rows["DATA_SOURCE"].ToString());
                    objlogbook.DATA_GROUP = Rows["DATA_GROUP"] == DBNull.Value ? "" : (Rows["DATA_GROUP"].ToString());
                    objlogbook.DATA_NAME = Rows["DATA_NAME"] == DBNull.Value ? "" : (Rows["DATA_NAME"].ToString());
                    // objlogbook.TAG_VALUE = Rows["TAG_VALUE"] == DBNull.Value ? "" : (Rows["TAG_VALUE"].ToString());
                    //objlogbook.DATA_TIME = Rows["MAX_DATA_TIME"] == DBNull.Value ? "" : (Rows["MAX_DATA_TIME"].ToString());
                    objlogbook.MIN_VALUE = Rows["MIN_VALUE"] == DBNull.Value ? "0" : (Rows["MIN_VALUE"].ToString());
                    objlogbook.MAX_VALUE = Rows["MAX_VALUE"] == DBNull.Value ? "0" : (Rows["MAX_VALUE"].ToString());
                    lstdatanamemonitoring.Add(objlogbook);

                }


            }




            return lstdatanamemonitoring;



        }
        private List<LogBook> GetData_Material(string KILN, string Date)
        {



            OracleDataAdapter QMFeMTDA;
            DataTable QMFeMTDT = new DataTable();
            List<LogBook> lstdatagroup = new List<LogBook>();
            try
            {




                string sqlcmd = @"select distinct  CASE table_name WHEN 'V_DOLO' THEN 'DOLOMITE'
                WHEN 'V_FINE_DRI' THEN 'DRI FINES'
                WHEN 'V_INJ_C_COAL' THEN 'INJECTION COARSE COAL'
                WHEN 'V_INJ_F_COAL' THEN 'INJECTION FINE COAL'
                 WHEN 'V_LUMP_DRI' THEN 'DRI LUMPS'
                WHEN 'V_ORE' THEN 'ORES'
                 WHEN 'V_FEEDCOAL' THEN 'FEEDCOAL'
                 ELSE table_name END AS TABLE_NAME from T_LAB_DATA_CONFIG where id_kiln=" + KILN + "  order by TABLE_NAME";
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }



                QMFeMTDA = new OracleDataAdapter(sqlcmd, con);
                DataTable ds = new DataTable();
                QMFeMTDA.Fill(ds);

                if (ds.Rows.Count > 0)
                {
                    foreach (DataRow Rows in ds.Rows)
                    {
                        LogBook objlogbook = new LogBook();


                        objlogbook.TABLE_NAME = Rows["TABLE_NAME"] == DBNull.Value ? "" : (Rows["TABLE_NAME"].ToString());

                        lstdatagroup.Add(objlogbook);

                    }


                }



            }

            catch (Exception ex)
            {

            }

            return lstdatagroup;


        }  //Quality logbook.
        private List<LogBookGroup> GetData_Material_Desc(string KILN, string fromDate,string toDate)
        {
           



            DateTime dtDate;
            DateTime dateTime1;
            DateTime dateTime2;



            if (DateTime.TryParse(fromDate, out dtDate))
            {
                dtDate = dtDate.AddDays(-(dtDate.Day - 1)).Date;
                Console.WriteLine("First Day of Month: " + dtDate.ToString("MM/dd/yyyy"));
            }
            else
            {
                Console.WriteLine("Invalid date format.");
            }
            string frmmonthdate = dtDate.ToString("MM/dd/yyyy") + " " + "6:00:00 :AM";

            if (DateTime.TryParse(fromDate, out dateTime1))
            {
                dateTime1 = dateTime1.Date;

            }

            if (DateTime.TryParse(toDate, out dateTime2))
            {
                dateTime2 = dateTime2.Date;

            }
            string fromdate = dateTime1.ToString("d") + " " + "6:00:00 :AM";
            string todate = dateTime2.ToString("d") + " " + "5:59:59 :AM";

            DateTime datehmi = dateTime1.Date;





            List<LogBookGroup> finalresult = new List<LogBookGroup>();

            OracleDataAdapter QMFeMTDA;
            OracleDataAdapter QMFeMTDAfrmmonth;
            DataTable QMFeMTDT = new DataTable();
            DataTable frmmonthQMFeMTDA = new DataTable();
            List<LogBookGroup> lstdatagroupondate = new List<LogBookGroup>();
            List<LogBookGroup> lstdatagrouptodate = new List<LogBookGroup>();
            try
            {



               







                


//   string sqlfinalontoavg= @"SELECT
//  A.id_kiln, dc.desc_lab_data,
//  CASE dc.table_name
//                WHEN 'V_DOLO' THEN 'DOLOMITE'
//                 WHEN 'V_FINE_DRI' THEN 'DRI FINES'
//                WHEN 'V_INJ_C_COAL' THEN 'INJECTION COARSE COAL'
//                WHEN 'V_INJ_F_COAL' THEN 'INJECTION FINE COAL'
//                 WHEN 'V_LUMP_DRI' THEN 'DRI LUMPS'
//                WHEN 'V_ORE' THEN 'ORES'
//                 WHEN 'V_FEEDCOAL' THEN 'FEEDCOAL'
//                 ELSE dc.table_name
//                    END AS TABLE_NAME,

//  AVG(A.shifta) shifta, 
//  AVG(A.shiftb) shiftb, 
//  AVG(A.shiftc) shiftc, 
//  A.id_seq_lab_data, 
//  A.data_date, 
//  --ROUND((AVG(A.shifta) + AVG(A.shiftb) + AVG(A.shiftc)) / 3, 2) as ondate,
  
//             ROUND(case
//                     WHEN(AVG(A.shifta) != 0 and AVG(A.shiftb) = 0 and AVG(A.shiftc) = 0) THEN AVG(A.shifta)
//                     WHEN AVG(A.shifta) = 0 and AVG(A.shiftb) != 0 and AVG(A.shiftc) = 0 THEN AVG(A.shiftb)
//                     WHEN AVG(A.shifta) = 0 and AVG(A.shiftb) = 0 and AVG(A.shiftc) != 0 THEN AVG(A.shiftc)
//                     WHEN AVG(A.shifta) = 0 and AVG(A.shiftb) != 0 and AVG(A.shiftc) != 0 THEN(AVG(A.shiftc) + AVG(A.shiftb)) / 2
//                     WHEN AVG(A.shifta) != 0 and AVG(A.shiftb) = 0 and AVG(A.shiftc) != 0 THEN(AVG(A.shiftc) + AVG(A.shifta)) / 2
//                     WHEN AVG(A.shifta) != 0 and AVG(A.shiftb) != 0 and AVG(A.shiftc) = 0 THEN(AVG(A.shiftb) + AVG(A.shifta)) / 2
//                     ELSE(AVG(A.shifta) + AVG(A.shiftb) + AVG(A.shiftc)) / 3
//                   END, 2) AS ON_DATE,

//  ROUND(
//    (SELECT AVG((A2.shifta + A2.shiftb + A2.shiftc) / 3)
//     FROM t_lab_data_shift_wise A2
//     WHERE A2.id_kiln = A.id_kiln
//       AND A2.id_seq_lab_data = A.id_seq_lab_data
//       AND TRUNC(A2.data_date) <= TRUNC(A.data_date)
//       AND TRUNC(A2.data_date) >= TRUNC(A.data_date, 'MM')
//       AND(A2.shifta <> 0 OR A2.shiftb <> 0 OR A2.shiftc <> 0)
//    ), 2
//  ) AS TO_DATE
//FROM t_lab_data_shift_wise  A join t_lab_data_config dc on dc.id_seq_lab_data = a.id_seq_lab_data and dc.id_kiln = a.id_kiln
//  --WHERE TRUNC(A.data_date) BETWEEN TRUNC(SYSDATE, 'MM')  AND TRUNC(SYSDATE)
//WHERE TRUNC(A.data_date) = TO_DATE('" + datehmi + "', 'MM/dd/yyyy HH:MI:SS :AM') AND A.id_kiln = "+KILN+" AND(A.shifta <> 0 OR A.shiftb <> 0 OR A.shiftc <> 0) GROUP BY A.id_seq_lab_data, A.data_date, A.id_kiln ,dc.table_name,dc.desc_lab_data ORDER BY A.data_date desc";






                string sqlfinalontoavg= @"SELECT
  K.id_kiln,
  D.desc_lab_data,
  CASE D.table_name
      WHEN 'V_DOLO' THEN 'DOLOMITE'
      WHEN 'V_FINE_DRI' THEN 'DRI FINES'
      WHEN 'V_INJ_C_COAL' THEN 'INJECTION COARSE COAL'
      WHEN 'V_INJ_F_COAL' THEN 'INJECTION FINE COAL'
      WHEN 'V_LUMP_DRI' THEN 'DRI LUMPS'
      WHEN 'V_ORE' THEN 'ORES'
      WHEN 'V_FEEDCOAL' THEN 'FEEDCOAL'
      ELSE D.table_name
  END AS TABLE_NAME,
  AVG(K.shifta) AS SHIFTA,
  AVG(K.shiftb) AS SHIFTB,
  AVG(K.shiftc) AS SHIFTC,
  K.id_seq_lab_data,
  K.data_date,
  ROUND(
    (CASE
      WHEN AVG(K.shifta) > 0 AND AVG(K.shiftb) = 0 AND AVG(K.shiftc) = 0 THEN AVG(K.shifta)
      WHEN AVG(K.shifta) = 0 AND AVG(K.shiftb) > 0 AND AVG(K.shiftc) = 0 THEN AVG(K.shiftb)
      WHEN AVG(K.shifta) = 0 AND AVG(K.shiftb) = 0 AND AVG(K.shiftc) > 0 THEN AVG(K.shiftc)
      WHEN AVG(K.shifta) > 0 AND AVG(K.shiftb) > 0 AND AVG(K.shiftc) = 0 THEN(AVG(K.shiftb) + AVG(K.shifta)) / 2
      WHEN AVG(K.shifta) > 0 AND AVG(K.shiftb) = 0 AND AVG(K.shiftc) > 0 THEN(AVG(K.shiftc) + AVG(K.shifta)) / 2
      WHEN AVG(K.shifta) = 0 AND AVG(K.shiftb) > 0 AND AVG(K.shiftc) > 0 THEN(AVG(K.shiftc) + AVG(K.shiftb)) / 2
      ELSE(AVG(K.shifta) + AVG(K.shiftb) + AVG(K.shiftc)) / 3
    END),
    2
  ) AS ON_DATE,
  ROUND(
    (SELECT
        (CASE
          WHEN AVG(K2.shifta) > 0 AND AVG(K2.shiftb) = 0 AND AVG(K2.shiftc) = 0 THEN AVG(K2.shifta)
          WHEN AVG(K2.shifta) = 0 AND AVG(K2.shiftb) > 0 AND AVG(K2.shiftc) = 0 THEN AVG(K2.shiftb)
          WHEN AVG(K2.shifta) = 0 AND AVG(K2.shiftb) = 0 AND AVG(K2.shiftc) > 0 THEN AVG(K2.shiftc)
          WHEN AVG(K2.shifta) > 0 AND AVG(K2.shiftb) > 0 AND AVG(K2.shiftc) = 0 THEN(AVG(K2.shiftb) + AVG(K2.shifta))
          WHEN AVG(K2.shifta) > 0 AND AVG(K2.shiftb) = 0 AND AVG(K2.shiftc) > 0 THEN(AVG(K2.shiftc) + AVG(K2.shifta))
          WHEN AVG(K2.shifta) = 0 AND AVG(K2.shiftb) > 0 AND AVG(K2.shiftc) > 0 THEN(AVG(K2.shiftc) + AVG(K2.shiftb))
          ELSE(AVG(K2.shifta) + AVG(K2.shiftb) + AVG(K2.shiftc)) / 3
        END)
     FROM t_lab_data_shift_wise K2
     WHERE K2.id_kiln = K.id_kiln
       AND K2.id_seq_lab_data = K.id_seq_lab_data
       AND K2.data_date <= K.data_date
       AND TRUNC(K2.data_date) >= TRUNC(K.data_date, 'MM')
       AND(K2.shifta IS NOT NULL OR K2.shiftb IS NOT NULL OR K2.shiftc IS NOT NULL)),
    2
  ) AS TO_DATE
FROM t_lab_data_shift_wise K
JOIN t_lab_data_config D
ON D.ID_SEQ_LAB_DATA = K.ID_SEQ_LAB_DATA
AND D.ID_KILN = K.ID_KILN
WHERE TRUNC(K.data_date) = TO_DATE('" + datehmi + "', 'MM/dd/yyyy HH:MI:SS :AM') AND K.ID_KILN = "+KILN+" AND(K.SHIFTA IS NOT NULL OR K.SHIFTB IS NOT NULL OR K.SHIFTC IS NOT NULL) GROUP BY K.ID_SEQ_LAB_DATA, K.data_date, K.ID_KILN, D.TABLE_NAME, D.DESC_LAB_DATA ORDER BY K.data_date DESC";









                QMFeMTDAfrmmonth = new OracleDataAdapter(sqlfinalontoavg, con);
              
               // DataTable dstodate = new DataTable();
                DataTable finalOntods= new DataTable();
                //QMFeMTDA.Fill(finalOntods);
                QMFeMTDAfrmmonth.Fill(finalOntods);
                if (finalOntods.Rows.Count > 0)
                {
                    foreach (DataRow Rows in finalOntods.Rows)
                    {
                        LogBookGroup objlogbook = new LogBookGroup();


                        objlogbook.TABLE_NAME = Rows["TABLE_NAME"] == DBNull.Value ? "" : (Rows["TABLE_NAME"].ToString());
                        objlogbook.DESC_LAB_DATA = Rows["DESC_LAB_DATA"] == DBNull.Value ? "" : (Rows["DESC_LAB_DATA"].ToString());
                        objlogbook.ID_SEQ_LAB_DATA = Rows["ID_SEQ_LAB_DATA"] == DBNull.Value ? "" : (Rows["ID_SEQ_LAB_DATA"].ToString());
                        objlogbook.SHIFTA = Rows["SHIFTA"] == DBNull.Value ? "" : (Rows["SHIFTA"].ToString());
                        objlogbook.SHIFTB = Rows["SHIFTB"] == DBNull.Value ? "" : (Rows["SHIFTB"].ToString());
                        objlogbook.SHIFTC = Rows["SHIFTC"] == DBNull.Value ? "" : (Rows["SHIFTC"].ToString());
                      
                        objlogbook.ON_DATE = Rows["ON_DATE"] == DBNull.Value ? "" : (Rows["ON_DATE"].ToString());
                        objlogbook.TO_DATE = Rows["TO_DATE"] == DBNull.Value ? "" : (Rows["TO_DATE"].ToString());

                        lstdatagroupondate.Add(objlogbook);

                    }


                }

                lstdatagroupondate = lstdatagroupondate.Select(y => new LogBookGroup

                {
                    DESC_LAB_DATA = y.DESC_LAB_DATA,
                    TABLE_NAME = y.TABLE_NAME,
                    ID_SEQ_LAB_DATA = y.ID_SEQ_LAB_DATA,
                    ON_DATE = y.ON_DATE,
                    TO_DATE = y.TO_DATE,
                    SHIFTA = y.SHIFTA == "0" ? "-" : y.SHIFTA,
                    SHIFTB = y.SHIFTB == "0" ? "-" : y.SHIFTB,
                    SHIFTC = y.SHIFTC == "0" ? "-" : y.SHIFTC,



                }).ToList();






                return lstdatagroupondate;





            }

            catch (Exception ex)
            {
               // finalresult;
            }

            return lstdatagroupondate;


        }  //Quality logbook.
        [WebMethod]

        public string UpdateLConfigurationTableData(string KILN, string DataName, string Min, string Max)
        {
            LogBook objlogbook = new LogBook();

            objlogbook.ID_KILN = KILN;
            objlogbook.DATA_NAME = DataName;
            objlogbook.MIN_VALUE = Min;
            objlogbook.MAX_VALUE = Max;


            string msg = dRIProvider.UpdateLConfigurationData(objlogbook);

            if (msg == "true")
            {

                return "Data Updated Succesfully!";
            }
            else
            {
                return "Error In Saving!";

            }





            //return "true";
        }
        [WebMethod]
        public object GetFeedTableData(string fromDate,string toDate, string KILN,string TYPE)
        {
            List<LossBook> finallossfeedbook = new List<LossBook>();
            LossBook lossBook = new LossBook();
            lossBook.ID_KILN = KILN;
            string sql = ""; 
           

            OracleDataAdapter QMCPDA;
            DataTable QMCPDT = new DataTable();
            List<LossBook> paramValues = new List<LossBook>();
            sql = "select * from T_FEED_LOG_BOOK where ID_KILN=" + KILN+" and TYPE='"+TYPE+"'";

            if (con.State != ConnectionState.Open)
            {
                con.Open();
            }
            
            

            QMCPDA = new OracleDataAdapter(sql, con);
            QMCPDA.Fill(QMCPDT);

            if (QMCPDT.Rows.Count > 0)
            {
                foreach (DataRow Rows in QMCPDT.Rows)
                {
                    LossBook OBJlossBook = new LossBook();
                    DateTime fromdate = Rows["FROM_DATE"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(Rows["FROM_DATE"].ToString());
                    DateTime TODATE = Rows["TO_DATE"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(Rows["TO_DATE"].ToString());
                    OBJlossBook.frmdate = fromdate.ToString("dd-MM-yyyy HH:mm:ss");
                    OBJlossBook.todate = TODATE.ToString("dd-MM-yyyy HH:mm:ss");
                    OBJlossBook.REASON= Rows["DELAY_REASON"] == DBNull.Value ? "-" : (Rows["DELAY_REASON"].ToString());
                    OBJlossBook.DEPARTMENT= Rows["DEPARTMENT"] == DBNull.Value ? "-" : (Rows["DEPARTMENT"].ToString());
                    OBJlossBook.EQUIPMENT = Rows["EQUIPMENT"] == DBNull.Value ? "-" : (Rows["EQUIPMENT"].ToString());
                    OBJlossBook.DURATION = Rows["DURATION"] == DBNull.Value ? "-" : (Rows["DURATION"].ToString());
                    OBJlossBook.TYPE = Rows["TYPE"] == DBNull.Value ? "-" : (Rows["TYPE"].ToString());


                    finallossfeedbook.Add(OBJlossBook);

                }
            }
            
            return finallossfeedbook.OrderByDescending(x=>x.frmdate);



     }


    }


   
   }
















