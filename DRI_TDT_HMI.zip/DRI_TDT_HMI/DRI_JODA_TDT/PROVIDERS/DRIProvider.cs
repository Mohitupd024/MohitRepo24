﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web;
using DRI_JODA_TDT.MODELS;
using Newtonsoft.Json;
using RestSharp;
using static DRI_JODA_TDT.REST.DRI_REST_API;

namespace DRI_JODA_TDT.PROVIDERS
{
    public class DRIProvider
    {
        DRIWebAPI_Client aPI_Client;


        //string url = "https://localhost:7052/api/Login";
        public List<USER> Validate_Login_Data(USER parameter)
        {
            List<USER> objResp = null;


            RestResponse response;
            string jsonBody;
            try
            {
                aPI_Client = new DRIWebAPI_Client();

                jsonBody = "{\"USER_NAME\": \"" + parameter.USER_NAME + "\"" +

                    ",\"PASSWORD\": \"" + parameter.PASSWORD + "\"}";

                response = aPI_Client.connect_rest("/" + "api/Login", Method.Post, jsonBody);


                if (response != null && (response.StatusCode == HttpStatusCode.OK) && response.ErrorException == null)
                {
                    var materialRoot = JsonConvert.DeserializeObject<List<USER>>(response.Content);
                    objResp = materialRoot;
                }
                else
                {
                    throw response.ErrorException;
                }
            }

            catch (Exception)
            {


            }
            finally
            {
                //aPI_Client.disConnect_rest();
                aPI_Client = null;
                parameter = null;
            }
            return objResp;

            //var client = new RestClient("https://localhost:7052");
            //var request = new RestRequest("api/Login", Method.Post);
            //request.RequestFormat = DataFormat.Json;
            //request.AddBody(new USER



            //{
            //    USER_NAME = parameter.USER_NAME,
            //    PASSWORD=parameter.PASSWORD
            //});

            //client.Execute(request);

            // return "test";
        }




        public List<ActionLog> GetActionLog(ActionLog parameter)
        {
            List<ActionLog> objResp = null;


            RestResponse response;
            string jsonBody;
            try
            {
                aPI_Client = new DRIWebAPI_Client();

                jsonBody = "{\"ID_KILN\": \"" + parameter.ID_KILN + "\"}";

                response = aPI_Client.connect_rest("/" + "api/Action/GetActionLog", Method.Post, jsonBody);


                if (response != null && (response.StatusCode == HttpStatusCode.OK) && response.ErrorException == null)
                {
                    var materialRoot = JsonConvert.DeserializeObject<List<ActionLog>>(response.Content);
                    objResp = materialRoot;
                }
                else
                {
                    throw response.ErrorException;
                }
            }

            catch (Exception)
            {


            }
            finally
            {
                aPI_Client.disConnect_rest();
                aPI_Client = null;
                parameter = null;
            }
            return objResp;


        }





        public string UpdateLConfigurationData(LogBook parameter)
        {
            string objResp = null;

            //// string apiurl = "http://localhost:5243/api/LogMonitoring/api/LogMonitoring/UpdateLConfigDetail";
            string apiurl = "http://10.163.30.60:11/api/LogMonitoring/api/LogMonitoring/UpdateLConfigDetail";

            string jsonBody;
            try
            {
                aPI_Client = new DRIWebAPI_Client();

                jsonBody = "{" +
                    "\"ID_KILN\": \"" + parameter.ID_KILN + "\"" +

                     ",\"MIN_VALUE\": \"" + parameter.MIN_VALUE + "\"" +
                      ",\"MAX_VALUE\": \"" + parameter.MAX_VALUE + "\"" +
                       ",\"DATA_NAME\": \"" + parameter.DATA_NAME + "\"}";



                var client = new RestClient(apiurl);
                var restRequest = new RestRequest();
                restRequest.Method = Method.Post;


                restRequest.AddHeader("Content-Type", "application/json");
                restRequest.AddParameter("application/json", jsonBody, ParameterType.RequestBody);

                var response = client.Execute(restRequest);

                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {

                    objResp = "true";
                }



            }

            catch (Exception)
            {


            }
            finally
            {
                aPI_Client.disConnect_rest();
                aPI_Client = null;
                parameter = null;
            }
            return objResp;


        }

        //public string InsertUpdateFeedBook(LossBook parameter)
        //{
        //    string objResp = null;

        //   string apiurl = "http://localhost:5243/api/LogMonitoring/api/LogMonitoring/InsertUpdateFeedBook";
        //   // string apiurl = "http://10.163.30.60:11/api/LogMonitoring/api/LogMonitoring/InsertUpdateFeedBook";

        //    string jsonBody;
        //    try
        //    {
        //        aPI_Client = new DRIWebAPI_Client();

        //        jsonBody = "{" +
        //            "\"ID_KILN\": \"" + parameter.ID_KILN + "\"" +

        //             ",\"FROM_DATE\": \"" + parameter.FROM_DATE.ToString("o") + "\"" +
        //              ",\"TO_DATE\": \"" + parameter.TO_DATE.ToString("o") + "\"" +
        //               ",\"DURATION\": \"" + parameter.DURATION + "\"" +
        //                ",\"DEPARTMENT\": \"" + parameter.DEPARTMENT + "\"" +
        //                 ",\"EQUIPMENT\": \"" + parameter.EQUIPMENT + "\"" +
        //               ",\"REASON\": \"" + parameter.REASON + "\"}";



        //        var client = new RestClient(apiurl);
        //        var restRequest = new RestRequest();
        //        restRequest.Method = Method.Post;


        //        restRequest.AddHeader("Content-Type", "application/json");
        //        restRequest.AddParameter("application/json", jsonBody, ParameterType.RequestBody);

        //        var response = client.Execute(restRequest);

        //        if (response.StatusCode == System.Net.HttpStatusCode.OK)
        //        {

        //            objResp = "true";
        //        }



        //    }

        //    catch (Exception)
        //    {


        //    }
        //    finally
        //    {
        //        aPI_Client.disConnect_rest();
        //        aPI_Client = null;
        //        parameter = null;
        //    }
        //    return objResp;


        //}

        public List<LossBook> GetFeedLog(LossBook parameter)
        {
            string apiurl = "http://localhost:5243/api/LogMonitoring/api/LogMonitoring/GetFeedBook";

            List<LossBook> objResp = null;


            //RestResponse response;
            string jsonBody;

            aPI_Client = new DRIWebAPI_Client();

            jsonBody = "{\"ID_KILN\": \"" + parameter.ID_KILN + "\"}";

            var client = new RestClient(apiurl);
            var restRequest = new RestRequest();
            restRequest.Method = Method.Post;


            restRequest.AddHeader("Content-Type", "application/json");
            restRequest.AddParameter("application/json", jsonBody, ParameterType.RequestBody);

            var response = client.Execute(restRequest);

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var materialRoot = JsonConvert.DeserializeObject<List<LossBook>>(response.Content);
                objResp = materialRoot;

                return objResp;
            }
            return objResp;



        }
    }
}











       
    
    
    
    
    
   