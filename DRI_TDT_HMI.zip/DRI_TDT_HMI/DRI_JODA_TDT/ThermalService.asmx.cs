﻿using DRI_JODA_TDT.MODELS;
using DRI_JODA_TDT.PROVIDERS;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Services;

namespace DRI_JODA_TDT
{
    /// <summary>
    /// Summary description for ThermalService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class ThermalService : System.Web.Services.WebService
    {
        static DRIProvider dRIProvider = new DRIProvider();
        public static OracleConnection con = new OracleConnection("Data Source=(DESCRIPTION="
             + "(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=10.163.30.60)(PORT=1521)))"
             + "(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=autdevtsbsl)));"
             + "User Id=dril2;Password=dril22;");
        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }
        [WebMethod]
        public object GetThermalScannerData( string Date, string KILN)
        {
            List<THERMAL> lsttHERMALs = new List<THERMAL>();


            try
            {
                DateTime frmdate = Convert.ToDateTime(Date);
               
                string result = null;

                OracleDataAdapter QMFeMTDA;


                //string sqlcmd = "Select * from T_THERMAL_SCANNER_DATA WHERE ID_KILN = '" + KILN + "' AND TIME_STAMP = TO_DATE('" + frmdate + "', 'MM/DD/YYYY HH:MI:SS AM')"; 

                string sqlcmd = "Select * from T_THERMAL_SCANNER_DATA WHERE  ID_KILN = '" + KILN + "' AND TIME_STAMP = TO_DATE('" + frmdate + "', 'MM/DD/YYYY HH:MI:SS AM')"; 



                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }



                QMFeMTDA = new OracleDataAdapter(sqlcmd, con);
                DataTable ds = new DataTable();
                QMFeMTDA.Fill(ds);

                if (ds.Rows.Count > 0)
                {
                    foreach (DataRow Rows in ds.Rows)
                    {
                        THERMAL objDATA = new THERMAL();

                       // objDATA.ID_KILN= Rows["ID_KILN"] == DBNull.Value ? "" : (Rows["ID_KILN"].ToString());
                        objDATA.Z1 = Rows["Z1"] == DBNull.Value ? "" : (Rows["Z1"].ToString());
                        objDATA.Z2 = Rows["Z2"] == DBNull.Value ? "" : (Rows["Z2"].ToString());
                        objDATA.Z3 = Rows["Z3"] == DBNull.Value ? "" : (Rows["Z3"].ToString());
                        objDATA.Z4 = Rows["Z4"] == DBNull.Value ? "" : (Rows["Z4"].ToString());
                        objDATA.Z5 = Rows["Z5"] == DBNull.Value ? "" : (Rows["Z5"].ToString());
                        objDATA.Z6 = Rows["Z6"] == DBNull.Value ? "" : (Rows["Z6"].ToString());
                        objDATA.Z7 = Rows["Z7"] == DBNull.Value ? "" : (Rows["Z7"].ToString());
                        objDATA.Z8 = Rows["Z8"] == DBNull.Value ? "" : (Rows["Z8"].ToString());
                        objDATA.Z9 = Rows["Z9"] == DBNull.Value ? "" : (Rows["Z9"].ToString());

                        lsttHERMALs.Add(objDATA);
                    }
                }
            }

           
            

           

            catch (Exception ex)
            {

            }


            lsttHERMALs = lsttHERMALs.Select(thermal => new THERMAL
            {   //ID_KILN=thermal.ID_KILN,
                Z1 = thermal.Z1,
                Z2 = thermal.Z2,
                Z3 = thermal.Z3,
                Z4 = thermal.Z4,
                Z5 = thermal.Z5,
                Z6 = thermal.Z6,
                Z7 = thermal.Z7,
                Z8 = thermal.Z8,
                Z9 = thermal.Z9
            }).ToList();
            return lsttHERMALs;
        }
        [WebMethod]
        public List<THERMALTIME> FillddlDateThermal(string KILN)
        {
            //List<THERMAL> lstACtionlog = new List<THERMAL>();

            List<THERMALTIME> lsttHERMALs = new List<THERMALTIME>();


            try
            {

                string result = null;

                OracleDataAdapter QMFeMTDA;


                string sqlcmd = "Select * from T_THERMAL_SCANNER_DATA";




                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }



                QMFeMTDA = new OracleDataAdapter(sqlcmd, con);
                DataTable ds = new DataTable();
                QMFeMTDA.Fill(ds);



                if (ds.Rows.Count > 0)
                {
                    foreach (DataRow Rows in ds.Rows)
                    {
                        THERMALTIME objDATA = new THERMALTIME();


                        objDATA.TIME_STAMP =  Convert.ToDateTime(Rows["TIME_STAMP"]);
                        objDATA.ID_KILN =(Rows["ID_KILN"]).ToString();

                        lsttHERMALs.Add(objDATA);
                    }
                }
                else
                {
                    return lsttHERMALs;
                }
               


            }
            catch (Exception ex)
            {

            }
            //lsttHERMALs = lsttHERMALs.Select(thermal => new ThermalService
            //{ })

            //    (//TIME_STAMP=TIME_STAMP.ToString("G"),

            //    ).
            //    ToList();

            lsttHERMALs = lsttHERMALs.Select(thermal => new THERMALTIME
            {
               ID_KILN =  thermal.ID_KILN,
               DATE= thermal.TIME_STAMP.ToString("G")
            }).ToList();
            return lsttHERMALs;
        }

    }
}
