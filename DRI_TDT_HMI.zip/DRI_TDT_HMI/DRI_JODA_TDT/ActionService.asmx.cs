﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Configuration;
using DRI_JODA_TDT.PROVIDERS;
using System.Web.Security;

using DRI_JODA_TDT.MODELS;
using static DRI_JODA_TDT.DRIService;

namespace DRI_JODA_TDT
{
    /// <summary>
    /// Summary description for ActionService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class ActionService : System.Web.Services.WebService
    {
        static DRIProvider dRIProvider = new DRIProvider();

        ActionLog objActionlog = new ActionLog();

        [WebMethod]

        public object FillDDlEntryTime1(string KILN)
        {
            List<ActionLog> lstACtionlog = new List<ActionLog>();
          
            objActionlog.ID_KILN = KILN;


            lstACtionlog = dRIProvider.GetActionLog(objActionlog);



            if (lstACtionlog.Count > 0)
            {

                lstACtionlog = lstACtionlog.OrderByDescending(x => x.ENTRY_DATE).ToList();
                var Entrytime= lstACtionlog.Select(x=>x.ENTRY_DATE.ToString("G")).ToList();
             



                return Entrytime;
            }
            else
            {
                return lstACtionlog.OrderByDescending(X=>X.ENTRY_DATE);
            }

        }

       
        [WebMethod]
        public List<ActionLog> fetchLogBookData(string fromDate, string toDate,string KILN)// graph 1
        {
            List<ActionLog> finalActionlog = new List<ActionLog>();
           
             fromDate = fromDate.Replace('T', ' ');
             toDate = toDate.Replace('T', ' ');
             DateTime datefrm= Convert.ToDateTime(fromDate);
             DateTime dateto = Convert.ToDateTime(toDate);
             objActionlog.ID_KILN = KILN;


             finalActionlog = dRIProvider.GetActionLog(objActionlog).OrderByDescending(y=>y.ENTRY_DATE).ToList().Where(x => x.ENTRY_DATE >= datefrm & x.ENTRY_DATE <= dateto).Select
                (x => new ActionLog
                {
                 Date=x.ENTRY_DATE.ToString("G"),
                 REMARKS=x.REMARKS is null?"":x.REMARKS,
                 ACTION_TAKEN=x.ACTION_TAKEN is null? "":x.ACTION_TAKEN,
                 ID_KILN=x.ID_KILN,
                 FEM_ACTUAL= x.FEM_ACTUAL is null ? "" : x.FEM_ACTUAL,
                 FEM_PREDICTED= x.FEM_PREDICTED is null ? "" : x.FEM_PREDICTED,

                }).ToList();
                 
                
                
                
                
                
              

            if(finalActionlog.Count > 0)
            {
                return finalActionlog;

            }







            return finalActionlog;
        }

        [WebMethod]
        public  string SaveAllManualData(string data)
        {

            return "true";
        }


        [WebMethod]
        public string insertLogData(string datetime,string action,string remarks,string kiln)
        {

           
            DateTime date = Convert.ToDateTime(datetime);
            objActionlog.ENTRY_DATE = date;
            objActionlog.ID_KILN =kiln;
            objActionlog.ACTION_TAKEN = action;
            objActionlog.REMARKS = remarks;

            int rowsUpdated = 0;
            string result = null;
            OracleParameter[] oracleParameters = null;

            string v_Query = string.Empty;
            try
            {


                oracleParameters = new OracleParameter[4];
               
                oracleParameters[0] = new OracleParameter(@"ACTION_TAKEN", objActionlog.ACTION_TAKEN);
                oracleParameters[1] = new OracleParameter(@"REMARKS", objActionlog.REMARKS);
                oracleParameters[2] = new OracleParameter(@"ID_KILN", objActionlog.ID_KILN);
                oracleParameters[3] = new OracleParameter(@"ENTRY_DATE", objActionlog.ENTRY_DATE);



                v_Query = @"UPDATE DRIL2.T_ACTION_LOG_BOOK SET ACTION_TAKEN=:ACTION_TAKEN,REMARKS=:REMARKS WHERE ID_KILN=:ID_KILN  and ENTRY_DATE=:ENTRY_DATE";
                rowsUpdated = Execute_Non_Query_DB(v_Query, oracleParameters);

                if (rowsUpdated > 0)
                    result = "Updated Successfully!";
                else
                    result = "Failed";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                oracleParameters = null;
            }
            return result;
        }


        private int Execute_Non_Query_DB(string sqlCommand, OracleParameter[] dbParams)
        {
            int rowsUpdated = 0;
            List<string> result_message = new List<string>();
            try
            {
                con.Close();
                // DBConnect();
                con.Open();
                if (con == null)
                    // DBConnect();
                    con.Open();
                using (OracleCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = sqlCommand;
                    cmd.CommandType = CommandType.Text;
                    if (dbParams != null)
                        cmd.Parameters.AddRange(dbParams);
                    rowsUpdated = cmd.ExecuteNonQuery();
                }
            }
            catch (OracleException ex)
            {
                result_message.Add(ex.Message);
            }
            catch (Exception ex)
            {
                result_message.Add(ex.Message);
            }
            finally
            {
                con.Close();
                // DBClose();
            }
            return rowsUpdated;
        }



       // [WebMethod]
       
    }

    
}

        










    
