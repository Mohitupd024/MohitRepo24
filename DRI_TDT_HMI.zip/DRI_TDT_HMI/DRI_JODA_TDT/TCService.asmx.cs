﻿using DRI_JODA_TDT.MODELS;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Services;

namespace DRI_JODA_TDT
{
    /// <summary>
    /// Summary description for TCService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class TCService : System.Web.Services.WebService
    {
        public static OracleConnection con = new OracleConnection("Data Source=(DESCRIPTION="
                + "(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=10.163.30.60)(PORT=1521)))"
                + "(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=autdevtsbsl)));"
                + "User Id=dril2;Password=dril22;");
        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }

        [WebMethod]
        public List<TCDATADATE> GetTCTableData(string KILN, string Date)
        {
            DataTable dt = new DataTable();
            List<TCDATA> lstGetTcbyDate = new List<TCDATA>();

            List<TCDATADATE> lstGetDate = new List<TCDATADATE>();
            lstGetDate = GetDate(KILN, Date);//parent

            lstGetTcbyDate = GetTcbyDate(KILN, Date);//child

            List<TCDATADATE> listdate = new List<TCDATADATE>(); //PARENT LIST
            
            TCDATADATE DATEOBJCLASS = new TCDATADATE(); //PARENT  CLASS
           
            List<TCDATA> lsttcdata = new List<TCDATA>();//child LIST
            
            
           
            var resp_lstGetDate = lstGetDate.ToList(); // parent
            
            
            var resp_lstGetTcbyDate = lstGetTcbyDate.ToList(); //child
            
            
            
            for (int i = 0; i < resp_lstGetDate.Count(); i++)  //parent
            {
                DATEOBJCLASS = new TCDATADATE();




               DATEOBJCLASS.DATA_TIME = resp_lstGetDate[i].DATA_TIME;
               




                listdate.Add(DATEOBJCLASS); //adding to parent list

                lsttcdata = null; //before adding new index null child list
                lsttcdata = new List<TCDATA>();
                // foreach (var itemform in resp_DataForm)


                for (int j = 0; j < resp_lstGetTcbyDate.Count(); j++)
                {


                    TCDATA TCDATAdtl = new TCDATA  //child item add
                    {




                        DATA_NAME = resp_lstGetTcbyDate[j].DATA_NAME,
                        AVGVALUE = resp_lstGetTcbyDate[j].AVGVALUE,
                        MAXVALUE = resp_lstGetTcbyDate[j].MAXVALUE,
                        MINVALUE = resp_lstGetTcbyDate[j].MINVALUE,
                        min_value=resp_lstGetTcbyDate[j].min_value,
                        max_value=resp_lstGetTcbyDate[j].max_value
                      

                    };
                    if (resp_lstGetDate[i].DATA_TIME == resp_lstGetTcbyDate[j].DATA_TIME)
                    {
                        lsttcdata.Add(TCDATAdtl);//child list add

                        DATEOBJCLASS.lstTCdata = lsttcdata;


                    }




                    else
                    {





                    }


                }




            }


            //return JsonConvert.SerializeObject(FMlist);

            return listdate;

        }

        private List<TCDATADATE> GetDate(string KILN, string Date)
        {

            DateTime d = Convert.ToDateTime(Date);
            string fromDate = d.ToString("d") + " "  +"6:00:00:AM";

            string toDate = d.AddDays(1).ToString("d") + " " + "6:00:00:AM";



            OracleDataAdapter QMFeMTDA;
            DataTable QMFeMTDT = new DataTable();
            List<TCDATADATE> finaltcdatadate = new List<TCDATADATE>();
            try
            {



               // string sqlcmd = "SELECT distinct data_time from t_tc_dashboard where ID_KILN="+1+" order by DATA_TIME";
                string sqlcmd = "SELECT distinct data_time from t_tc_dashboard where ID_KILN=" + KILN + " and " +
                    "DATA_TIME  >= TO_DATE('" + fromDate + "', 'MM/dd/yyyy HH:MI:SS :AM') and DATA_TIME  <= TO_DATE('" + toDate + "', 'MM/dd/yyyy HH:MI:SS :AM') " +
                    " order by DATA_TIME";
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }

                QMFeMTDA = new OracleDataAdapter(sqlcmd, con);
                DataTable ds = new DataTable();
                QMFeMTDA.Fill(ds);

                if (ds.Rows.Count > 0)
                {
                    foreach (DataRow Rows in ds.Rows)
                    {
                        TCDATADATE objdate = new TCDATADATE();


                        objdate.DATA_TIME = Rows["DATA_TIME"] == DBNull.Value ? "" : (Rows["DATA_TIME"].ToString());

                        finaltcdatadate.Add(objdate);

                    }


                }



            }

            catch (Exception ex)
            {

            }

            return finaltcdatadate;


        }

        private List<TCDATA> GetTcbyDate(string KILN, string Date)
        {
            DateTime d = Convert.ToDateTime(Date);
            string fromDate = d.ToString("d") + " " + "6:00:00:AM";

            string toDate = d.AddDays(1).ToString("d") + " " + "6:00:00:AM";

            OracleDataAdapter QMFeMTDA;
            DataTable QMFeMTDT = new DataTable();
            List<TCDATA> finaltcdata = new List<TCDATA>();
            try
            {



               // string sqlcmd = "SELECT  DATA_TIME,MINVALUE,MAXVALUE,AVGVALUE, DATA_NAME ,TO_NUMBER(SUBSTR(data_name, 4)) as dname from t_tc_dashboard  where ID_KILN =" + KILN + " and  DATA_TIME >= TO_DATE('" + fromDate + "', 'MM/dd/yyyy HH:MI:SS :AM') and DATA_TIME  <= TO_DATE('" + toDate + "', 'MM/dd/yyyy HH:MI:SS :AM') order by DATA_TIME , dname asc";




               // string sqlcmd= @"SELECT TC.DATA_TIME TC.MAXVALUE,TC.MINVALUE,TC.AVGVALUE,TC.DATA_NAME  dc.min_value,dc.max_value FROM t_tc_dashboard TC left join t_dri_data_config DC

                                     //  ON dc.id_kiln = tc.id_kiln AND tc.data_name = dc.data_name where TC.ID_KILN =" + KILN + " and " +
                                     //"TC.DATA_TIME >= TO_DATE('" + fromDate + "', 'MM/dd/yyyy HH:MI:SS :AM') and TC.DATA_TIME  <= TO_DATE('" + toDate + "', 'MM/dd/yyyy HH:MI:SS :AM') order by TC.DATA_TIME ";

            string sqlcmd= @"SELECT DISTINCT TC.DATA_TIME, TC.MAXVALUE,TC.DATA_NAME, TC.MINVALUE, TC.AVGVALUE, DC.MIN_VALUE AS min_val, DC.MAX_VALUE AS max_val,TO_NUMBER(SUBSTR(TC.data_name, 4)) as dname
                                     FROM t_tc_dashboard TC
                                           JOIN t_dri_data_config DC ON DC.ID_KILN = TC.ID_KILN AND TC.DATA_NAME = DC.DATA_NAME
                                        WHERE TC.ID_KILN = '" + KILN+"' AND TC.DATA_TIME >= TO_DATE('"+fromDate+"', 'MM/DD/YYYY HH:MI:SS AM') AND TC.DATA_TIME < TO_DATE('"+toDate+ "', 'MM/DD/YYYY HH:MI:SS AM')  ORDER BY TC.DATA_TIME,dname asc";



                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }

                QMFeMTDA = new OracleDataAdapter(sqlcmd, con);
                DataTable ds = new DataTable();
                QMFeMTDA.Fill(ds);

                if (ds.Rows.Count > 0)
                {
                    foreach (DataRow Rows in ds.Rows)
                    {
                        TCDATA obj = new TCDATA();


                        obj.DATA_TIME = Rows["DATA_TIME"] == DBNull.Value ? "" : (Rows["DATA_TIME"].ToString());
                        obj.DATA_NAME = Rows["DATA_NAME"] == DBNull.Value ? "" : (Rows["DATA_NAME"].ToString());

                        obj.MINVALUE = Rows["MINVALUE"] == DBNull.Value ? "" : (Rows["MINVALUE"].ToString());
                        obj.MAXVALUE = Rows["MAXVALUE"] == DBNull.Value ? "" : (Rows["MAXVALUE"].ToString());
                        obj.AVGVALUE = Rows["AVGVALUE"] == DBNull.Value ? "" : (Rows["AVGVALUE"].ToString());
                        obj.min_value = Rows["min_val"] == DBNull.Value ? "" : (Rows["min_val"].ToString());
                        obj.max_value = Rows["max_val"] == DBNull.Value ? "" : (Rows["max_val"].ToString());
                        finaltcdata.Add(obj);

                    }


                }



            }

            catch (Exception ex)
            {

            }

            return finaltcdata;

           // partNumbers.OrderBy(x => PadNumbers(x));

        }

        //public static object PadNumbers(string input)
        //{
        //    return Regex.Replace(input, "[0-9]+", match => match.Value.PadLeft(10, '0'));
        //}







    }
}

