﻿using System;
using System.Collections.Generic;
using System.Data;
using System.EnterpriseServices;
using System.Linq;
using System.Text.Json;
using System.Web;
using System.Web.Services;
using DRI_JODA_TDT.MODELS;
using DRI_JODA_TDT.PROVIDERS;
using Oracle.ManagedDataAccess.Client;
using static DRI_JODA_TDT.DRIService;

namespace DRI_JODA_TDT
{
    /// <summary>
    /// Summary description for ManualDataService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class ManualDataService : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld(List<MANUAL> data)
        {
            MANUAL mANUAL= new MANUAL();
           //JsonSerializer.Deserialize<CSharpMember>(jsonString);
           // var json= ToJson(data);


         

            //foreach (var item in data.ToString())
            //{
            //    mANUAL.date=item.

            //}
            
           // for(int i=0; i<)
            
            
            
            
            
            
            
            return data.ToString();
        }


        [WebMethod]
        public List<MANUAL> GetManualDataShift(string KILN, string Date)
        {

            MANUAL Manual = new MANUAL();
            Manual.ID_KILN = KILN;
            Manual.date = Date;


           
            string sqlcmd = "";
            OracleDataAdapter QMFeMTDA;
            DataTable QMFeMTDT = new DataTable();

            string ShiftATime = "";
            string ShiftBTime = "";
            DateTime shiftc = new DateTime();
            DateTime shiftb = new DateTime();
            DateTime shifta = new DateTime();
            if (Manual.date == null || Manual.date == "")
            {
                Manual.date = DateTime.Now.ToString("MM/dd/yyyy");

            }
            shiftc = Convert.ToDateTime(Manual.date);
            shiftb = Convert.ToDateTime(Manual.date);
            shifta = Convert.ToDateTime(Manual.date);
            ShiftBTime = shiftb.ToString("MM/dd/yyyy");
            ShiftBTime = ShiftBTime + " " + "2:20:00 PM";
            ShiftATime = shifta.ToString("MM/dd/yyyy");
            ShiftATime = ShiftATime + " " + "6:20:00 AM";

         
            string shiftcTime = shiftc.ToString("MM/dd/yyyy");
            shiftcTime = shiftcTime + " " + "10:20:00 PM";


            IEnumerable<MANUAL> resp_Data = null;
            IEnumerable<MANUAL> resp_DataShift = null;

            IEnumerable<ShiftData> shiftDatas = null;
            resp_Data = GetManualDataStatic(Manual);
            string[] arrShitA = new string[resp_Data.Count()];
            string[] arrShitB = new string[resp_Data.Count()];
            string[] arrShitC = new string[resp_Data.Count()];
            string[] arridseqdata = new string[resp_Data.Count()];
            string[] arrdescParameter = new string[resp_Data.Count()];
            string[] arrunit = new string[resp_Data.Count()];
            string[] arrmax = new string[resp_Data.Count()];
            string[] arrmin = new string[resp_Data.Count()];

            if (Manual.date == null || Manual.date == "")
            {
                string From_Date = "";
                string To_Date = "";


                From_Date = DateTime.Now.AddDays(-1).ToString("MM/dd/yyyy");
                To_Date = DateTime.Now.ToString("MM/dd/yyyy");
                From_Date = From_Date + " " + "10:00:00 PM";
                To_Date = To_Date + " " + "10:30:00 PM";

                resp_DataShift = GetManualData(Manual);
                DateTime frmdatetime = new DateTime();
                DateTime todatetime = new DateTime();
                frmdatetime = Convert.ToDateTime(From_Date);
                todatetime = Convert.ToDateTime(To_Date);

                resp_DataShift = resp_DataShift.ToList().Where(x => x.DATA_RECEIVED_MOMENT >= frmdatetime && x.DATA_RECEIVED_MOMENT <= todatetime);

                List<ShiftData> shiftDatas1 = new List<ShiftData>();
                ShiftData obj = null;



            }
            else
            {
                DateTime frmdate = new DateTime();
                DateTime todate = new DateTime();
                string From_Date = "";
                string To_Date = "";

                From_Date = Manual.date;

                frmdate = Convert.ToDateTime(From_Date);
                From_Date = frmdate.AddDays(-1).ToString("MM/dd/yyyy");
                To_Date = Manual.date;

                todate = Convert.ToDateTime(To_Date);
                To_Date = todate.ToString("MM/dd/yyyy");


                From_Date = From_Date + " " + "10:00:00 PM";
                To_Date = To_Date + " " + "10:30:00 PM";


                resp_DataShift = GetManualData(Manual);
                DateTime frmdatetime = new DateTime();
                DateTime todatetime = new DateTime();
                frmdatetime = Convert.ToDateTime(From_Date);
                todatetime = Convert.ToDateTime(To_Date);


                resp_DataShift = resp_DataShift.ToList().Where(x => x.DATA_RECEIVED_MOMENT >= frmdatetime && x.DATA_RECEIVED_MOMENT <= todatetime);

                List<ShiftData> shiftDatas1 = new List<ShiftData>();
                ShiftData obj = null;
            }





            int i = 0;


            foreach (var shiftitem in resp_Data)
            {

                foreach (var shiftbackend in resp_DataShift)
                {

                    if (shiftbackend.ID_SEQ_MANUAL_DATA == shiftitem.ID_SEQ_MANUAL_DATA && shiftbackend.DATA_RECEIVED_MOMENT == Convert.ToDateTime(ShiftATime))
                    {
                        arrShitA[i] = shiftbackend.Value;

                    }
                    if (shiftbackend.ID_SEQ_MANUAL_DATA == shiftitem.ID_SEQ_MANUAL_DATA && shiftbackend.DATA_RECEIVED_MOMENT == Convert.ToDateTime(ShiftBTime))
                    {
                        arrShitB[i] = shiftbackend.Value;
                    }
                    if (shiftbackend.ID_SEQ_MANUAL_DATA == shiftitem.ID_SEQ_MANUAL_DATA && shiftbackend.DATA_RECEIVED_MOMENT == Convert.ToDateTime(shiftcTime))
                    {
                        arrShitC[i] = shiftbackend.Value;
                    }

                    arridseqdata[i] = shiftitem.ID_SEQ_MANUAL_DATA;
                    arrunit[i] = shiftitem.UNIT;
                    arrmax[i] = shiftitem.MAX_VALUE;
                    arrmin[i] = shiftitem.MIN_VALUE;
                    arrdescParameter[i] = shiftitem.DESC_MANUAL_DATA;
                }

                i++;



            }





            for (int j = 0; j < resp_Data.Count(); j++)
            {

                for (int k = 0; k < resp_Data.Count(); k++)
                {
                    resp_Data.ElementAt(k).ShiftA = arrShitA[k];

                }

                for (int l = 0; l < resp_Data.Count(); l++)
                {
                    resp_Data.ElementAt(l).ShiftB = arrShitB[l];

                }

                for (int m = 0; m < resp_Data.Count(); m++)
                {
                    resp_Data.ElementAt(m).ShiftC = arrShitC[m];
                }
            }



            resp_Data = resp_Data.Select
               (x => new MANUAL
               {
                   ID_SEQ_MANUAL_DATA=x.ID_SEQ_MANUAL_DATA,
                   ID_KILN=x.ID_KILN,
                   DESC_MANUAL_DATA=x.DESC_MANUAL_DATA,
                   MAX_VALUE=x.MAX_VALUE,
                   MIN_VALUE=x.MIN_VALUE,
                   ShiftA=x.ShiftA is null?"" :x.ShiftA,
                   ShiftB=x.ShiftB is null?"" :x.ShiftB,
                   ShiftC=x.ShiftC is null?"" :x.ShiftC,
                   UNIT=x.UNIT

               }).ToList();






            return resp_Data.ToList();







        }

        public IEnumerable<MANUAL> GetManualDataStatic(MANUAL mANUAL)
        {
            string sql = "";


            OracleDataAdapter QMCPDA;
            DataTable QMCPDT = new DataTable();
            List<MANUAL> finalparamValues = new List<MANUAL>();

            sql = "SELECT ID_SEQ_MANUAL_DATA, ID_KILN, MIN_VALUE, MAX_VALUE, UNIT, DESC_MANUAL_DATA From T_MANUAL_DATA_CONFIG Where ID_KILN =" + mANUAL.ID_KILN + " order by ID_SEQ_MANUAL_DATA";


            QMCPDA = new OracleDataAdapter(sql, con);
            DataTable ds = new DataTable();
            QMCPDA.Fill(ds);

            if (ds.Rows.Count > 0)
            {
                foreach (DataRow Rows in ds.Rows)
                {
                    MANUAL obj = new MANUAL();


                    obj.ID_KILN = Rows["ID_KILN"].ToString();
                    obj.ID_SEQ_MANUAL_DATA = Rows["ID_SEQ_MANUAL_DATA"].ToString();
                    obj.MAX_VALUE = Rows["MAX_VALUE"].ToString();

                    obj.MIN_VALUE = Rows["MIN_VALUE"].ToString();
                    obj.UNIT = Rows["UNIT"].ToString();
                    obj.DESC_MANUAL_DATA = Rows["DESC_MANUAL_DATA"].ToString();
                    finalparamValues.Add(obj);

                }

            }
            return finalparamValues.AsEnumerable();


        }

        public IEnumerable<MANUAL> GetManualData(MANUAL mANUAL)
        {
            string sql = "";


            OracleDataAdapter QMCPDA;
            DataTable QMCPDT = new DataTable();
            List<MANUAL> finalparamValues1 = new List<MANUAL>();

            sql = "SELECT T1.ID_SEQ_MANUAL_DATA, T1.MIN_VALUE, T1.MAX_VALUE, T1.UNIT,T2.data_received_moment,T2.value, T2.ID_KILN, calc_shift(T2.data_received_moment) as SHIFT FROM t_manual_data_config T1 LEFT JOIN t_manual_data_log T2 ON T1.ID_SEQ_MANUAL_DATA = T2.id_seq_manual_data where T2.ID_KILN =" + mANUAL.ID_KILN + " ORDER BY ID_SEQ_MANUAL_DATA";

            QMCPDA = new OracleDataAdapter(sql, con);
            DataTable ds = new DataTable();
            QMCPDA.Fill(ds);



            if (ds.Rows.Count > 0)
            {
                foreach (DataRow Rows in ds.Rows)
                {
                    MANUAL obj1 = new MANUAL();


                    obj1.ID_KILN = Rows["ID_KILN"].ToString();
                    obj1.ID_SEQ_MANUAL_DATA = Rows["ID_SEQ_MANUAL_DATA"].ToString();
                    obj1.MAX_VALUE = Rows["MAX_VALUE"].ToString();

                    obj1.MIN_VALUE = Rows["MIN_VALUE"].ToString();
                    obj1.UNIT = Rows["UNIT"].ToString();
                    obj1.Value = Rows["Value"].ToString();
                    obj1.DATA_RECEIVED_MOMENT = Convert.ToDateTime(Rows["DATA_RECEIVED_MOMENT"].ToString());
                    // obj.Value= Rows["Value"].ToString(); 

                    finalparamValues1.Add(obj1);

                    //obj.DATA_RECEIVED_MOMENT = dt.ToString("dd MMM HH:mm");


                }

            }




            return finalparamValues1.AsEnumerable();
        }

        [WebMethod]
        public bool InsertUpdateManualDatatst(string ID_KILN)
        {
            return true;
        }

        [WebMethod]
        //public bool InsertUpdateManualData(string ID_KILN, string ShiftA, string ShiftB, string ShiftC, string ID_SEQ_MANUAL_DATA, string Date1)
        public bool InsertUpdateManualData(List<MANUAL> data)
        {
            MANUAL manualData = new MANUAL();
            int length = data.Count();
            // int j = 0;v
            bool resp= false;

            foreach (MANUAL obj in data)
            {

                

               

                manualData.ShiftA = obj.SHIFT_A;
                manualData.ShiftB = obj.SHIFT_B;
                manualData.ShiftC = obj.SHIFT_C;
                manualData.ID_SEQ_MANUAL_DATA = obj.ID;
                manualData.ID_KILN = obj.ID_KILN;
                manualData.date = obj.date;

                if (manualData.ShiftA != "" || manualData.ShiftB != "" || manualData.ShiftC != "")
                {
                    resp = SaveAllManualHtmlData(manualData);
                }
                if(resp==false)
                {
                    return false;
                }
                
            }
            if (resp == true)
            {
                return true;
            }
            return false;

        }






        public bool SaveAllManualHtmlData(MANUAL manualData)
        {
            bool resp_Resultmsg = false;
            try
            {


                string resp_DataA = "";
                string resp_DataB = "";
                string resp_DataC = "";
             
                DateTime DTA = new DateTime();
                string Date = manualData.date;

                DTA = Convert.ToDateTime(Date);
                Date = DTA.ToString("MM/dd/yyyy");

                string DateShiftC = DTA.ToString("MM/dd/yyyy");

                if (manualData.ShiftA != null && manualData.ShiftA != "")
                {

                    manualData.Value = manualData.ShiftA;

                    manualData.date = Date + " " + "6:20:00:AM";
                    bool checkAvailability = CheckAvailabilityManual(manualData);
                    if (checkAvailability == false)
                    {
                        resp_DataA = InsertManualData(manualData);
                    }
                    else
                    {
                        resp_DataA = UpdateManualData(manualData);

                    }

                }

                if (manualData.ShiftB != null && manualData.ShiftB != "")
                {
                    manualData.Value = manualData.ShiftB;
                    manualData.date = "";
                    manualData.date = Date + " " + "2:20:00:PM";

                    bool checkAvailability = CheckAvailabilityManual(manualData);


                    if (checkAvailability == false)
                    {
                        resp_DataB = InsertManualData(manualData);
                    }
                    else
                    {
                        resp_DataB = UpdateManualData(manualData);

                    }
                }

                if (manualData.ShiftC != null && manualData.ShiftC != "")
                {


                    manualData.Value = manualData.ShiftC;
                    manualData.date = DateShiftC + " " + "10:20:00:PM";
                    bool checkAvailability = CheckAvailabilityManual(manualData);
                    if (checkAvailability == false)
                    {
                        resp_DataC = InsertManualData(manualData);
                    }
                    else
                    {
                        resp_DataC = UpdateManualData(manualData);

                    }

                }



                manualData.Value = "";


                if ((resp_DataA == "Successfull") || (resp_DataB == "Successfull") || (resp_DataC == "Successfull")) //All condition Check!
                {
                    manualData = null;
                    return resp_Resultmsg = true;

                }
                else
                {
                    return false;
                }
            }

            catch (Exception ex)
            {
                return resp_Resultmsg = false;

            }

            manualData.ShiftA = "";
            manualData.ShiftA = "";
            manualData.ShiftC = "";
        }

      


        public bool CheckAvailabilityManual(MANUAL mANUAL)
        {

            string sql = "";


            OracleDataAdapter QMCPDA;
            DataTable QMCPDT = new DataTable();
            List<MANUAL> finalparamValues = new List<MANUAL>();

           

            sql = "Select* from DRIL2.T_MANUAL_DATA_LOG where  ID_SEQ_MANUAL_DATA='" + mANUAL.ID_SEQ_MANUAL_DATA + "' and ID_KILN='" + mANUAL.ID_KILN + "' and DATA_RECEIVED_MOMENT = TO_Date('" + mANUAL.date + "', 'MM/dd/yyyy HH:MI:SS :AM')";
            QMCPDA = new OracleDataAdapter(sql, con);
            DataTable ds = new DataTable();
            QMCPDA.Fill(ds);





            if (ds.Rows.Count > 0)
            {

                return true;
            }

            else
            {

                return false;
            }

          

        }


        



        public string InsertManualData(MANUAL mANUAL)
        {



            int rowsUpdated = 0;
            string result = null;
            OracleParameter[] oracleParameters = null;
          
            string v_Query = string.Empty;
            try
            {

               // dBQuery = new DBQuery();
                //dbObj = new DBObj();
                oracleParameters = new OracleParameter[4];

                oracleParameters[0] = new OracleParameter(@"ID_SEQ_MANUAL_DATA", mANUAL.ID_SEQ_MANUAL_DATA);

                oracleParameters[1] = new OracleParameter(@"DATA_RECEIVED_MOMENT", mANUAL.date);
                oracleParameters[2] = new OracleParameter(@"VALUE", mANUAL.Value);
                oracleParameters[3] = new OracleParameter(@"ID_KILN", mANUAL.ID_KILN);


                v_Query = @"INSERT INTO DRIL2.T_MANUAL_DATA_LOG(ID_SEQ_MANUAL_DATA, DATA_RECEIVED_MOMENT, VALUE,ID_KILN) VALUES(:ID_SEQ_MANUAL_DATA,TO_Date(:DATA_RECEIVED_MOMENT, 'MM/dd/yyyy HH:MI:SS :AM'),:VALUE,:ID_KILN)";
                rowsUpdated = Execute_Non_Query_DB(v_Query, oracleParameters);

                if (rowsUpdated > 0)
                    result = "Successfull";
                else
                    result = "Failed";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                //dBQuery = null;
               // dbObj = null;
                oracleParameters = null;
            }
            return result;
        }


        private int Execute_Non_Query_DB(string sqlCommand, OracleParameter[] dbParams)
        {
            int rowsUpdated = 0;
            List<string> result_message = new List<string>();
            try
            {
                con.Close();
                // DBConnect();
                con.Open();
                if (con == null)
                    // DBConnect();
                    con.Open();
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        cmd.CommandText = sqlCommand;
                        cmd.CommandType = CommandType.Text;
                        if (dbParams != null)
                            cmd.Parameters.AddRange(dbParams);
                        rowsUpdated = cmd.ExecuteNonQuery();
                    }
            }
            catch (OracleException ex)
            {
                result_message.Add(ex.Message);
            }
            catch (Exception ex)
            {
                result_message.Add(ex.Message);
            }
            finally
            {
                con.Close();
                // DBClose();
            }
            return rowsUpdated;
        }



        public string UpdateManualData(MANUAL mANUAL)
        {



            int rowsUpdated = 0;
            string result = null;
            OracleParameter[] oracleParameters = null;

            string v_Query = string.Empty;
            try
            {

              
                oracleParameters = new OracleParameter[4];
                oracleParameters[0] = new OracleParameter(@"VALUE", mANUAL.Value);
                oracleParameters[1] = new OracleParameter(@"ID_SEQ_MANUAL_DATA", mANUAL.ID_SEQ_MANUAL_DATA);
                oracleParameters[2] = new OracleParameter(@"ID_KILN", mANUAL.ID_KILN);
                oracleParameters[3] = new OracleParameter(@"DATA_RECEIVED_MOMENT", mANUAL.date);
               
               


                v_Query = @"UPDATE DRIL2.T_MANUAL_DATA_LOG SET VALUE=:VALUE WHERE ID_SEQ_MANUAL_DATA=:ID_SEQ_MANUAL_DATA and ID_KILN=:ID_KILN and DATA_RECEIVED_MOMENT=TO_Date(:DATA_RECEIVED_MOMENT, 'MM/dd/yyyy HH:MI:SS :AM')";
                rowsUpdated = Execute_Non_Query_DB(v_Query, oracleParameters);

                if (rowsUpdated > 0)
                    result = "Successfull";
                else
                    result = "Failed";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                
                oracleParameters = null;
            }
            return result;
        }
    }
}
