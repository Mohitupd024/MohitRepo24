﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RestSharp;
using Newtonsoft.Json;
using System.Net;

namespace DRI_JODA_TDT.REST
{
    public class DRI_REST_API
    {

        internal class DRIWebAPI_Client
        {


            RestClient client;
            RestRequest request;
            RestResponse response;
            string gateway = "gateway_H";
         
            
            
            //------------------------------DEVELOPMENT 2022 WEB API--------//
            //private string ServiceUrl = "http://localhost:5243";
            //------------------------------DEVELOPMENT 2022 WEB API--------//
            ////------------------------------PRODUCTION 2022 WEB API--------//
            private string ServiceUrl = "http://10.163.30.60:11";
            ////------------------------------PRODUCTION 2022 WEB API--------//

           
            public DRIWebAPI_Client()
            {
                try
                {  
                   
                }
                catch (Exception)
                {


                }
                finally
                {
                    disConnect_rest();
                }
            }

            internal RestClient connect_rest()
            {
                try
                {
                    client = new RestClient(ServiceUrl);
                }
                catch (Exception)
                {
                    client = null;
                }
                return client;
            }

            internal RestResponse connect_rest(string resource ,Method method )
            {
                try
                {
                    client = new RestClient(ServiceUrl);
                    request = new RestRequest(resource, Method.Get);
                   
                    request.Timeout = 58888000;

                    if (request != null)
                    {
                        response = (RestResponse)client.Execute(request);
                    }
                }
                catch (Exception)
                {
                    request = null;
                }
                return response;
            }

            internal RestResponse connect_rest(string resource, Method method, Dictionary<string, string> dict = null)
            {
                try
                {
                    client = new RestClient(ServiceUrl);
                    request = new RestRequest(resource, method);
                    if (dict != null)
                    {
                        foreach (KeyValuePair<string, string> entry in dict)
                        {
                            request.AddParameter(entry.Key, entry.Value);
                        }
                    }
                   
                    request.Timeout = 5000;

                    if (request != null)
                    {
                        response = (RestResponse)client.Execute(request);
                    }
                }
                catch (Exception)
                {
                    request = null;
                }
                return response;
            }

            internal RestResponse connect_rest(string resource, Method method, Dictionary<string, string> dict = null, string jsonBody = null, Boolean headerType = false)
            {
                try
                {
                    client = new RestClient(ServiceUrl);
                    request = new RestRequest(resource, method);
                   
                    if (dict != null)
                    {
                        foreach (KeyValuePair<string, string> entry in dict)
                        {
                            request.AddHeader(entry.Key, entry.Value);
                        }
                    }
                    else if (jsonBody != null)
                        request.AddBody(jsonBody);
                    if (headerType)
                        request.AddHeader("Content-Type", "application/json");
                    request.Timeout = 5000;

                    if (request != null)
                    {
                        response = (RestResponse)client.Execute(request);

                    }
                }
                catch (Exception)
                {
                    request = null;
                }
                return response;
            }

           








            internal RestResponse connect_rest(string resource, Method method, string jsonBody)
            {
                try
                {
                    client = new RestClient(ServiceUrl);
                    request = new RestRequest(resource, method);
                    request.RequestFormat = DataFormat.Json;

                    if (!string.IsNullOrEmpty(jsonBody))
                    {
                        request.AddJsonBody(jsonBody);
                    }
                   

                    if (request != null)
                    {
                        response = client.Execute(request);
                    }
                }
                catch (Exception)
                {
                    request = null;
                }
                return response;
            }


            internal void disConnect_rest()
            {
                if (client != null)
                    //  client.;
                    client = null;
            }

           

        }
    }
}
