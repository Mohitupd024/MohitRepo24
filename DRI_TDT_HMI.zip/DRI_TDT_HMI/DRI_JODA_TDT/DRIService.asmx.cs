﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.IO;
using System.Text;
using System.Collections;
using Newtonsoft.Json;
using System.Globalization;
using DRI_JODA_TDT.MODELS;

namespace DRI_JODA_TDT
{
    /// <summary>
    /// Summary description for DRIService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
   
    public class DRIService : System.Web.Services.WebService
    {
       

      //  public static OracleConnection con = new OracleConnection("Data Source=(DESCRIPTION="
      //+ "(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=157.0.151.76)(PORT=1521)))"
      //+ "(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=millsdb)));"
      //+ "User Id=bafdba;Password=bafdba");


        public static OracleConnection con = new OracleConnection("Data Source=(DESCRIPTION="
                  + "(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=10.163.30.60)(PORT=1521)))"
                  + "(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=autdevtsbsl)));"
                  + "User Id=dril2;Password=dril22;");


        public string[] KilnLength_Kiln1 = { "0", "5", "10", "15", "20", "25", "30", "35", "40", "45", "50", "55", "60", "65", "70" };
        public string[] KilnLength_Kiln3 = { "0", "5", "10", "15", "20", "25", "30", "35", "40", "45", "50", "55", "60", "65", "70", "75" };





        [WebMethod]
        public List<ParamConfig> GetParamConfigDropDown()
        {


            OracleDataAdapter QMFeMTDA;
            DataTable QMFeMTDT = new DataTable();
            List<ParamConfig> lstdatagroup = new List<ParamConfig>();
            try
            {




                string sqlcmd = "select * from T_LOSS_LOGBOOK_PARAM_CONFIG";
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }



                QMFeMTDA = new OracleDataAdapter(sqlcmd, con);
                DataTable ds = new DataTable();
                QMFeMTDA.Fill(ds);

                if (ds.Rows.Count > 0)
                {
                    foreach (DataRow Rows in ds.Rows)
                    {
                        ParamConfig objlogbook = new ParamConfig();


                        objlogbook.PARAM_ID = Rows["PARAM_ID"] == DBNull.Value ? "" : (Rows["PARAM_ID"].ToString());
                        objlogbook.PARAM_NAME = Rows["PARAM_NAME"] == DBNull.Value ? "" : (Rows["PARAM_NAME"].ToString());
                        objlogbook.PARAM_DESC = Rows["PARAM_DESC"] == DBNull.Value ? "" : (Rows["PARAM_DESC"].ToString());

                        lstdatagroup.Add(objlogbook);

                    }


                }



            }

            catch (Exception ex)
            {

            }

            return lstdatagroup;


        }

        [WebMethod]
        public ArrayList get_3D_data()
        {
             
            ArrayList finalList = new ArrayList();
            int count = 0;
            string[] Values = { "" };

            try
            {
                //string path = @"D:\Automation_Dont_delete\Accretion_Results_Kiln1";
              // string path = @"D:\OneDrive - Tata Steel Limited\DRI PROJECT\DRI_Deploy\Kiln_2\Accretion_3D\Accretion_results";
                string path = @"E:/sushmita/textFile";
                string fileName = GetFiles(path);
                string fileWithoutExt = Path.GetFileNameWithoutExtension(fileName);
                string filePath = path + "/" + fileWithoutExt + ".txt";
                var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                using (var streamReader = new StreamReader(fileStream, Encoding.UTF8))
                {
                    string line;
                    while ((line = streamReader.ReadLine()) != null)
                    {
                        count++;
                        if (count > 10)
                        {
                            //list = new List<string>();
                            Values = line.Split(',');
                            finalList.Add(Values);
                            //for (int i = 0; i < Values.Length; i++)
                            //    list.Add(Values[i]);
                        }

                    }
                }

                

                return finalList;
            }
            catch (Exception ex)
            {
                finalList = null;
                return finalList;
            }
            finally
            {
                finalList = null;
            }

        }

        // ==========================================================================

        private static string GetFiles(string path)
        {
            var file = new DirectoryInfo(path).GetFiles().OrderByDescending(o => o.LastWriteTime).FirstOrDefault();
            return file.Name;
        }


        //==========================================================================
          [WebMethod]
        public ArrayList getReportData(string KILN ,string FromDate,string ToDate,string Selection)
        {
            ArrayList objAllData = new ArrayList();
            string sql = "";
            string tblName = "";
            //if (KILN == "1")
            //{
            //    if (Selection == "pr_Para")
            //    tblName = getInputTableName(KILN);
            //    else  if (Selection == "Mo_Out")
            //        tblName = "T_FEM_OUTPUT_KILN_1";
            //}
            //if (KILN == "2")
            //{
            //    if (Selection == "pr_Para")
            //    tblName = getInputTableName(KILN);
            //    else  if (Selection == "Mo_Out")
            //        tblName = "T_FEM_OUTPUT_KILN_1";
            //}
            if (KILN == "5" || KILN=="3" || KILN=="4" || KILN=="6" || KILN=="1" || KILN=="2")
            {
                if (Selection == "pr_Para")
                    tblName = getInputTableName(KILN);
                else if (Selection == "Mo_Out")
                    //tblName = "T_FEM_OUTPUT_KILN_1";
                    tblName = "T_KILN56_OUTPUT";
            }
            OracleDataAdapter QMCPDA;
            DataTable QMCPDT = new DataTable();
            List<T_JKI_CLASS> finalValues = new List<T_JKI_CLASS>();
            List<string> reportData = new List<string>();

           // sql = "select * from " + tblName + " where run_time between sysdate-1 and sysdate order by run_time asc";
            if (Selection == "pr_Para")       
                sql = "select RUN_TIME, ID_KILN, FE_FEED, FEEDCOAL, DOLO, FINECOAL, P_INLET, P_OUTLET, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, PRIM_AIR, SAB1, SAB2, SAB3, SAB4, SAB5, SAB6, SAB7, SAB8, MPS_ORE, MPS_FC, MPS_IC, RPM, ORE_LOI, ORE_MOIST, ORE_FETOTAL, ORE_SILICA, ORE_ALIMINA, FC_MC, FC_VM, FC_ASH, FC_FIXEDCARBON, IC_MC, IC_VM, IC_ASH, IC_FIXEDCARBON, FC_SUL, IC_SUL, DOLO_CACO3, DOLO_MGCO3, DOLO_MC, DOLO_SIO2, DOLO_FE2O3, DOLO_AL2O3, FEM_ACT, SUL_LUMP_ACT, SUL_FINE_ACT from " + tblName + " where run_time <=to_date('" + ToDate + "','yyyy-MM-dd') and run_time > to_date('" + FromDate + "','yyyy-MM-dd') AND ID_KILN = " + KILN + " order by run_time asc";

            else if (Selection == "Mo_Out")
                sql = "select * from " + tblName + " where TIME_STAMP <=to_date('" + ToDate + "','yyyy-MM-dd') and TIME_STAMP >= to_date('" + FromDate + "','yyyy-MM-dd') order by TIME_STAMP asc";
            if (con.State != ConnectionState.Open)
            {
                con.Open();
            }
            string JSONData = "";
            // Adapter & Data Table
            QMCPDA = new OracleDataAdapter(sql, con);
            QMCPDA.Fill(QMCPDT);






            if (QMCPDT.Rows.Count > 0)
            {
                JSONData = JsonConvert.SerializeObject(QMCPDT);
            }

            objAllData.Add(JSONData);
            QMCPDA.Dispose();
            return objAllData;
        }
        //==================================== FUNCTION FOR GETTING CONTROLLABLE PARAMETERS DATA ======================================
          [WebMethod]
          public List<FemValue> getFemVsTime(string KILN, string FromDate, string ToDate)// graph 1
          {
              List<FemValue> finalQMFeMTData = new List<FemValue>();
              finalQMFeMTData = QMFeMvsTime(KILN, FromDate, ToDate);
              return finalQMFeMTData;
          }
         [WebMethod]
          public List<GraphValue> getSulphurVsTime(string KILN, string FromDate, string ToDate)
          {
              List<GraphValue> finalSulphurData = new List<GraphValue>();
              finalSulphurData = GetSulphurData(KILN, FromDate, ToDate);
              return finalSulphurData;
          }

          [WebMethod]
           public List<GraphValue> getCharVsTime(string KILN, string FromDate, string ToDate) // graph 3
          {
              List<GraphValue> finalCharData = new List<GraphValue>();
              finalCharData = GetCharData(KILN, FromDate, ToDate);
              return finalCharData;
           }

        //[WebMethod]
        //public List<MANUAL> GetManualData(string KILN, string Date)
        //{
        //    List<MANUAL> finalMANUALData = new List<MANUAL>();
        //    //finalQMFeMTData = QMFeMvsTime(KILN, FromDate, ToDate);





        //    return finalMANUALData;



        //}





        //[WebMethod]
        //public List<GraphValue> getBedHeightVsTime(string KILN, string FromDate, string ToDate)
        //{
        //    List<GraphValue> finalBedHeightData = new List<GraphValue>();
        //    finalBedHeightData = GetBedHeightData(KILN, FromDate, ToDate);
        //    return finalBedHeightData;
        //}


        // [WebMethod]
        //public List<GraphValue> getCOCO2VsTime(string KILN, string FromDate, string ToDate)
        //{
        //    List<GraphValue> finalCOCO2Data = new List<GraphValue>();
        //    finalCOCO2Data = GetCoCo2Data(KILN);
        //    return finalCOCO2Data;
        //}


        [WebMethod(EnableSession = true)]
        public ArrayList QMcontrollablePara(string KILN ,string FromDate,string ToDate ,string FromDateSul,string ToDateSul)
        {
            
            ArrayList objFinal = new ArrayList();

         
            if (Session["user"]==null)
            
            {

                objFinal = null;
                return objFinal;

            }    
                  
            try
            {
                string currentuser = Session["user"].ToString();
                ArrayList ParamList = getControllableParamValues(KILN);
                List<ParamVsLength> lstvalues = new List<ParamVsLength>();
                lstvalues = FemVsKilnLength(KILN);
                List<pressureValue> lstPressure = new List<pressureValue>();
                lstPressure = getPressureData(KILN);
                List<FemValue> lstFemValue = new List<FemValue>();

                //-------------------------------GRAPH 1 FEM VS TIME--------//

                lstFemValue = QMFeMvsTime(KILN, FromDate, ToDate); // 1st graph
               //-------------------------------GRAPH 1 FEM VS TIME--------//
                ArrayList BedHeightList = new ArrayList();
                BedHeightList = BedHeightVsKilnLength(KILN);
                ArrayList fillingDegreeList = new ArrayList();
               fillingDegreeList = FillingDegreeVsKilnLength(KILN);
                List<GraphValue> lstSulphurValue = new List<GraphValue>();
                lstSulphurValue = GetSulphurData(KILN, FromDateSul, ToDateSul);
                List<GraphValue> lstCharValue = new List<GraphValue>();
                lstCharValue = GetCharData(KILN, FromDateSul, ToDateSul);
                ArrayList lstCarbonAvail = new ArrayList();
                lstCarbonAvail = CarbonAvailabilityVsKilnLength(KILN);
                List<GraphValue> lstBedHeightValue = new List<GraphValue>();
               //lstBedHeightValue = GetBedHeightData(KILN, FromDate, ToDate);

                ArrayList lstCoCo2Value = new ArrayList();
                lstCoCo2Value = GetCoCo2Data(KILN);

                objFinal.Add(ParamList); // 1st table
                objFinal.Add(lstvalues); 
                objFinal.Add(lstPressure);
                objFinal.Add(lstFemValue);// 1st graph


                objFinal.Add(lstSulphurValue); // 2 nd graph 
                objFinal.Add(lstCharValue); // 3rd graph

                objFinal.Add(BedHeightList);
                objFinal.Add(fillingDegreeList);
                objFinal.Add(lstCoCo2Value);
                objFinal.Add(lstCarbonAvail);
            }
            catch (Exception ex)
            {

                throw;
            }
            return objFinal;

        }
        //============================================================== ENDS ============================================================
        public ArrayList getControllableParamValues(string KILN)
        {
            ArrayList finalList = new ArrayList();
            try
             {
                string sql = ""; string sql_Kiln3 = "";
                string tblName = getInputTableName(KILN);

                OracleDataAdapter QMCPDA;
                DataTable QMCPDT = new DataTable();
                List<T_JKI_CLASS> paramValues = new List<T_JKI_CLASS>();
                sql_Kiln3 ="select PRIM_AIR,SAB1,SAB2,SAB3,SAB4,SAB5,SAB6,SAB7,SAB8,RPM,FEEDCOAL,FINECOAL,FE_FEED,DOLO,PRIM_AIR_SET,RPM_SET,FE_FEED_SET,FEEDCOAL_SET,finecoal_set from " + tblName + " where run_time >= (select max(run_time) from " + tblName + ") and ID_KILN = " + KILN + "";
                
                //sql = "select PRIM_AIR,SAB2,SAB3,SAB4,SAB5,SAB6,SAB7,SAB8,SAB9,SAB10,RPM,FEEDCOAL,FINECOAL,FE_FEED,DOLO,PRIM_AIR_SET,RPM_SET,FE_FEED_SET,FEEDCOAL_SET,finecoal_set from " + tblName + " where run_time >= (select max(run_time) from " + tblName + ")";
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                //if (KILN == "5" || KILN=="6" || KILN=="3" || KILN=="4" || KILN="1" || KILN="2") //kiln 3 Changed 5 and 1 to 6!
                    QMCPDA = new OracleDataAdapter(sql_Kiln3, con);
                
                    QMCPDA = new OracleDataAdapter(sql_Kiln3, con);
                QMCPDA.Fill(QMCPDT);
                QMCPDA.Dispose();

                if (QMCPDT.Rows.Count > 0)
                {
                    foreach (DataRow Rows in QMCPDT.Rows)
                    {
                        T_JKI_CLASS obj = new T_JKI_CLASS();
                        obj.PAB_AirFlow = Rows["PRIM_AIR"] == DBNull.Value ? "0" : Rows["PRIM_AIR"].ToString();
                       
                        obj.SAB2_AirFlow = Rows["SAB2"] == DBNull.Value ? "0" : Rows["SAB2"].ToString();
                        obj.SAB3_AirFlow = Rows["SAB3"] == DBNull.Value ? "0" : Rows["SAB3"].ToString();
                        obj.SAB4_AirFlow = Rows["SAB4"] == DBNull.Value ? "0" : Rows["SAB4"].ToString();
                        obj.SAB5_AirFlow = Rows["SAB5"] == DBNull.Value ? "0" : Rows["SAB5"].ToString();
                        obj.SAB6_AirFlow = Rows["SAB6"] == DBNull.Value ? "0" : Rows["SAB6"].ToString();
                        obj.SAB7_AirFlow = Rows["SAB7"] == DBNull.Value ? "0" : Rows["SAB7"].ToString();
                        obj.SAB8_AirFlow = Rows["SAB8"] == DBNull.Value ? "0" : Rows["SAB8"].ToString();
                        //if (KILN == "1" || KILN == "2")
                        //{
                        //    obj.SAB9_AirFlow = Rows["SAB9"] == DBNull.Value ? "0" : Rows["SAB9"].ToString();
                        //    obj.SAB10_AirFlow = Rows["SAB10"] == DBNull.Value ? "0" : Rows["SAB10"].ToString();
                        //}
                        //else
                        //{
                           obj.SAB1_AirFlow = Rows["SAB1"] == DBNull.Value ? "0" : Rows["SAB1"].ToString();
                        //}
                       double KILN_RPM = Rows["RPM"] == DBNull.Value ? 0 : Math.Round(Convert.ToDouble(Rows["RPM"]), 2);
                      // double KILN_RPM = Rows["RPM_SET"] == DBNull.Value ? 0 : Math.Round(Convert.ToDouble(Rows["RPM_SET"]), 2);
                        obj.KILN_RPM = KILN_RPM.ToString();
                        double FeedCoalRate = Rows["FEEDCOAL"] == DBNull.Value ? 0 : Math.Round(Convert.ToDouble(Rows["FEEDCOAL"]), 2);
                        obj.FeedCoalRate= FeedCoalRate.ToString();

                        // obj.FeedCoalRate = Rows["FEEDCOAL"] == DBNull.Value ? "0" : Rows["FEEDCOAL"].ToString();

                        double InjectionCoalRate = Rows["FINECOAL"] == DBNull.Value ? 0 : Math.Round(Convert.ToDouble(Rows["FINECOAL"]), 2);
                        obj.InjectionCoalRate = InjectionCoalRate.ToString();


                        // obj.InjectionCoalRate = Rows["FINECOAL"] == DBNull.Value ? "0" : Rows["FINECOAL"].ToString();

                        double IronOreFeedRate = Rows["FE_FEED"] == DBNull.Value ? 0 : Math.Round(Convert.ToDouble(Rows["FE_FEED"]), 2);
                        obj.IronOreFeedRate = IronOreFeedRate.ToString();


                        //obj.IronOreFeedRate = Rows["FE_FEED"] == DBNull.Value ? "0" : Rows["FE_FEED"].ToString();

                        double DolomiteFeedRate = Rows["DOLO"] == DBNull.Value ? 0 : Math.Round(Convert.ToDouble(Rows["DOLO"]), 2);
                        obj.DolomiteFeedRate = DolomiteFeedRate.ToString();

                        //obj.DolomiteFeedRate = Rows["DOLO"] == DBNull.Value ? "0" : Rows["DOLO"].ToString();

                        obj.PRIM_AIR_SET = Rows["PRIM_AIR_SET"] == DBNull.Value ? "0" : Rows["PRIM_AIR_SET"].ToString();
                        obj.RPM_SET = Rows["RPM_SET"] == DBNull.Value ? "0" : Rows["RPM_SET"].ToString();
                        obj.FE_FEED_SET = Rows["FE_FEED_SET"] == DBNull.Value ? "0" : Rows["FE_FEED_SET"].ToString();
                        obj.FEEDCOAL_SET = Rows["FEEDCOAL_SET"] == DBNull.Value ? "0" : Rows["FEEDCOAL_SET"].ToString();
                        obj.FINECOAL_SET = Rows["FINECOAL_SET"] == DBNull.Value ? "0" : Rows["FINECOAL_SET"].ToString();
                       // obj.INJ_AIR_FLOW1 = Rows["INJ_AIR_FLOW1"] == DBNull.Value ? "0" : Rows["INJ_AIR_FLOW1"].ToString();
                       // obj.INJ_AIR_FLOW2 = Rows["INJ_AIR_FLOW2"] == DBNull.Value ? "0" : Rows["INJ_AIR_FLOW2"].ToString();
                        paramValues.Add(obj);
                    }
                    finalList.Add(paramValues);
                    finalList.Add(getL2RecommendationValues(KILN));
                }
                return finalList;
            }
            catch(Exception ex)
            { return null; }
        }
        public List<T_JKI_CLASS> getL2RecommendationValues(string KILN)
        {          
            try
            {
                string sql = "";  string sql2 = "";
                string tableName = getOuputTableName(KILN);             
                OracleDataAdapter QMCPDA;
                DataTable QMCPDT = new DataTable();
                DataTable ReccmDs = new DataTable();
                List<T_JKI_CLASS> paramValues = new List<T_JKI_CLASS>();               
                sql = "Select SAB1,SAB2,SAB3,SAB4,SAB5,SAB6,SAB7,SAB8,SAB9,RPM,FEED_COAL,INJ_COAL,FE_FEED,DOLOMITE,PA ,back_flow,back_flow_t,c_fe_ref "+
                "from T_KILN_OPTIMIZATION where prod_centre = "+ KILN + " and date_time = (select max(date_time) from T_KILN_OPTIMIZATION where prod_centre = "+ KILN + ")";
                sql2 = "select C_FE_RATIO From "+ tableName + " Where TIME_STAMP= (select max(TIME_STAMP) from "+ tableName + ")";

                if (con.State != ConnectionState.Open)
                {  con.Open();  }
              
                QMCPDA = new OracleDataAdapter(sql, con);
                QMCPDA.Fill(QMCPDT);
                QMCPDA.Dispose();
                QMCPDA = new OracleDataAdapter(sql2, con);
                QMCPDA.Fill(ReccmDs);
                QMCPDA.Dispose();

                if (QMCPDT.Rows.Count > 0)
                {
                    foreach (DataRow Rows in QMCPDT.Rows)
                    {
                        T_JKI_CLASS obj = new T_JKI_CLASS();
                        obj.PAB_AirFlow = Rows["PA"] == DBNull.Value ? "0" : Rows["PA"].ToString();
                        obj.SAB1_AirFlow = Rows["SAB1"] == DBNull.Value ? "0" : Rows["SAB1"].ToString();
                        obj.SAB2_AirFlow = Rows["SAB2"] == DBNull.Value ? "0" : Rows["SAB2"].ToString();
                        obj.SAB3_AirFlow = Rows["SAB3"] == DBNull.Value ? "0" : Rows["SAB3"].ToString();
                        obj.SAB4_AirFlow = Rows["SAB4"] == DBNull.Value ? "0" : Rows["SAB4"].ToString();
                        obj.SAB5_AirFlow = Rows["SAB5"] == DBNull.Value ? "0" : Rows["SAB5"].ToString();
                        obj.SAB6_AirFlow = Rows["SAB6"] == DBNull.Value ? "0" : Rows["SAB6"].ToString();
                        obj.SAB7_AirFlow = Rows["SAB7"] == DBNull.Value ? "0" : Rows["SAB7"].ToString();
                        obj.SAB8_AirFlow = Rows["SAB8"] == DBNull.Value ? "0" : Rows["SAB8"].ToString();
                        if (!(KILN=="5"))
                        {                        
                            obj.SAB9_AirFlow = Rows["SAB9"] == DBNull.Value ? "0" : Rows["SAB9"].ToString();
                        }
                        
                          
                        obj.KILN_RPM = Rows["RPM"] == DBNull.Value ? "0" : Rows["RPM"].ToString();
                        obj.FeedCoalRate = Rows["FEED_COAL"] == DBNull.Value ? "0" : Rows["FEED_COAL"].ToString();
                        obj.InjectionCoalRate = Rows["INJ_COAL"] == DBNull.Value ? "0" : Rows["INJ_COAL"].ToString();
                        obj.IronOreFeedRate = Rows["FE_FEED"] == DBNull.Value ? "0" : Rows["FE_FEED"].ToString();
                        obj.DolomiteFeedRate = Rows["DOLOMITE"] == DBNull.Value ? "0" : Rows["DOLOMITE"].ToString();
                      
                        obj.BackFlow = Rows["back_flow"] == DBNull.Value ? "0" : Rows["back_flow"].ToString();
                        obj.BackFlow_Ref = Rows["back_flow_t"] == DBNull.Value ? "0" : Rows["back_flow_t"].ToString();
                        obj.C_FE_REF = Rows["c_fe_ref"] == DBNull.Value ? "0" : Rows["c_fe_ref"].ToString();
                        if (ReccmDs.Rows.Count > 0)
                        { obj.C_FE = ReccmDs.Rows[0]["C_FE_RATIO"] == DBNull.Value ? "0" : ReccmDs.Rows[0]["C_FE_RATIO"].ToString(); }

                        paramValues.Add(obj);
                    }
                }
                return paramValues;
            }
            catch (Exception ex)
            { return null; }
        }
        public List<GraphValue> GetSulphurData(string KILN, string FromDate, string ToDate)
        {
            List<GraphValue> lstSulphurValue = new List<GraphValue>();
            DataTable dsSulphur = new DataTable();
            string sqlcmd = "";

                string fromDate = FromDate.Replace('T', ' ');
            string toDate = ToDate.Replace('T', ' ');

            OracleDataAdapter QMFeMTDA;
            DataTable QMFeMTDT = new DataTable();
            List<GraphValue> finalSulpherData = new List<GraphValue>();
            // DataTable QMFeMTDT2 = new DataTable();
            // DataTable matchedRows = new DataTable();

            try
            {
                // double[] timePredictedValues = new double[6];
                //double FE_M_SIX_Value = 0; double FE_M_FIVE_Value = 0; double FE_M_FOUR_Value = 0; double FE_M_THREE_Value = 0; double FE_M_TWO_Value = 0; double FE_M_ONE_Value = 0;
                //string sql = "Select " + date_time + " , " + FemActual + "," + FemPredicted + " from " + tblName + " WHERE " + date_time + " >=TO_DATE('" + fromDate + "','yyyy-MM-dd HH24:MI') and " + date_time + " <=TO_DATE('" + toDate + "','yyyy-MM-dd HH24:MI') ORDER BY " + date_time + " ASC  ";
                // string sql = "select DATE_TIME,FE_M_LUMPS,FEM_PRED_CORR,PROD_CENTRE from T_FEM_CORR_KILN Where prod_centre="+KILN+ " and date_time >= TO_DATE('" + fromDate + "', 'yyyy-MM-dd HH24:MI') and date_time <= TO_DATE('" + toDate + "', 'yyyy-MM-dd HH24:MI') order by date_time";
                // string sql2 = "select FE_M_ONE,FE_M_TWO,FE_M_THREE,FE_M_FOUR,FE_M_FIVE,FE_M_SIX From T_KILN_FUTURE where PROD_CENTRE = " + KILN + " and date_time=(select max(date_time) from T_KILN_FUTURE where PROD_CENTRE = " + KILN + ")";
                if (KILN == "5" || KILN == "6")
                {
                    sqlcmd = "SELECT TIME_STAMP,SU1,SUL_FINE_ACT,SUL_LUMP_ACT FROM t_kiln56_output WHERE ID_KILN = " + KILN + " and   TIME_STAMP  >= TO_DATE('" + fromDate + "', 'yyyy-MM-dd HH24:MI') and TIME_STAMP <= TO_DATE('" + toDate + "', 'yyyy-MM-dd HH24:MI') order by TIME_STAMP";
                }
                if (KILN == "3" || KILN == "4")
                {
                    sqlcmd = "SELECT TIME_STAMP,SU1,SUL_FINE_ACT,SUL_LUMP_ACT FROM t_kiln34_output WHERE ID_KILN = " + KILN + " and   TIME_STAMP  >= TO_DATE('" + fromDate + "', 'yyyy-MM-dd HH24:MI') and TIME_STAMP <= TO_DATE('" + toDate + "', 'yyyy-MM-dd HH24:MI') order by TIME_STAMP";
                }


                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }

                QMFeMTDA = new OracleDataAdapter(sqlcmd, con);
                DataTable ds = new DataTable();
                QMFeMTDA.Fill(ds);

                if (ds.Rows.Count > 0)
                {
                    foreach (DataRow Rows in ds.Rows)
                    {
                        GraphValue obj = new GraphValue();
                        DateTime date = Rows["TIME_STAMP"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(Rows["TIME_STAMP"].ToString());
                        obj.TIME_STAMP = date.ToString("dd MMM HH: mm");

                        obj.SU1 = Rows["SU1"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["SU1"].ToString());
                        obj.SUL_FINE_ACT = Rows["SUL_FINE_ACT"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["SUL_FINE_ACT"].ToString());
                        obj.SUL_LUMP_ACT = Rows["SUL_LUMP_ACT"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["SUL_LUMP_ACT"].ToString());

                        finalSulpherData.Add(obj);

                    }


                }
            }













            //string sql = "Select DATE_TIME, ACT_VALUE, PRED_VALUE from T_KILN_CHAR_S WHERE ID=103 and prod_centre=" + KILN + " AND DATE_TIME >=TO_DATE('" + fromDate + "','yyyy-MM-dd HH24:MI') and DATE_TIME <=TO_DATE('" + toDate + "','yyyy-MM-dd HH24:MI') ORDER BY DATE_TIME ASC  ";
            //string sql2 = "select C_CHAR_SIX From T_KILN_FUTURE where PROD_CENTRE = " + KILN + " and date_time=(select max(date_time) from T_KILN_FUTURE where PROD_CENTRE = " + KILN + ")";

            //if (con.State != ConnectionState.Open)
            //{
            //    con.Open();
            //}
            //OracleDataAdapter orcDA = new OracleDataAdapter(sql2, con);
            //DataSet ds = new DataSet();
            //orcDA.Fill(ds);
            //if (ds.Tables[0].Rows.Count > 0)
            //{
            //    CHAR_SIX_Value = ds.Tables[0].Rows[0]["C_CHAR_SIX"] == DBNull.Value ? 0.0 : Convert.ToDouble(ds.Tables[0].Rows[0]["C_CHAR_SIX"].ToString());
            //}
            //// Adapter & Data Table
            //orcDA = new OracleDataAdapter(sql, con);
            //orcDA.Fill(dsChar);
            //orcDA.Dispose();
            //if (dsChar.Rows.Count > 0)
            //{
            //    DateTime maxTime = Convert.ToDateTime(dsChar.Rows[dsChar.Rows.Count - 1]["DATE_TIME"].ToString());
            //    foreach (DataRow row in dsChar.Rows)
            //    {
            //        GraphValue objData = new GraphValue();
            //        DateTime date = row["DATE_TIME"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(row["DATE_TIME"].ToString());
            //        objData.TIME_STAMP = date.ToString("dd MMM HH:mm");
            //        objData.ActualValue = row["ACT_VALUE"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["ACT_VALUE"].ToString());
            //        objData.PredictedValue = row["PRED_VALUE"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["PRED_VALUE"].ToString());
            //        lstCharValue.Add(objData);
            //    }
            //    GraphValue obj = new GraphValue();
            //    obj.TIME_STAMP = maxTime.AddHours(6).ToString("dd MMM HH:mm");
            //    obj.PredictedValue = CHAR_SIX_Value;
            //    lstCharValue.Add(obj);
            //}
            //}
            catch (Exception ex)
            {
                
            
            }






            //string fromDate = FromDate.Replace('T', ' ');
            //string toDate = ToDate.Replace('T', ' ');
            //double SUL_SIX_Value = 0;
            //string sql = "Select DATE_TIME, ACT_VALUE, PRED_VALUE from T_KILN_CHAR_S WHERE ID=102 and prod_centre="+ KILN + " AND DATE_TIME >=TO_DATE('" + fromDate + "','yyyy-MM-dd HH24:MI') and DATE_TIME <=TO_DATE('" + toDate + "','yyyy-MM-dd HH24:MI') ORDER BY DATE_TIME ASC  ";
            //string sql2 = "select DATE_TIME, SUL_SIX From T_KILN_FUTURE where PROD_CENTRE = "+ KILN+ " and date_time=(select max(date_time) from T_KILN_FUTURE where PROD_CENTRE = "+KILN +")";

            //if (con.State != ConnectionState.Open)
            //{
            //    con.Open();
            //}
            //OracleDataAdapter orcDA = new OracleDataAdapter(sql2, con);
            //DataSet ds = new DataSet();
            //orcDA.Fill(ds);
            //if (ds.Tables[0].Rows.Count > 0)
            //{
            //    SUL_SIX_Value = ds.Tables[0].Rows[0]["SUL_SIX"] == DBNull.Value ? 0.0 : Convert.ToDouble(ds.Tables[0].Rows[0]["SUL_SIX"].ToString());
            //}

            //orcDA = new OracleDataAdapter(sql, con);
            //orcDA.Fill(dsSulphur);
            //orcDA.Dispose();
            //if (dsSulphur.Rows.Count > 0)
            //{
            //    DateTime maxTime = Convert.ToDateTime(dsSulphur.Rows[dsSulphur.Rows.Count - 1]["DATE_TIME"].ToString());
            //    foreach (DataRow row in dsSulphur.Rows)
            //    {
            //        GraphValue objData = new GraphValue();                     
            //        DateTime date = row["DATE_TIME"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(row["DATE_TIME"].ToString());
            //        objData.TIME_STAMP = date.ToString("dd MMM HH:mm");
            //        objData.ActualValue = row["ACT_VALUE"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["ACT_VALUE"].ToString());
            //        objData.PredictedValue = row["PRED_VALUE"] ==DBNull.Value ? 0.0 : Convert.ToDouble(row["PRED_VALUE"].ToString());
            //       // objData.ActualValue2 =row["PRED_SUL"]== DBNull.Value ? 0.0 : Convert.ToDouble(row["ACT_SUL_FINES"].ToString());
            //        lstSulphurValue.Add(objData);                    
            //    }
            //    GraphValue obj = new GraphValue();
            //    obj.TIME_STAMP = maxTime.AddHours(6).ToString("dd MMM HH:mm");
            //    obj.PredictedValue = SUL_SIX_Value;
            //    lstSulphurValue.Add(obj);
            //}


            return finalSulpherData;
        }
            
         
        public List<GraphValue> GetCharData(string KILN, string FromDate, string ToDate) //graph 3
        {
            List<GraphValue> lstCharValue = new List<GraphValue>();
            DataTable dsChar = new DataTable();
            string fromDate = FromDate.Replace('T', ' ');
            string toDate = ToDate.Replace('T', ' ');
            string sqlcmd = "";
            OracleDataAdapter QMFeMTDA;
            DataTable QMFeMTDT = new DataTable();
            // DataTable QMFeMTDT2 = new DataTable();
            // DataTable matchedRows = new DataTable();
            List<GraphValue> finallstCarbonChar = new List<GraphValue>();
            try
            {
                // double[] timePredictedValues = new double[6];
                //double FE_M_SIX_Value = 0; double FE_M_FIVE_Value = 0; double FE_M_FOUR_Value = 0; double FE_M_THREE_Value = 0; double FE_M_TWO_Value = 0; double FE_M_ONE_Value = 0;
                //string sql = "Select " + date_time + " , " + FemActual + "," + FemPredicted + " from " + tblName + " WHERE " + date_time + " >=TO_DATE('" + fromDate + "','yyyy-MM-dd HH24:MI') and " + date_time + " <=TO_DATE('" + toDate + "','yyyy-MM-dd HH24:MI') ORDER BY " + date_time + " ASC  ";
                // string sql = "select DATE_TIME,FE_M_LUMPS,FEM_PRED_CORR,PROD_CENTRE from T_FEM_CORR_KILN Where prod_centre="+KILN+ " and date_time >= TO_DATE('" + fromDate + "', 'yyyy-MM-dd HH24:MI') and date_time <= TO_DATE('" + toDate + "', 'yyyy-MM-dd HH24:MI') order by date_time";
                // string sql2 = "select FE_M_ONE,FE_M_TWO,FE_M_THREE,FE_M_FOUR,FE_M_FIVE,FE_M_SIX From T_KILN_FUTURE where PROD_CENTRE = " + KILN + " and date_time=(select max(date_time) from T_KILN_FUTURE where PROD_CENTRE = " + KILN + ")";
                if (KILN == "5" || KILN == "6")
                {
                    sqlcmd = "SELECT TIME_STAMP,C1 FROM t_kiln56_output WHERE ID_KILN = " + KILN + " and   TIME_STAMP  >= TO_DATE('" + fromDate + "', 'yyyy-MM-dd HH24:MI') and TIME_STAMP <= TO_DATE('" + toDate + "', 'yyyy-MM-dd HH24:MI') order by TIME_STAMP";
                }

                if (KILN == "3" || KILN == "4")
                {
                    sqlcmd = "SELECT TIME_STAMP,C1 FROM t_kiln34_output WHERE ID_KILN = " + KILN + " and   TIME_STAMP  >= TO_DATE('" + fromDate + "', 'yyyy-MM-dd HH24:MI') and TIME_STAMP <= TO_DATE('" + toDate + "', 'yyyy-MM-dd HH24:MI') order by TIME_STAMP";
                }
                if (KILN == "1" || KILN == "2")
                {
                    sqlcmd = "SELECT TIME_STAMP,C1 FROM t_kiln12_output WHERE ID_KILN = " + KILN + " and   TIME_STAMP  >= TO_DATE('" + fromDate + "', 'yyyy-MM-dd HH24:MI') and TIME_STAMP <= TO_DATE('" + toDate + "', 'yyyy-MM-dd HH24:MI') order by TIME_STAMP";
                }


                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }

                QMFeMTDA = new OracleDataAdapter(sqlcmd, con);
                DataTable ds = new DataTable();
                QMFeMTDA.Fill(ds);

                if (ds.Rows.Count > 0)
                {
                    foreach (DataRow Rows in ds.Rows)
                    {
                        GraphValue obj = new GraphValue();
                        DateTime date = Rows["TIME_STAMP"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(Rows["TIME_STAMP"].ToString());
                        obj.TIME_STAMP = date.ToString("dd MMM HH: mm");
                        //obj.RUN_TIME = Rows["RUN_TIME"].ToString();
                        obj.C1 = Rows["C1"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["C1"].ToString());
                       // obj.FEM16 = Rows["FEM16"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["FEM16"].ToString());
                        finallstCarbonChar.Add(obj);
                    }
                }













                //string sql = "Select DATE_TIME, ACT_VALUE, PRED_VALUE from T_KILN_CHAR_S WHERE ID=103 and prod_centre=" + KILN + " AND DATE_TIME >=TO_DATE('" + fromDate + "','yyyy-MM-dd HH24:MI') and DATE_TIME <=TO_DATE('" + toDate + "','yyyy-MM-dd HH24:MI') ORDER BY DATE_TIME ASC  ";
                //string sql2 = "select C_CHAR_SIX From T_KILN_FUTURE where PROD_CENTRE = " + KILN + " and date_time=(select max(date_time) from T_KILN_FUTURE where PROD_CENTRE = " + KILN + ")";

                //if (con.State != ConnectionState.Open)
                //{
                //    con.Open();
                //}
                //OracleDataAdapter orcDA = new OracleDataAdapter(sql2, con);
                //DataSet ds = new DataSet();
                //orcDA.Fill(ds);
                //if (ds.Tables[0].Rows.Count > 0)
                //{
                //    CHAR_SIX_Value = ds.Tables[0].Rows[0]["C_CHAR_SIX"] == DBNull.Value ? 0.0 : Convert.ToDouble(ds.Tables[0].Rows[0]["C_CHAR_SIX"].ToString());
                //}
                //// Adapter & Data Table
                //orcDA = new OracleDataAdapter(sql, con);
                //orcDA.Fill(dsChar);
                //orcDA.Dispose();
                //if (dsChar.Rows.Count > 0)
                //{
                //    DateTime maxTime = Convert.ToDateTime(dsChar.Rows[dsChar.Rows.Count - 1]["DATE_TIME"].ToString());
                //    foreach (DataRow row in dsChar.Rows)
                //    {
                //        GraphValue objData = new GraphValue();
                //        DateTime date = row["DATE_TIME"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(row["DATE_TIME"].ToString());
                //        objData.TIME_STAMP = date.ToString("dd MMM HH:mm");
                //        objData.ActualValue = row["ACT_VALUE"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["ACT_VALUE"].ToString());
                //        objData.PredictedValue = row["PRED_VALUE"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["PRED_VALUE"].ToString());
                //        lstCharValue.Add(objData);
                //    }
                //    GraphValue obj = new GraphValue();
                //    obj.TIME_STAMP = maxTime.AddHours(6).ToString("dd MMM HH:mm");
                //    obj.PredictedValue = CHAR_SIX_Value;
                //    lstCharValue.Add(obj);
                //}
            }
            catch (Exception ex)
            {
            }
            return finallstCarbonChar;
        }
        
        //public List<GraphValue> GetBedHeightData(string KILN, string FromDate, string ToDate)
        //{
        //    List<GraphValue> lstBedHeightValue = new List<GraphValue>();
        //    DataSet dsBedHeight = new DataSet();
        //    try
        //    {
        //        String fromDate = FromDate.Replace('T', ' ');
        //        String toDate = ToDate.Replace('T', ' ');
        //        string sql = "Select TIME_STAMP,D15 from T_KILN1_OUTPUT WHERE TIME_STAMP >=TO_DATE('" + fromDate + "','yyyy-MM-dd HH24:MI') and TIME_STAMP <=TO_DATE('" + toDate + "','yyyy-MM-dd HH24:MI') ORDER BY TIME_STAMP ASC  ";


        //        if (con.State != ConnectionState.Open)
        //        {
        //            con.Open();
        //        }
        //        // Adapter & Data Table
        //        OracleDataAdapter orcDA = new OracleDataAdapter(sql, con);
        //        orcDA.Fill(dsBedHeight);
        //        orcDA.Dispose();
        //        if (dsBedHeight.Tables[0].Rows.Count > 0)
        //        {
        //            foreach (DataRow row in dsBedHeight.Tables[0].Rows)
        //            {
        //                GraphValue objData = new GraphValue();
        //                DateTime date = row["TIME_STAMP"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(row["TIME_STAMP"].ToString());
        //                objData.TIME_STAMP = date.ToString("dd MMM HH:mm");
        //                objData.PredictedValue = row["D15"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["D15"].ToString());
        //                lstBedHeightValue.Add(objData);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    return lstBedHeightValue;
        //}
        public ArrayList GetCoCo2Data(string KILN)
        {
            string[] length;
            if (KILN == "1" || KILN == "2")
                length = KilnLength_Kiln1;
            else
                length = KilnLength_Kiln3;

            string sql = ""; string sql_avg = "";
            List<ParamVsLength> lstCoCo2Value = new List<ParamVsLength>();
            List<ParamVsLength> lstCoCo2AVGValue = new List<ParamVsLength>();
            DataTable dsCOcO2 = new DataTable();
            string tblName = getOuputTableName(KILN);

            ArrayList finalList = new ArrayList();
            try
            {
                if(KILN=="1" || KILN=="2")
                {
                    sql = "select TIME_STAMP,co_co215,co_co214,co_co213,co_co212,co_co211,co_co210,co_co29,co_co28,co_co27,co_co26,co_co25,co_co24,co_co23,co_co22,co_co21 from " + tblName + " where TIME_STAMP= (select max(TIME_STAMP) from " + tblName + ")";

                    sql_avg = "select  Round(AVG(c15),2),ROUND(AVG(c14),2), ROUND(AVG(c13),2),ROUND(AVG(c12),2),ROUND(AVG(c11),2),ROUND(AVG(c10),2),ROUND(AVG(c9),2),ROUND(AVG(c8),2),ROUND(AVG(c7),2),ROUND(AVG(c6),2),ROUND(AVG(c5),2),ROUND(AVG(c4),2),ROUND(AVG(c3),2),ROUND(AVG(c2),2),ROUND(AVG(c1),2)" +
                    " from(select TO_DATE(TO_CHAR(TIME_STAMP, 'YYYY-MM-DD'), 'YYYY-MM-DD') AS TIME_INTERVAL," +
                    "AVG(co_co215) as c15, AVG(co_co214) as c14, AVG(co_co213) as c13, AVG(co_co212) as c12, AVG(co_co211) as c11, AVG(co_co210) as c10, " +
                    "AVG(co_co29) as c9, AVG(co_co28) as c8, AVG(co_co27) as c7, AVG(co_co26) as c6, AVG(co_co25) as c5, AVG(co_co24) as c4, AVG(co_co23) as c3, AVG(co_co22) as c2, AVG(co_co21) as c1 FROM " + tblName +
                    " WHERE TIME_STAMP > (select max(time_stamp) - interval '10' DAY from " + tblName + ")" +
                    " GROUP BY TO_DATE(TO_CHAR(TIME_STAMP, 'YYYY-MM-DD'), 'YYYY-MM-DD') ORDER BY TIME_INTERVAL desc)";
                }
                else
                {
                    sql = "select TIME_STAMP,co_co216,co_co215,co_co214,co_co213,co_co212,co_co211,co_co210,co_co29,co_co28,co_co27,co_co26,co_co25,co_co24,co_co23,co_co22,co_co21 from " + tblName + " where TIME_STAMP= (select max(TIME_STAMP) from " + tblName + ")";

                    sql_avg = "select Round(AVG(c16),2), Round(AVG(c15),2),ROUND(AVG(c14),2), ROUND(AVG(c13),2),ROUND(AVG(c12),2),ROUND(AVG(c11),2),ROUND(AVG(c10),2),ROUND(AVG(c9),2),ROUND(AVG(c8),2),ROUND(AVG(c7),2),ROUND(AVG(c6),2),ROUND(AVG(c5),2),ROUND(AVG(c4),2),ROUND(AVG(c3),2),ROUND(AVG(c2),2),ROUND(AVG(c1),2)" +
                    " from(select TO_DATE(TO_CHAR(TIME_STAMP, 'YYYY-MM-DD'), 'YYYY-MM-DD') AS TIME_INTERVAL," +
                    "AVG(co_co216) as c16,AVG(co_co215) as c15, AVG(co_co214) as c14, AVG(co_co213) as c13, AVG(co_co212) as c12, AVG(co_co211) as c11, AVG(co_co210) as c10, " +
                    "AVG(co_co29) as c9, AVG(co_co28) as c8, AVG(co_co27) as c7, AVG(co_co26) as c6, AVG(co_co25) as c5, AVG(co_co24) as c4, AVG(co_co23) as c3, AVG(co_co22) as c2, AVG(co_co21) as c1 FROM " + tblName +
                    " WHERE TIME_STAMP > (select max(time_stamp) - interval '10' DAY from " + tblName + ")" +
                    " GROUP BY TO_DATE(TO_CHAR(TIME_STAMP, 'YYYY-MM-DD'), 'YYYY-MM-DD') ORDER BY TIME_INTERVAL desc)";
                }

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                // Adapter & Data Table
                OracleDataAdapter orcDA = new OracleDataAdapter(sql, con);
                orcDA.Fill(dsCOcO2);
                orcDA.Dispose();
                if (dsCOcO2.Rows.Count > 0)
                {
                    for (int a = 1; a < dsCOcO2.Columns.Count; a++)
                    {
                        ParamVsLength obj = new ParamVsLength();
                        obj.Kiln_Length = length[a - 1];
                        obj.COCO2_Value = dsCOcO2.Rows[0][a] == DBNull.Value ? 0: Math.Round(Convert.ToDouble(dsCOcO2.Rows[0][a].ToString()), 2);
                        lstCoCo2Value.Add(obj);
                    }
                }
                dsCOcO2 = new DataTable();
                orcDA = new OracleDataAdapter(sql_avg, con);
                orcDA.Fill(dsCOcO2);
                orcDA.Dispose();
                if (dsCOcO2.Rows.Count > 0)
                {
                    for (int a = 0; a < dsCOcO2.Columns.Count; a++)
                    {
                        ParamVsLength obj = new ParamVsLength();
                        obj.Kiln_Length = length[a];
                        obj.COCO2_Value = dsCOcO2.Rows[0][a] == DBNull.Value ? 0 : Math.Round(Convert.ToDouble(dsCOcO2.Rows[0][a].ToString()), 2);
                        lstCoCo2AVGValue.Add(obj);
                    }
                }

                finalList.Add(lstCoCo2Value);
                finalList.Add(lstCoCo2AVGValue);
            }
            catch (Exception ex)
            {
                finalList = null;
            }
            return finalList;
        }

        public ArrayList BedHeightVsKilnLength(string KILN)
        {
            string[] length;
            if (KILN == "1" || KILN == "2")
                length = KilnLength_Kiln1;
            else
                length = KilnLength_Kiln3;
            string sql = ""; string sql2 = "";
            string tblName = getOuputTableName(KILN);
          
            OracleDataAdapter QMCPDA;
            DataTable BedHeightVsLength = new DataTable();
            List<ParamVsLength> lstvalues = new List<ParamVsLength>();
            List<ParamVsLength> avg_lstvalues = new List<ParamVsLength>();
            ArrayList finalList = new ArrayList();

            try
            {
                if (KILN == "1" || KILN == "2")
                {
                    sql = "select TIME_STAMP,D15,D14,D13,D12,D11,D10,D9,D8,D7,D6,D5,D4,D3,D2,D1 from " + tblName + " where TIME_STAMP= (select max(TIME_STAMP) from " + tblName + ")";

                    sql2 = "select  Round(AVG(d15),2),ROUND(AVG(d14),2), ROUND(AVG(d13),2),ROUND(AVG(d12),2),ROUND(AVG(d11),2),ROUND(AVG(d10),2),ROUND(AVG(d9),2),ROUND(AVG(d8),2),ROUND(AVG(d7),2),ROUND(AVG(d6),2),ROUND(AVG(d5),2),ROUND(AVG(d4),2),ROUND(AVG(d3),2),ROUND(AVG(d2),2),ROUND(AVG(d1),2)" +
                    " from(select TO_DATE(TO_CHAR(TIME_STAMP, 'YYYY-MM-DD'), 'YYYY-MM-DD') AS TIME_INTERVAL," +
                    "AVG(D15) as d15, AVG(D14) as d14, AVG(D13) as d13, AVG(D12) as d12, AVG(D11) as d11, AVG(D10) as d10, " +
                    "AVG(D9) as d9, AVG(D8) as d8, AVG(D7) as d7, AVG(D6) as d6, AVG(D5) as d5, AVG(D4) as d4, AVG(D3) as d3, AVG(D2) as d2, AVG(D1) as d1 FROM " + tblName +
                    " WHERE TIME_STAMP > (select max(time_stamp) - interval '10' DAY from " + tblName + ")" +
                    " GROUP BY TO_DATE(TO_CHAR(TIME_STAMP, 'YYYY-MM-DD'), 'YYYY-MM-DD') ORDER BY TIME_INTERVAL desc)";
                }
                else
                {
                    sql = "select TIME_STAMP,D16,D15,D14,D13,D12,D11,D10,D9,D8,D7,D6,D5,D4,D3,D2,D1 from " + tblName + " where TIME_STAMP= (select max(TIME_STAMP) from " + tblName + ")";

                    sql2 = "select Round(AVG(d16),2), Round(AVG(d15),2),ROUND(AVG(d14),2), ROUND(AVG(d13),2),ROUND(AVG(d12),2),ROUND(AVG(d11),2),ROUND(AVG(d10),2),ROUND(AVG(d9),2),ROUND(AVG(d8),2),ROUND(AVG(d7),2),ROUND(AVG(d6),2),ROUND(AVG(d5),2),ROUND(AVG(d4),2),ROUND(AVG(d3),2),ROUND(AVG(d2),2),ROUND(AVG(d1),2)" +
                    " from(select TO_DATE(TO_CHAR(TIME_STAMP, 'YYYY-MM-DD'), 'YYYY-MM-DD') AS TIME_INTERVAL," +
                    "AVG(D16) as d16,AVG(D15) as d15, AVG(D14) as d14, AVG(D13) as d13, AVG(D12) as d12, AVG(D11) as d11, AVG(D10) as d10, " +
                    "AVG(D9) as d9, AVG(D8) as d8, AVG(D7) as d7, AVG(D6) as d6, AVG(D5) as d5, AVG(D4) as d4, AVG(D3) as d3, AVG(D2) as d2, AVG(D1) as d1 FROM " + tblName +
                    " WHERE TIME_STAMP > (select max(time_stamp) - interval '10' DAY from " + tblName + ")" +
                    " GROUP BY TO_DATE(TO_CHAR(TIME_STAMP, 'YYYY-MM-DD'), 'YYYY-MM-DD') ORDER BY TIME_INTERVAL desc)";
                }

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                // Adapter & Data Table
                QMCPDA = new OracleDataAdapter(sql, con);
                QMCPDA.Fill(BedHeightVsLength);
                QMCPDA.Dispose();
                if (BedHeightVsLength.Rows.Count > 0)
                {
                    for (int a = 1; a < BedHeightVsLength.Columns.Count; a++)
                    {
                        ParamVsLength obj = new ParamVsLength();
                        obj.Kiln_Length = length[a - 1];
                        obj.BH_Value = BedHeightVsLength.Rows[0][a] == DBNull.Value ? 0 : Math.Round(Convert.ToDouble(BedHeightVsLength.Rows[0][a].ToString()), 2);
                        lstvalues.Add(obj);
                    }
                }
                BedHeightVsLength = new DataTable();
                QMCPDA = new OracleDataAdapter(sql2, con);
                QMCPDA.Fill(BedHeightVsLength);
                QMCPDA.Dispose();
                if (BedHeightVsLength.Rows.Count > 0)
                {
                    for (int a = 0; a < BedHeightVsLength.Columns.Count; a++)
                    {
                        ParamVsLength obj = new ParamVsLength();
                        obj.Kiln_Length = length[a];
                        obj.BH_Value = BedHeightVsLength.Rows[0][a] == DBNull.Value ? 0 : Math.Round(Convert.ToDouble(BedHeightVsLength.Rows[0][a].ToString()), 2);
                        avg_lstvalues.Add(obj);
                    }
                }

                finalList.Add(lstvalues);
                finalList.Add(avg_lstvalues);
                return finalList;

            }
            catch (Exception ex)
            {
                lstvalues = null; avg_lstvalues = null;
                return null;
            }
        }

        public ArrayList FillingDegreeVsKilnLength(string KILN)
        {
            string[] length;
            if (KILN == "1" || KILN == "2")
                length = KilnLength_Kiln1;
            else
                length = KilnLength_Kiln3;
            string sql = ""; string sql2 = "";
            string tblName = getOuputTableName(KILN);
           
            OracleDataAdapter QMCPDA;
            DataTable BedHeightVsLength = new DataTable();
            List<ParamVsLength> lstvalues = new List<ParamVsLength>();
            List<ParamVsLength> avg_lstvalues = new List<ParamVsLength>();
            ArrayList finalList = new ArrayList();

            try
            {
                if (KILN == "1" || KILN == "2")
                {
                    sql = "select TIME_STAMP,F15,F14,F13,F12,F11,F10,F9,F8,F7,F6,F5,F4,F3,F2,F1 from " + tblName + " where TIME_STAMP= (select max(TIME_STAMP) from " + tblName + ")";

                    sql2 = "select  Round(AVG(f15),2),ROUND(AVG(f14),2), ROUND(AVG(f13),2),ROUND(AVG(f12),2),ROUND(AVG(f11),2),ROUND(AVG(f10),2),ROUND(AVG(f9),2),ROUND(AVG(f8),2),ROUND(AVG(f7),2),ROUND(AVG(f6),2),ROUND(AVG(f5),2),ROUND(AVG(f4),2),ROUND(AVG(f3),2),ROUND(AVG(f2),2),ROUND(AVG(f1),2)" +
                    " from(select TO_DATE(TO_CHAR(TIME_STAMP, 'YYYY-MM-DD'), 'YYYY-MM-DD') AS TIME_INTERVAL," +
                    "AVG(F15) as f15, AVG(F14) as f14, AVG(F13) as f13, AVG(F12) as f12, AVG(F11) as f11, AVG(F10) as f10, " +
                    "AVG(F9) as f9, AVG(F8) as f8, AVG(F7) as f7, AVG(F6) as f6, AVG(F5) as f5, AVG(F4) as f4, AVG(F3) as f3, AVG(F2) as f2, AVG(F1) as f1 FROM " + tblName +
                    " WHERE TIME_STAMP > (select max(time_stamp) - interval '10' DAY from " + tblName + ")" +
                    " GROUP BY TO_DATE(TO_CHAR(TIME_STAMP, 'YYYY-MM-DD'), 'YYYY-MM-DD') ORDER BY TIME_INTERVAL desc)";
                }
                else
                {
                    sql = "select TIME_STAMP,F16,F15,F14,F13,F12,F11,F10,F9,F8,F7,F6,F5,F4,F3,F2,F1 from " + tblName + " where TIME_STAMP= (select max(TIME_STAMP) from " + tblName + ")";

                    sql2 = "select Round(AVG(f16),2), Round(AVG(f15),2),ROUND(AVG(f14),2), ROUND(AVG(f13),2),ROUND(AVG(f12),2),ROUND(AVG(f11),2),ROUND(AVG(f10),2),ROUND(AVG(f9),2),ROUND(AVG(f8),2),ROUND(AVG(f7),2),ROUND(AVG(f6),2),ROUND(AVG(f5),2),ROUND(AVG(f4),2),ROUND(AVG(f3),2),ROUND(AVG(f2),2),ROUND(AVG(f1),2)" +
                    " from(select TO_DATE(TO_CHAR(TIME_STAMP, 'YYYY-MM-DD'), 'YYYY-MM-DD') AS TIME_INTERVAL," +
                    "AVG(F16) as f16, AVG(F15) as f15, AVG(F14) as f14, AVG(F13) as f13, AVG(F12) as f12, AVG(F11) as f11, AVG(F10) as f10, " +
                    "AVG(F9) as f9, AVG(F8) as f8, AVG(F7) as f7, AVG(F6) as f6, AVG(F5) as f5, AVG(F4) as f4, AVG(F3) as f3, AVG(F2) as f2, AVG(F1) as f1 FROM " + tblName +
                    " WHERE TIME_STAMP > (select max(time_stamp) - interval '10' DAY from " + tblName + ")" +
                    " GROUP BY TO_DATE(TO_CHAR(TIME_STAMP, 'YYYY-MM-DD'), 'YYYY-MM-DD') ORDER BY TIME_INTERVAL desc)";
                }
                    

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                // Adapter & Data Table
                QMCPDA = new OracleDataAdapter(sql, con);
                QMCPDA.Fill(BedHeightVsLength);
                QMCPDA.Dispose();
                if (BedHeightVsLength.Rows.Count > 0)
                {
                    for (int a = 1; a < BedHeightVsLength.Columns.Count; a++)
                    {
                        ParamVsLength obj = new ParamVsLength();
                        obj.Kiln_Length = length[a - 1];
                        obj.FDegree_Value = BedHeightVsLength.Rows[0][a] == DBNull.Value ? 0 : Math.Round(Convert.ToDouble(BedHeightVsLength.Rows[0][a].ToString()), 2);
                        lstvalues.Add(obj);
                    }
                }
                BedHeightVsLength = new DataTable();
                QMCPDA = new OracleDataAdapter(sql2, con);
                QMCPDA.Fill(BedHeightVsLength);
                QMCPDA.Dispose();
                if (BedHeightVsLength.Rows.Count > 0)
                {
                    for (int a = 0; a < BedHeightVsLength.Columns.Count; a++)
                    {
                        ParamVsLength obj = new ParamVsLength();
                        obj.Kiln_Length = length[a];
                        obj.FDegree_Value = BedHeightVsLength.Rows[0][a] == DBNull.Value ? 0 : Math.Round(Convert.ToDouble(BedHeightVsLength.Rows[0][a].ToString()), 2);
                        avg_lstvalues.Add(obj);
                    }
                }

                finalList.Add(lstvalues);
                finalList.Add(avg_lstvalues);
                return finalList;

            }
            catch (Exception ex)
            {
                lstvalues = null; avg_lstvalues = null;
                return null;
            }
        }

        public ArrayList CarbonAvailabilityVsKilnLength(string KILN)
        {
            string[] length;
            if (KILN == "1" || KILN == "2")
                length = KilnLength_Kiln1;
            else
                length = KilnLength_Kiln3;

            string sql = ""; string sql2 = "";
            string tblName = getOuputTableName(KILN);
           
            OracleDataAdapter QMCPDA;
            DataTable dt = new DataTable();
            List<ParamVsLength> lstvalues = new List<ParamVsLength>();
            List<ParamVsLength> avg_lstvalues = new List<ParamVsLength>();
            ArrayList finalList = new ArrayList();

            try
            {
                if (KILN == "1" || KILN == "2")
                {
                    sql = "select TIME_STAMP,CA1,CA2,CA3,CA4,CA5,CA6,CA7,CA8,CA9,CA10,CA11,CA12,CA13,CA14,CA15 from " + tblName + " where TIME_STAMP= (select max(TIME_STAMP) from " + tblName + ")";
                    sql2 = "select  Round(AVG(c1),2),ROUND(AVG(c2),2), ROUND(AVG(c3),2),ROUND(AVG(c4),2),ROUND(AVG(c5),2),ROUND(AVG(c6),2),ROUND(AVG(c7),2),ROUND(AVG(c8),2),ROUND(AVG(c9),2),ROUND(AVG(c10),2),ROUND(AVG(c11),2),ROUND(AVG(c12),2),ROUND(AVG(c13),2),ROUND(AVG(c14),2),ROUND(AVG(c15),2)" +
                    " from(select TO_DATE(TO_CHAR(TIME_STAMP, 'YYYY-MM-DD'), 'YYYY-MM-DD') AS TIME_INTERVAL," +
                    "AVG(CA1) as c1, AVG(CA2) as c2, AVG(CA3) as c3, AVG(CA4) as c4, AVG(CA5) as c5, AVG(CA6) as c6, " +
                    "AVG(CA7) as c7, AVG(CA8) as c8, AVG(CA9) as c9, AVG(CA10) as c10, AVG(CA11) as c11, AVG(CA12) as c12, AVG(CA13) as c13, AVG(CA14) as c14, AVG(CA15) as c15 FROM " + tblName +
                    " WHERE TIME_STAMP > (select max(time_stamp) - interval '10' DAY from " + tblName + ")" +
                    " GROUP BY TO_DATE(TO_CHAR(TIME_STAMP, 'YYYY-MM-DD'), 'YYYY-MM-DD') ORDER BY TIME_INTERVAL desc)";
                }
                    
                else
                {
                    sql = "select TIME_STAMP,CA1,CA2,CA3,CA4,CA5,CA6,CA7,CA8,CA9,CA10,CA11,CA12,CA13,CA14,CA15,CA16 from " + tblName + " where TIME_STAMP= (select max(TIME_STAMP) from " + tblName + ")";
                    sql2 = "select  Round(AVG(c1),2),ROUND(AVG(c2),2), ROUND(AVG(c3),2),ROUND(AVG(c4),2),ROUND(AVG(c5),2),ROUND(AVG(c6),2),ROUND(AVG(c7),2),ROUND(AVG(c8),2),ROUND(AVG(c9),2),ROUND(AVG(c10),2),ROUND(AVG(c11),2),ROUND(AVG(c12),2),ROUND(AVG(c13),2),ROUND(AVG(c14),2),ROUND(AVG(c15),2),ROUND(AVG(c16),2)" +
                    " from(select TO_DATE(TO_CHAR(TIME_STAMP, 'YYYY-MM-DD'), 'YYYY-MM-DD') AS TIME_INTERVAL," +
                    "AVG(CA1) as c1, AVG(CA2) as c2, AVG(CA3) as c3, AVG(CA4) as c4, AVG(CA5) as c5, AVG(CA6) as c6, " +
                    "AVG(CA7) as c7, AVG(CA8) as c8, AVG(CA9) as c9, AVG(CA10) as c10, AVG(CA11) as c11, AVG(CA12) as c12, AVG(CA13) as c13, AVG(CA14) as c14, AVG(CA15) as c15, AVG(CA16) as c16 FROM " + tblName +
                    " WHERE TIME_STAMP > (select max(time_stamp) - interval '10' DAY from " + tblName + ")" +
                    " GROUP BY TO_DATE(TO_CHAR(TIME_STAMP, 'YYYY-MM-DD'), 'YYYY-MM-DD') ORDER BY TIME_INTERVAL desc)";

                }


                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                // Adapter & Data Table
                QMCPDA = new OracleDataAdapter(sql, con);
                QMCPDA.Fill(dt);
                QMCPDA.Dispose();
                if (dt.Rows.Count > 0)
                {
                    for (int a = 1; a < dt.Columns.Count; a++)
                    {
                        ParamVsLength obj = new ParamVsLength();
                        obj.Kiln_Length = length[a - 1];
                        obj.Carbon_Value = Math.Round(Convert.ToDouble(dt.Rows[0][a].ToString()), 2);
                        lstvalues.Add(obj);
                    }
                }
                dt = new DataTable();
                QMCPDA = new OracleDataAdapter(sql2, con);
                QMCPDA.Fill(dt);
                QMCPDA.Dispose();
                if (dt.Rows.Count > 0)
                {
                    for (int a = 0; a < dt.Columns.Count; a++)
                    {
                        ParamVsLength obj = new ParamVsLength();
                        obj.Kiln_Length = length[a];
                        obj.Carbon_Value = Math.Round(Convert.ToDouble(dt.Rows[0][a].ToString()), 2);
                        avg_lstvalues.Add(obj);
                    }
                }

                finalList.Add(lstvalues);
                finalList.Add(avg_lstvalues);
                return finalList;

            }
            catch (Exception ex)
            {
                lstvalues = null; //avg_lstvalues = null;
                return null;
            }
        }

        public List<ParamVsLength> FemVsKilnLength(string KILN)
        {
            string[] length;
            //if (KILN == "1" || KILN == "2")
            //    length = KilnLength_Kiln1;
            //else
                length = KilnLength_Kiln3;

            string sql = "";
            string tblName = getOuputTableName(KILN);
          
            OracleDataAdapter QMCPDA;
            DataSet FemVsLength = new DataSet();
            List<ParamVsLength> lstvalues = new List<ParamVsLength>();
            try
            {
                //if (KILN == "1" || KILN == "2")
                //{
                //    sql = "select TIME_STAMP,FEM2,FEM3,FEM4,FEM5,FEM6,FEM7,FEM8,FEM9,FEM10,FEM11,FEM12,FEM13,FEM14,FEM15,FEM16 from " + tblName + " where TIME_STAMP= (select max(TIME_STAMP) from " + tblName + ")";
                //}
                //else
                //{
                    sql = "select TIME_STAMP,FEM1,FEM2,FEM3,FEM4,FEM5,FEM6,FEM7,FEM8,FEM9,FEM10,FEM11,FEM12,FEM13,FEM14,FEM15,FEM16 from " + tblName + " where TIME_STAMP= (select max(TIME_STAMP) from " + tblName + ")";
                //}
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                // Adapter & Data Table
                QMCPDA = new OracleDataAdapter(sql, con);
                QMCPDA.Fill(FemVsLength);
                QMCPDA.Dispose();
                if (FemVsLength.Tables[0].Rows.Count > 0)
                {
                    for (int a = 1; a < FemVsLength.Tables[0].Columns.Count; a++)
                    {
                        ParamVsLength obj = new ParamVsLength();
                        obj.Kiln_Length = length[a-1];
                        obj.Fem_Value = Math.Round(Convert.ToDouble(FemVsLength.Tables[0].Rows[0][a].ToString()),2);
                        lstvalues.Add(obj);
                }
                }

                return lstvalues;

            }
            catch (Exception ex)
            {
                lstvalues = null;
                return lstvalues;
            }
            }

        public List<pressureValue> getPressureData(string KILN)
        {
            
            string tblName = getInputTableName(KILN);            
            OracleDataAdapter QMCPDA;
            DataTable dsPressure = new DataTable();
            List<pressureValue> lstPressure = new List<pressureValue>();
            try
            {
                string sql = "select RUN_TIME, P_INLET,P_OUTLET from " + tblName + " where run_time >= (SELECT (MAX(run_time)-1) FROM " + tblName + ")  ORDER BY run_time asc";

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                // Adapter & Data Table
                QMCPDA = new OracleDataAdapter(sql, con);
                QMCPDA.Fill(dsPressure);
                QMCPDA.Dispose();

                if (dsPressure.Rows.Count > 0)
                {
                    foreach (DataRow Rows in dsPressure.Rows)
                    {
                        pressureValue obj = new pressureValue();
                        DateTime dt=Convert.ToDateTime(Rows["RUN_TIME"].ToString());
                        obj.Date_Time =dt.ToString("dd MMM HH:mm");
                        obj.P_INLET =Convert.ToDouble(Rows["P_INLET"].ToString());
                        obj.P_OUTLET = Convert.ToDouble(Rows["P_OUTLET"].ToString());
                        lstPressure.Add(obj);
                    }

                }
                return lstPressure;
            }
            catch (Exception ex)
            {
                lstPressure = null;
                return lstPressure;
            }
        }
        //=================================================== FUNCTION GETTING Fe-M VS TIME DATA  GRAPH 1 ==================================
        public List<FemValue> QMFeMvsTime(string KILN, string FromDate, string ToDate) // 1 st graph
        {
            string fromDate = FromDate.Replace('T', ' ');
            string toDate = ToDate.Replace('T', ' ');
            string sqlcmd = "";
            OracleDataAdapter QMFeMTDA;
            DataTable QMFeMTDT = new DataTable();
           // DataTable QMFeMTDT2 = new DataTable();
           // DataTable matchedRows = new DataTable();
            List<FemValue> finalQMFeMTData = new List<FemValue>();
            try
            {
                
                if (KILN == "5" || KILN == "6")
                {
                    sqlcmd = "SELECT TIME_STAMP, FEM16, FEM_ACT FROM t_kiln56_output WHERE ID_KILN = " + KILN + " and   TIME_STAMP  >= TO_DATE('" + fromDate + "', 'yyyy-MM-dd HH24:MI') and TIME_STAMP <= TO_DATE('" + toDate + "', 'yyyy-MM-dd HH24:MI') order by TIME_STAMP";
                }
                if (KILN == "3" || KILN == "4")
                {
                     sqlcmd = "SELECT TIME_STAMP, FEM16, FEM_ACT FROM t_kiln34_output WHERE ID_KILN = " + KILN + " and   TIME_STAMP  >= TO_DATE('" + fromDate + "', 'yyyy-MM-dd HH24:MI') and TIME_STAMP <= TO_DATE('" + toDate + "', 'yyyy-MM-dd HH24:MI') order by TIME_STAMP";
                }
                if (KILN == "1" || KILN == "2")
                {
                    sqlcmd = "SELECT TIME_STAMP, FEM16, FEM_ACT FROM t_kiln12_output WHERE ID_KILN = " + KILN + " and   TIME_STAMP  >= TO_DATE('" + fromDate + "', 'yyyy-MM-dd HH24:MI') and TIME_STAMP <= TO_DATE('" + toDate + "', 'yyyy-MM-dd HH24:MI') order by TIME_STAMP";
                }





                if (con.State != ConnectionState.Open)
                {  
                    con.Open(); 
                }

                QMFeMTDA = new OracleDataAdapter(sqlcmd, con);
                DataTable ds = new DataTable();
                QMFeMTDA.Fill(ds);

                if (ds.Rows.Count>0)
                {
                    foreach (DataRow Rows in ds.Rows)
                    {
                       FemValue obj = new FemValue();
                        DateTime date = Rows["TIME_STAMP"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(Rows["TIME_STAMP"].ToString());
                        obj.TIME_STAMP = date.ToString("dd MMM HH:mm");
                        //obj.RUN_TIME = Rows["RUN_TIME"].ToString();
                        obj.FEM_ACT= Rows["FEM_ACT"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["FEM_ACT"].ToString());
                        obj.FEM16 = Rows["FEM16"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["FEM16"].ToString());
                        finalQMFeMTData.Add(obj);
                    }
                }








                //if (ds.Rows.Count > 0)
                //{

                //    timePredictedValues[1] = ds.Rows[0]["FEM16"] == DBNull.Value ? 0.0 : Convert.ToDouble(ds.Rows[0]["FEM16"].ToString());
                //    timePredictedValues[2] = ds.Rows[0]["FEM_ACT"] == DBNull.Value ? 0.0 : Convert.ToDouble(ds.Rows[0]["FEM_ACT"].ToString());
                //    //timePredictedValues[2] = ds.Rows[0]["FE_M_THREE"] == DBNull.Value ? 0.0 : Convert.ToDouble(ds.Rows[0]["FE_M_THREE"].ToString());
                //    //timePredictedValues[3] = ds.Rows[0]["FE_M_FOUR"] == DBNull.Value ? 0.0 : Convert.ToDouble(ds.Rows[0]["FE_M_FOUR"].ToString());
                //    //timePredictedValues[4] = ds.Rows[0]["FE_M_FIVE"] == DBNull.Value ? 0.0 : Convert.ToDouble(ds.Rows[0]["FE_M_FIVE"].ToString());
                //    //timePredictedValues[5] = ds.Rows[0]["FE_M_SIX"] == DBNull.Value ? 0.0 : Convert.ToDouble(ds.Rows[0]["FE_M_SIX"].ToString());
                //}

                //// Adapter & Data Table
                //QMFeMTDA = new OracleDataAdapter(sqlcmd, con);
                //QMFeMTDA.Fill(QMFeMTDT);
                //QMFeMTDA.Dispose();


                //if (QMFeMTDT.Rows.Count > 0)
                //{
                //    DateTime maxTime = Convert.ToDateTime(QMFeMTDT.Rows[QMFeMTDT.Rows.Count - 1][0].ToString());
                //    foreach (DataRow Rows in QMFeMTDT.Rows)
                //    {
                //        FemValue obj = new FemValue();
                //        DateTime date = Rows["DATE_TIME"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(Rows["DATE_TIME"].ToString());
                //        obj.Date_Time = date.ToString("dd MMM HH:mm");
                //        obj.FE_M_LUMPS = Rows["FE_M_LUMPS"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["FE_M_LUMPS"].ToString());
                //        obj.FEM_PRED_CORR = Rows["FEM_PRED_CORR"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["FEM_PRED_CORR"].ToString());
                //        //obj.Fem_Predicted = Rows[3] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows[3].ToString());

                //        finalQMFeMTData.Add(obj);
                //    }
                //    for (int i = 1; i <= 6; i++)
                //    {
                //        FemValue obj1 = new FemValue();
                //        obj1.Date_Time = maxTime.AddHours(i).ToString("dd MMM HH:mm");
                //        obj1.FEM_PRED_CORR = timePredictedValues[i-1];
                //        finalQMFeMTData.Add(obj1);
                //    }

                //}                               
            }
            catch (Exception ex)
            {
                throw;
            }
            return finalQMFeMTData;
        }

        //public List<FemValue> QMFeMvsTime(string KILN,string FromDate,string ToDate)
        //{
        //    String fromDate = FromDate.Replace('T', ' ');
        //    String toDate = ToDate.Replace('T', ' ');


        //    string tblName1 = "";
        //    string tblName = "";
        //    string FemActual = "";
        //    string FemActual2 = "";
        //    string FemPredicted = "";
        //    string date_time ="";
        //    if (KILN == "1")
        //    {
        //        tblName1 = "T_KILN1_FUTURE"; 
        //        tblName = "T_FEM_OUTPUT_KILN_1";
        //        date_time = "DATE_TIME_KILN1";
        //        FemActual = "FE_M_LUMPS";
        //        FemActual2 = "FE_M_FINES";
        //        FemPredicted = "KILN1_PREDICTED";
        //    }
        //    if (KILN == "2")
        //    {
        //        //tblName1 = "T_KILN1_FUTURE"; 
        //        //date_time = "DATE_TIME_KILN2";
        //        //tblName = "T_FEM_OUTPUT_KILN_1";
        //        //FemActual = "KILN2_ACTUAL";
        //        //FemPredicted = "KILN2_PREDICTED";
        //        tblName1 = "T_KILN1_FUTURE";
        //        tblName = "T_FEM_OUTPUT_KILN_1";
        //        date_time = "DATE_TIME_KILN1";
        //        FemActual = "FE_M_LUMPS";
        //        FemActual2 = "FE_M_FINES";
        //        FemPredicted = "KILN1_PREDICTED";
        //    }
        //    if (KILN == "3")
        //    {
        //        //tblName1 = "T_KILN1_FUTURE"; 
        //        //date_time = "DATE_TIME_KILN1";
        //        //tblName = "T_FEM_OUTPUT_KILN_1";
        //        //FemActual = "KILN1_ACTUAL";
        //        //FemPredicted = "KILN1_PREDICTED";
        //        tblName1 = "T_KILN1_FUTURE";
        //        tblName = "T_FEM_OUTPUT_KILN_1";
        //        date_time = "DATE_TIME_KILN1";
        //        FemActual = "FE_M_LUMPS";
        //        FemActual2 = "FE_M_FINES";
        //        FemPredicted = "KILN1_PREDICTED";
        //    }

        //    OracleDataAdapter QMFeMTDA;
        //    DataTable QMFeMTDT = new DataTable();
        //    DataTable QMFeMTDT2 = new DataTable();
        //    DataTable matchedRows = new DataTable();
        //    List<FemValue> finalQMFeMTData = new List<FemValue>();
        //    try
        //    {
        //       // string sql = "Select DATE_TIME_KILN2 ,KILN2_ACTUAL,KILN2_PREDICTED from T_FEM_OUTPUT_KILN WHERE DATE_TIME_KILN2 >=(Select (MAX(DATE_TIME_KILN2)-1) from T_FEM_OUTPUT_KILN) ORDER BY DATE_TIME_KILN2 ASC  ";
        //       // string sql = "Select "+ date_time + " , "+ FemActual + ","+FemPredicted+" from "+ tblName + " WHERE " + date_time + " >=(Select (MAX(" + date_time + ")-1) from " + tblName + ") ORDER BY " + date_time + " ASC  ";
        //        string LastTime = "";
        //        //string sql = "Select " + date_time + " , " + FemActual + "," + FemPredicted + " from " + tblName + " WHERE " + date_time + " >=TO_DATE('" + fromDate + "','yyyy-MM-dd HH24:MI') and " + date_time + " <=TO_DATE('" + toDate + "','yyyy-MM-dd HH24:MI') ORDER BY " + date_time + " ASC  ";
        //        string sql = "Select DATE_TIME_KILN1 , FE_M_LUMPS,FE_M_FINES,KILN1_PREDICTED from T_FEM_CORR_KILN WHERE " + date_time + " >=TO_DATE('" + fromDate + "','yyyy-MM-dd HH24:MI') and " + date_time + " <=TO_DATE('" + toDate + "','yyyy-MM-dd HH24:MI') ORDER BY " + date_time + " ASC  ";


        //        if (con.State != ConnectionState.Open)
        //        {
        //            con.Open();
        //        }
        //        // Adapter & Data Table
        //        QMFeMTDA = new OracleDataAdapter(sql, con);
        //        QMFeMTDA.Fill(QMFeMTDT);
        //        QMFeMTDA.Dispose();


        //        if (QMFeMTDT.Rows.Count > 0)
        //        {
        //            LastTime = QMFeMTDT.Rows[QMFeMTDT.Rows.Count-1][0].ToString();            
        //            foreach (DataRow Rows in QMFeMTDT.Rows)
        //            {
        //                FemValue obj = new FemValue();
        //                DateTime date = Rows[0] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(Rows[0].ToString());
        //                obj.Date_Time = date.ToString("dd MMM HH:mm");
        //                obj.Fem_Actual = Rows[1] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows[1].ToString());
        //                obj.Fem_Actual2 = Rows[2] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows[2].ToString());
        //                obj.Fem_Predicted = Rows[3] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows[3].ToString());

        //                finalQMFeMTData.Add(obj);
        //            }
        //        }
        //        DataSet dsFuturePred = new DataSet();
        //        string sql1 = "Select *  from " + tblName1 + " WHERE  date_time =(Select Max(date_time) from " + tblName1 +")  ";

        //        if (con.State != ConnectionState.Open)
        //        {
        //            con.Open();
        //        }
        //        // Adapter & Data Table
        //        QMFeMTDA = new OracleDataAdapter(sql1, con);
        //        QMFeMTDA.Fill(dsFuturePred);
        //        QMFeMTDA.Dispose();
        //        if (QMFeMTDT.Rows.Count > 0)
        //        {
        //            if (dsFuturePred.Tables[0].Rows.Count > 0)
        //            {
        //                DataRow Rows = dsFuturePred.Tables[0].Rows[0];

        //                for (int j = 1; j < dsFuturePred.Tables[0].Columns.Count; j++)
        //                {
        //                    FemValue obj = new FemValue();
        //                    DateTime date = Convert.ToDateTime(LastTime).AddHours(j);
        //                    obj.Date_Time = date.ToString("dd MMM HH:mm");
        //                    // obj.Fem_Actual = Rows[1] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows[1].ToString());
        //                    obj.Fem_Predicted = Rows[j] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows[j].ToString());
        //                    finalQMFeMTData.Add(obj);
        //                }

        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {

        //        throw;
        //    }


        //    return finalQMFeMTData;
        //}
        //======================================================================= ENDS ===================================================
        //=================================================== FUNCTION GETTING Fe-M VS KILN-LENGTH DATA ==================================
        [WebMethod]
        public List<T_JKI_CLASS> QMFeMvsKilnLength(string KILN)
        {

            string tblName = getInputTableName(KILN);
           
            OracleDataAdapter QMFeKilnDA;
            DataTable QMFeKilnDT = new DataTable();
            List<T_JKI_CLASS> finalQMFeKilnData = new List<T_JKI_CLASS>();
            try
            {

                string   sql = "SELECT DISTINCT run_time, FE_M, FEM_16 FROM " + tblName + " WHERE run_time >= (SELECT MAX(run_time) FROM " + tblName + ") - (12/24) ORDER BY run_time ASC";
               
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                // Adapter & Data Table
                QMFeKilnDA = new OracleDataAdapter(sql, con);
                QMFeKilnDA.Fill(QMFeKilnDT);
                QMFeKilnDA.Dispose();

                if (QMFeKilnDT.Rows.Count > 0)
                {
                    foreach (DataRow Rows in QMFeKilnDT.Rows)
                    {
                        T_JKI_CLASS obj = new T_JKI_CLASS();
                        DateTime date = Rows["RUN_TIME"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(Rows["RUN_TIME"].ToString());
                        obj.RUN_TIME = date.ToString("dd-MM-yyyy HH:mm:ss");
                        //obj.RUN_TIME = Rows["RUN_TIME"].ToString();
                        obj.FEM_16 = Rows["FEM_16"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["FEM_16"].ToString());

                        finalQMFeKilnData.Add(obj);
                    }
                }
            }
            catch (Exception)
            {

                return null;
            }


            return finalQMFeKilnData;
        }
        //======================================================================= ENDS ===================================================

        [WebMethod]
        public List<T_JKI_CLASS> acerationModelTCTrend(string TC, string kilnNo)
        {

            //string TC = "";
            string sql = "";
            string tblName = getInputTableName(kilnNo);

           
            // double maxVal=0.0;
            // double minVal=0.0;

            OracleDataAdapter AMtcTrendDA;
            DataTable AMtcTrendDT = new DataTable();
            List<T_JKI_CLASS> finalAccuracyTCData = new List<T_JKI_CLASS>();

            try
            {
                sql = "SELECT RUN_TIME, " + TC + " FROM " + tblName + " WHERE run_time >= (SELECT MAX(run_time) FROM " + tblName + ") - 14/24 order by run_time asc";
                //sql = "SELECT RUN_TIME, T1, T2,T3,T4,T5,T6,T7,T8,T9,T10,T11 FROM T_KILN56_INPUT WHERE run_time >= (SELECT MAX(run_time) FROM T_KILN56_INPUT) - 14/24 order by run_time desc";

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                // Adapter & Data Table
                AMtcTrendDA = new OracleDataAdapter(sql, con);
                AMtcTrendDA.Fill(AMtcTrendDT);
                AMtcTrendDA.Dispose();

                if (AMtcTrendDT.Rows.Count > 0)
                {
                    
                    var maxVal = AMtcTrendDT.AsEnumerable().Max(x => x[TC]);
                    var minVal = AMtcTrendDT.AsEnumerable().Min(x => x[TC]);


                    foreach (DataRow Rows in AMtcTrendDT.Rows)
                    {
                        T_JKI_CLASS obj = new T_JKI_CLASS();
                        DateTime date = Rows[0] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(Rows[0].ToString());
                        obj.RUN_TIME = date.ToString("dd-MM-yyyy HH:mm:ss");
                        obj.TCSelect = Rows[1] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows[1].ToString());
                        obj.ucl = Convert.ToDouble(maxVal);
                        obj.lcl = Convert.ToDouble(minVal);


                        finalAccuracyTCData.Add(obj);
                    }
                }
            }
            catch (Exception ex)
            {

                return null;
            }

            return finalAccuracyTCData;
        }

        //=============================== FUNCTION TO GET ACCERATION MODEL'S 2D-PROFILE =======================================
        [WebMethod]
        public List<T_JK1_ACC_CLASS> accerationModel2D(string kiln, string acc2DDate)
        {
            //DateTime acc2DDateFormat = Convert.ToDateTime(acc2DDate);
            //====
           
            OracleDataAdapter accModel2DDA;
            
            var myTime = "";
            string sql2 = "Select CAMPAIGN_START_DATE from T_KILN_CAMPGN_INFO Where prod_centre =" + kiln+ " and CAMPAIGN_NO =(select max(CAMPAIGN_NO) from T_KILN_CAMPGN_INFO where prod_centre = " + kiln + " )";
            if (con.State != ConnectionState.Open)
            {  con.Open(); }
            accModel2DDA = new OracleDataAdapter(sql2, con);
            DataTable accModel2DDT = new DataTable();
            accModel2DDA.Fill(accModel2DDT);
            accModel2DDA.Dispose();
            if (accModel2DDT.Rows.Count > 0)
            {
                DateTime date = accModel2DDT.Rows[0]["CAMPAIGN_START_DATE"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(accModel2DDT.Rows[0]["CAMPAIGN_START_DATE"].ToString());
                 myTime = date.ToString("yyyy-MM-dd");
            }
                //====
                List<T_JK1_ACC_CLASS> finalAccModel2D = new List<T_JK1_ACC_CLASS>();
            string sql = "";
            string error = "500";
            string tblName = "";
            
            if (kiln == "3")
            {
                tblName = "T_KILN34_ACCRETION";
            }

            if (kiln == "4")
            {
                tblName = "T_KILN34_ACCRETION";
            }
            if (kiln == "5")
            {
                tblName = "T_KILN56_ACCRETION";
            }

            if (kiln == "6")
            {
                tblName = "T_KILN56_ACCRETION";
            }
            if (kiln == "1")
            {
                tblName = "T_KILN12_ACCRETION";
            }

            if (kiln == "2")
            {
                tblName = "T_KILN12_ACCRETION";
            }







            accModel2DDT = new DataTable();
            try
            {

                sql = "SELECT * FROM " + tblName + " WHERE ENTRY_DATE >= TO_DATE('" + myTime + "', 'YYYY/MM/DD') ORDER BY ENTRY_DATE ASC"; //MM/dd/yyyy
                //sql = "SELECT ENTRY_DATE, TC5_ACC, TC6_ACC,TC7_ACC, TC8_ACC ,TC9_ACC, TC10_ACC, TC11_ACC FROM " + tblName+" ORDER BY ENTRY_DATE ASC";
                
                error = "525";
                // Adapter & Data Table
                accModel2DDA = new OracleDataAdapter(sql, con);
                accModel2DDA.Fill(accModel2DDT);
                accModel2DDA.Dispose();
                error = "530";
                if (accModel2DDT.Rows.Count > 0)
                {
                    foreach (DataRow Rows in accModel2DDT.Rows)
                    {
                        T_JK1_ACC_CLASS obj = new T_JK1_ACC_CLASS();

                        DateTime date = Rows["ENTRY_DATE"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(Rows["ENTRY_DATE"].ToString());
                        obj.ENTRY_DATE = date.ToString("yyyy-MM-dd");
                        obj.CAMPGN_DATE = myTime;
                        obj.TC5_ACC = Convert.ToDouble(Rows["TC5_ACC"].ToString());
                        obj.TC6_ACC = Rows["TC6_ACC"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["TC6_ACC"].ToString());
                        obj.TC7_ACC = Rows["TC7_ACC"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["TC7_ACC"].ToString());
                        obj.TC8_ACC = Rows["TC8_ACC"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["TC8_ACC"].ToString());
                        obj.TC9_ACC = Rows["TC9_ACC"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["TC9_ACC"].ToString());
                        obj.TC10_ACC = Rows["TC10_ACC"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["TC10_ACC"].ToString());
                        obj.TC11_ACC = Rows["TC11_ACC"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["TC11_ACC"].ToString());

                        finalAccModel2D.Add(obj);
                    }
                    
                }
                error = "551";
                return finalAccModel2D;
            }
            catch (Exception ex)
            {
                T_JK1_ACC_CLASS obj = new T_JK1_ACC_CLASS();
                obj.Error = error+" "+ex.ToString()+":----------"+sql;
                finalAccModel2D.Add(obj);
                return finalAccModel2D;
            }



        }
        //======================================================== END ========================================================
        
            //=============================== FUNCTION TO GET ACCERATION MODEL VOLUME-PROFILE =======================================
        [WebMethod]
        public List<T_JK1_ACC_CLASS> getAccVolumeData(string kiln)
        {
            List<T_JK1_ACC_CLASS> finalAccModel2D = new List<T_JK1_ACC_CLASS>();
           
            string tblName = ""; string sql = "";
            
            if (kiln == "3")
            {
                tblName = "T_KILN34_ACCRETION";
            }
            if (kiln == "4")
            {
                tblName = "T_KILN34_ACCRETION";
            }
            if (kiln == "5")
            {
                tblName = "T_KILN56_ACCRETION";
            }
            if (kiln == "6")
            {
                tblName = "T_KILN56_ACCRETION";
            }
            if (kiln == "1")
            {
                tblName = "T_KILN12_ACCRETION";
            }
            if (kiln == "2")
            {
                tblName = "T_KILN12_ACCRETION";
            }




            OracleDataAdapter accModel2DDA;
            DataTable accModel2DDT = new DataTable();
            try
            {

                sql = "SELECT ENTRY_DATE,TC5_WV,TC6_WV,TC7_WV,TC8_WV,TC9_WV,TC10_WV,TC11_WV FROM " + tblName + " WHERE ENTRY_DATE =(SELECT MAX(ENTRY_DATE) From "+ tblName + ")"; //MM/dd/yyyy
                //sql = "SELECT ENTRY_DATE,TC5_WV,TC6_WV,TC7_WV,TC8_WV,TC9_WV,TC10_WV,TC11_WV FROM T_KILN1_ACCRETION WHERE ENTRY_DATE = to_date('07/07/2023 00:00:00','DD/MM/YYYY HH24:MI:SS')";
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
               
                // Adapter & Data Table
                accModel2DDA = new OracleDataAdapter(sql, con);
                accModel2DDA.Fill(accModel2DDT);
                accModel2DDA.Dispose();
                
                if (accModel2DDT.Rows.Count > 0)
                {
                    foreach (DataRow Rows in accModel2DDT.Rows)
                    {
                        T_JK1_ACC_CLASS obj = new T_JK1_ACC_CLASS();

                        DateTime date = Rows["ENTRY_DATE"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(Rows["ENTRY_DATE"].ToString());
                        obj.ENTRY_DATE = date.ToString("dd-MM-yyyy");

                        obj.TC5_ACC = Rows["TC5_WV"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["TC5_WV"].ToString());
                        obj.TC6_ACC = Rows["TC6_WV"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["TC6_WV"].ToString());
                        obj.TC7_ACC = Rows["TC7_WV"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["TC7_WV"].ToString());
                        obj.TC8_ACC = Rows["TC8_WV"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["TC8_WV"].ToString());
                        obj.TC9_ACC = Rows["TC9_WV"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["TC9_WV"].ToString());
                        obj.TC10_ACC = Rows["TC10_WV"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["TC10_WV"].ToString());
                        obj.TC11_ACC = Rows["TC11_WV"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["TC11_WV"].ToString());

                        finalAccModel2D.Add(obj);
                    }

                }             
                return finalAccModel2D;
            }
            catch (Exception ex)
            {               
                return null;
            }
        }
        //======================================================== END ========================================================
       
        //===========================================TRENDS DATA ===========================================================
        [WebMethod]
        public List<TrendsParametertValue> ParameterTrendsData(string FromDate, string ToDate, string Param, string Kiln)
        {
            DataTable dTable = new DataTable();
            List<TrendsParametertValue> paramList = new List<TrendsParametertValue>();
            string tblName = getInputTableName(Kiln);           
            string column = null;
            FromDate = FromDate.Replace('T', ' ');
            ToDate = ToDate.Replace('T', ' ');

            if (Param== "Air_Flow" && (Kiln=="1"||Kiln=="2" || Kiln=="5" || Kiln=="3" || Kiln=="4" || Kiln=="6"))            
                column = "PRIM_AIR,SAB2,SAB3,SAB4,SAB5,SAB6,SAB7,SAB8,SAB9,SAB10";
           
            else if(Param == "Fuel Rate/Coal Rate")
             column = "FEEDCOAL, FINECOAL"; 
            else if (Param == "RPM")           
                column = "RPM";            
            else if (Param == "Dolomite Rate")            
                column = "DOLO";
            else if (Param == "Iron Ore Rate")
                column = "FE_FEED";
            else if (Param == "FC analysis")
                column = "FC_MC, FC_VM, FC_ASH, FC_FIXEDCARBON";
            else if (Param == "IC analysis")
                column = "IC_MC, IC_VM, IC_ASH, IC_FIXEDCARBON";
            else if (Param == "Ore analysis")
                column = "ORE_LOI, ORE_MOIST, ORE_FETOTAL";
            else if (Param == "C/Fe Ratio")
                column = "C_Fe_Ratio";
            try
            {
                
                string sql = "Select RUN_TIME,"+ column + " from "+ tblName + 
                "  WHERE RUN_TIME >=TO_DATE('" + FromDate + "','yyyy-MM-dd HH24:MI') and RUN_TIME <=TO_DATE('" 
                + ToDate + "','yyyy-MM-dd HH24:MI') and ID_KILN =" + Kiln +"  ORDER BY RUN_TIME ASC  ";


                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                // Adapter & Data Table
                OracleDataAdapter orcDA = new OracleDataAdapter(sql, con);
                orcDA.Fill(dTable);
                orcDA.Dispose();
                if (dTable.Rows.Count > 0)
                {
                    foreach (DataRow row in dTable.Rows)
                    {
                        TrendsParametertValue objData = new TrendsParametertValue();
                        DateTime date = row["RUN_TIME"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(row["RUN_TIME"].ToString());
                        objData.Date_Time = date.ToString("yy-MM-dd HH:mm");
                        if(Param == "RPM")
                        { objData.KILN_RPM = row["RPM"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["RPM"].ToString()); }
                        if (Param == "Iron Ore Rate")
                        { objData.FE_FEED = row["FE_FEED"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["FE_FEED"].ToString()); }
                        if (Param == "Dolomite Rate")
                        { objData.DOLO = row["DOLO"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["DOLO"].ToString()); }
                        if (Param == "Fuel Rate/Coal Rate")
                        {   objData.FEEDCOAL = row["FEEDCOAL"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["FEEDCOAL"].ToString());
                            objData.FINECOAL = row["FINECOAL"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["FINECOAL"].ToString());
                        }
                        if (Param == "Air_Flow" && (Kiln == "1" || Kiln == "2"))
                        {   objData.PAB = row["PRIM_AIR"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["PRIM_AIR"].ToString());
                            objData.SAB2 = row["SAB2"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["SAB2"].ToString());
                            objData.SAB3 = row["SAB3"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["SAB3"].ToString());
                            objData.SAB4 = row["SAB4"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["SAB4"].ToString());
                            objData.SAB5 = row["SAB5"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["SAB5"].ToString());
                            objData.SAB6 = row["SAB6"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["SAB6"].ToString());
                            objData.SAB7 = row["SAB7"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["SAB7"].ToString());
                            objData.SAB8 = row["SAB8"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["SAB8"].ToString());
                            objData.SAB9 = row["SAB9"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["SAB9"].ToString());
                            objData.SAB10 = row["SAB10"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["SAB10"].ToString());
                        }
                        if (Param == "Air_Flow" && Kiln == "3")
                        {
                            objData.PAB = row["PRIM_AIR"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["PRIM_AIR"].ToString());
                            objData.SAB2 = row["SAB1"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["SAB1"].ToString());
                            objData.SAB3 = row["SAB2"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["SAB2"].ToString());
                            objData.SAB4 = row["SAB3"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["SAB3"].ToString());
                            objData.SAB5 = row["SAB4"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["SAB4"].ToString());
                            objData.SAB6 = row["SAB5"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["SAB5"].ToString());
                            objData.SAB7 = row["SAB6"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["SAB6"].ToString());
                            objData.SAB8 = row["SAB7"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["SAB7"].ToString());
                            objData.SAB9 = row["SAB8"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["SAB8"].ToString());
                           // objData.SAB9 = row["SAB9"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["SAB9"].ToString());
                           
                        }
                        if (Param == "FC analysis")
                        {
                            objData.FC_MC  = row["FC_MC"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["FC_MC"].ToString());
                            objData.FC_VM = row["FC_VM"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["FC_VM"].ToString());
                            objData.FC_ASH = row["FC_ASH"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["FC_ASH"].ToString());
                            objData.FC_FIXEDCARBON = row["FC_FIXEDCARBON"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["FC_FIXEDCARBON"].ToString());
                        }
                        if (Param == "IC analysis")
                        {
                            objData.IC_MC = row["IC_MC"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["IC_MC"].ToString());
                            objData.IC_VM = row["IC_VM"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["IC_VM"].ToString());
                            objData.IC_ASH = row["IC_ASH"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["IC_ASH"].ToString());
                            objData.IC_FIXEDCARBON = row["IC_FIXEDCARBON"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["IC_FIXEDCARBON"].ToString());
                        }
                        if (Param == "Ore analysis")
                        {
                            objData.ORE_LOI = row["ORE_LOI"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["ORE_LOI"].ToString());
                            objData.ORE_MOIST = row["ORE_MOIST"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["ORE_MOIST"].ToString());
                            objData.ORE_FETOTAL = row["ORE_FETOTAL"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["ORE_FETOTAL"].ToString());                         
                        }
                        if (Param == "C/Fe Ratio")
                        {
                            objData.C_Fe_Ratio = row["C_Fe_Ratio"] == DBNull.Value ? 0.0 : Convert.ToDouble(row["C_Fe_Ratio"].ToString());                          
                        }

                        paramList.Add(objData);
                    }
                }

                return paramList;
            }
            catch(Exception ex)
            { paramList = null; return paramList; }
            
        }

        public string getInputTableName(string Kiln)
        {
            string tblName = "";
            
            if (Kiln == "6")
            {

                tblName = "T_KILN56_INPUT";
            }
            if (Kiln =="5")
            {
               

                tblName = "T_KILN56_INPUT";
            }
            if (Kiln == "3")
            {
               

                tblName = "T_KILN34_INPUT";
            }
            if (Kiln == "4")
            {
               

                tblName = "T_KILN34_INPUT";
            }

            if (Kiln == "1")
            {


                tblName = "T_KILN12_INPUT";
            }

            if (Kiln == "2")
            {


                tblName = "T_KILN12_INPUT";
            }


            return tblName;
        }
        public string getOuputTableName(string Kiln)
        {
            string tblName = "";
            
            if (Kiln == "6")
            {
               

                tblName = "T_KILN56_OUTPUT";
            }
            if (Kiln == "5")
            {
                tblName = "T_KILN56_OUTPUT";
            }

            if (Kiln == "3")
            {
                tblName = "T_KILN34_OUTPUT";
            }
            if (Kiln == "4")
            {
                tblName = "T_KILN34_OUTPUT";
            }

            if (Kiln == "1")
            {
                tblName = "T_KILN12_OUTPUT";
            }
            if (Kiln == "2")
            {
                tblName = "T_KILN12_OUTPUT";
            }



            return tblName;
        }

        //=============== CLASSES =======================

        public class ParamVsLength
        {
            public string Kiln_Length { get; set; }
            public double BH_Value { get; set; }
            public double FDegree_Value { get; set; }
            public double Fem_Value { get; set; }
            public double COCO2_Value { get; set; }
            public double Carbon_Value { get; set; }

        }
        public class pressureValue
        {
            public string Date_Time { get; set; }
            public double P_INLET { get; set; }
            public double P_OUTLET { get; set; }

        }

        public class FemValue
        {
            public string Date_Time { get; set; }
            public double FE_M_LUMPS { get; set; }
            public double FEM_PRED_CORR { get; set; }
           // public double Fem_Predicted { get; set; }

            public string TIME_STAMP { get; set; }
            public double FEM16 { get; set; }
            public double FEM_ACT { get; set; }


        }
public class TrendsParametertValue
{
            public string Date_Time { get; set; }
            public double KILN_RPM { get; set; }
            public double FEEDCOAL { get; set; }
            public double FINECOAL { get; set; }
            public double FE_FEED { get; set; }
            public double DOLO { get; set; }
            public double PAB { get; set; }
            public double SAB2 { get; set; }
            public double SAB3 { get; set; }
            public double SAB4 { get; set; }
            public double SAB5 { get; set; }
            public double SAB6 { get; set; }
            public double SAB7 { get; set; }
            public double SAB8 { get; set; }
            public double SAB9 { get; set; }
            public double SAB10 { get; set; }
            public double FC_MC { get; set; }
            public double FC_VM { get; set; }
            public double FC_ASH { get; set; }
            public double FC_FIXEDCARBON { get; set; }
            public double IC_MC { get; set; }
            public double IC_VM { get; set; }
            public double IC_ASH { get; set; }
            public double IC_FIXEDCARBON { get; set; }
            public double ORE_LOI  { get; set; }
            public double ORE_MOIST  { get; set; }
            public double ORE_FETOTAL { get; set; }
            public double C_Fe_Ratio { get; set; }
        }

public class T_JKI_CLASS
        {

            public string PAB_AirFlow { get; set; }
            public string SAB1_AirFlow { get; set; }
            public string SAB2_AirFlow { get; set; }
            public string SAB3_AirFlow { get; set; }
            public string SAB4_AirFlow { get; set; }
            public string SAB5_AirFlow { get; set; }
            public string SAB6_AirFlow { get; set; }
            public string SAB7_AirFlow { get; set; }
            public string SAB8_AirFlow { get; set; }
            public string SAB9_AirFlow { get; set; }
            public string SAB10_AirFlow { get; set; }
            public string KILN_RPM { get; set; }
            public string FeedCoalRate { get; set; }
            public string InjectionCoalRate { get; set; }
            public string IronOreFeedRate { get; set; }
            public string DolomiteFeedRate { get; set; }
            public string PRIM_AIR_SET { get; set; }
            public string RPM_SET { get; set; }
            public string FE_FEED_SET { get; set; }
            public string FEEDCOAL_SET { get; set; }
            public string FINECOAL_SET { get; set; }
            public string INJ_AIR_FLOW1 { get; set; }
            public string INJ_AIR_FLOW2 { get; set; }

            public string BackFlow { get; set; }
            public string BackFlow_Ref { get; set; }
            public string C_FE { get; set; }
            public string C_FE_REF { get; set; }

            public string RUN_TIME { get; set; }
            public double FE_M { get; set; }
            public double FEM_16 { get; set; }
            public double T1 { get; set; }
            public double T2 { get; set; }
            public double T3 { get; set; }
            public double T4 { get; set; }
            public double T5 { get; set; }
            public double T6 { get; set; }
            public double T7 { get; set; }
            public double T8 { get; set; }
            public double T9 { get; set; }
            public double T10 { get; set; }
            public double T11 { get; set; }

            public double TCSelect { get; set; }
            public double ucl { get; set; }
            public double lcl { get; set; }
        }

        public class GraphValue
        {
            public string TIME_STAMP { get; set; }
            public double ActualValue { get; set; }
            public double ActualValue2 { get; set; }
            public double PredictedValue { get; set; }

            public double C1 { get; set; }
            public double SU1 { get; set; }
            public double SUL_LUMP_ACT { get; set; }
            public double SUL_FINE_ACT { get; set; }

           
        }
        public class T_JKO_CLASS
        {

            public string TIME_STAMP { get; set; }
            public string FEM1 { get; set; }
            public string FEM2 { get; set; }
            public string FEM3 { get; set; }
            public string FEM4 { get; set; }
            public string FEM5 { get; set; }
            public string FEM6 { get; set; }
            public string FEM7 { get; set; }
            public string FEM8 { get; set; }
            public string FEM9 { get; set; }
            public string FEM10 { get; set; }
            public string FEM11 { get; set; }
            public string FEM12 { get; set; }
            public string FEM13 { get; set; }
            public string FEM14 { get; set; }
            public string FEM15 { get; set; }
            public string FEM_16 { get; set; }
        }

        public class T_JK1_ACC_CLASS
        {
            public string Error{ get; set; }
            public string ENTRY_DATE { get; set; }
            public string CAMPGN_DATE { get; set; }
            public double SHELL_TEMP_T5 { get; set; }
            public double SHELL_TEMP_T6 { get; set; }
            public double SHELL_TEMP_T7 { get; set; }
            public double SHELL_TEMP_T8 { get; set; }
            public double SHELL_TEMP_T9 { get; set; }
            public double SHELL_TEMP_T10 { get; set; }
            public double SHELL_TEMP_T11 { get; set; }
            public double TC5 { get; set; }
            public double TC6 { get; set; }
            public double TC7 { get; set; }
            public double TC8 { get; set; }
            public double TC9 { get; set; }
            public double TC10 { get; set; }
            public double TC11 { get; set; }
            public double TC5_ACC { get; set; }
            public double TC6_ACC { get; set; }
            public double TC7_ACC { get; set; }
            public double TC8_ACC { get; set; }
            public double TC9_ACC { get; set; }
            public double TC10_ACC { get; set; }
            public double TC11_ACC { get; set; }
        }
    }
}
