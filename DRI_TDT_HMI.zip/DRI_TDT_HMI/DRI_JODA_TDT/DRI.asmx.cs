﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace DRI_JODA_TDT
{
    /// <summary>
    /// Summary description for DRI
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class DRI : System.Web.Services.WebService
    {

        public static OracleConnection con = new OracleConnection("Data Source=(DESCRIPTION="
      + "(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=157.0.151.76)(PORT=1521)))"
      + "(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=millsdb)));"
      + "User Id=bafdba;Password=bafdba");


        //==================================== FUNCTION FOR GETTING CONTROLLABLE PARAMETERS DATA ======================================
        [WebMethod]
        public List<T_JKI_CLASS> QMcontrollablePara(string KILN)
        {
            string KilnNo = "";
            string sql = "";
            if (KILN == "KILN-1")
            {
                KilnNo = "1";
            }
            if (KILN == "KILN-2")
            {
                KilnNo = "2";
            }
            if (KILN == "KILN-3")
            {
                KilnNo = "3";
            }
            OracleDataAdapter QMCPDA;
            DataTable QMCPDT = new DataTable();
            List<T_JKI_CLASS> finalValues = new List<T_JKI_CLASS>();
            try
            {
                 sql = "select PRIM_AIR,SAB1,SAB2,SAB3,SAB4,SAB5,SAB6,SAB7,SAB8,SAB9,SAB10,RPM,FEEDCOAL,FINECOAL,FE_FEED,DOLO from T_KILN56_INPUT where run_time >= (select max(run_time) from T_KILN56_INPUT)";
                 if (con.State != ConnectionState.Open)
                 {
                     con.Open();
                 }
                 // Adapter & Data Table
                 QMCPDA = new OracleDataAdapter(sql, con);
                 QMCPDA.Fill(QMCPDT);
                 QMCPDA.Dispose();

                 if (QMCPDT.Rows.Count > 0)
                 {
                     foreach (DataRow Rows in QMCPDT.Rows)
                     {
                         T_JKI_CLASS obj = new T_JKI_CLASS();
                         obj.PAB_AirFlow       = Rows["PRIM_AIR"].ToString();
                         obj.SAB1_AirFlow      = Rows["SAB1"].ToString();
                         obj.SAB2_AirFlow      = Rows["SAB2"].ToString();
                         obj.SAB3_AirFlow      = Rows["SAB3"].ToString();
                         obj.SAB4_AirFlow      = Rows["SAB4"].ToString();
                         obj.SAB5_AirFlow      = Rows["SAB5"].ToString();
                         obj.SAB6_AirFlow      = Rows["SAB6"].ToString();
                         obj.SAB7_AirFlow      = Rows["SAB7"].ToString();
                         obj.SAB8_AirFlow      = Rows["SAB8"].ToString();
                         obj.SAB9_AirFlow      = Rows["SAB9"].ToString();
                         obj.SAB10_AirFlow     = Rows["SAB10"].ToString();
                         obj.KILN_RPM          = Rows["RPM"].ToString();
                         obj.FeedCoalRate      = Rows["FEEDCOAL"].ToString();
                         obj.InjectionCoalRate = Rows["FINECOAL"].ToString();
                         obj.IronOreFeedRate   = Rows["FE_FEED"].ToString();
                         obj.DolomiteFeedRate  = Rows["DOLO"].ToString();

                         finalValues.Add(obj);
                     }
                 }
            }
            catch (Exception)
            {
                
                throw;
            }
            return finalValues;
            
        }
        //============================================================== ENDS ============================================================

        //=================================================== FUNCTION GETTING Fe-M VS TIME DATA ==================================
        [WebMethod]
        public List<T_JKI_CLASS> QMFeMvsTime(string KILN)
        {
            
            string KilnNo = "";
            string sql = "";
            if (KILN == "KILN-1")
            {
                KilnNo = "1";
            }
            if (KILN == "KILN-2")
            {
                KilnNo = "2";
            }
            if (KILN == "KILN-5")
            {
                KilnNo = "5";
            }
            OracleDataAdapter QMFeMTDA;
            DataTable QMFeMTDT = new DataTable();
            DataTable QMFeMTDT2 = new DataTable();
            DataTable matchedRows = new DataTable();
            List<T_JKI_CLASS> finalQMFeMTData = new List<T_JKI_CLASS>();
            try
            {

                sql = "SELECT DISTINCT (run_time), FE_M, FEM16 FROM T_KILN56_INPUT WHERE run_time >= (SELECT MAX(run_time) FROM T_KILN56_INPUT) - (12/24) ORDER BY run_time desc";

                //sql = "SELECT DISTINCT TO_CHAR(run_time, 'DD-MM-YYYY HH24:MI:SS') AS formatted_time, FE_M, FEM16 FROM T_KILN56_INPUT WHERE run_time >= (SELECT MAX(run_time) FROM T_KILN56_INPUT) - 12/24 ORDER BY formatted_time DESC";
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                // Adapter & Data Table
                QMFeMTDA = new OracleDataAdapter(sql, con);
                QMFeMTDA.Fill(QMFeMTDT);
                QMFeMTDA.Dispose();
                
                //if (QMFeMTDT.Rows.Count > 0)
                //{

                //    // Sort the rows in descending order by RUN_TIME and select the first row
                //    DataRow latestRow = QMFeMTDT.Rows.Cast<DataRow>()
                //        .OrderByDescending(row => row.Field<DateTime>("RUN_TIME"))
                //        .FirstOrDefault();

                //    if (latestRow != null)
                //    {
                //        // Subtract 2 hours from the RUN_TIME value of the latest row
                //        DateTime latestTime = latestRow.Field<DateTime>("RUN_TIME");
                //        DateTime newTime = latestTime.AddHours(-2);

                //        // Calculate the nearest matching timestamp
                //        DataRow nearestRow = QMFeMTDT.Rows.Cast<DataRow>()
                //            .OrderBy(row => Math.Abs((row.Field<DateTime>("RUN_TIME") - newTime).Ticks))
                //            .FirstOrDefault();

                //        // Create a new DataTable to hold the matched row(s)
                //        //matchedRows = QMFeMTDT.Clone();

                //        // Iterate through the rows and add any matching rows to the new DataTable
                //        foreach (DataRow row in QMFeMTDT.Rows)
                //        {
                //            DateTime rowTime = row.Field<DateTime>("RUN_TIME");
                //            if (rowTime == newTime)
                //            {
                //                matchedRows.Rows.Add(row.ItemArray);
                //            }
                //        }

                //        // Use the matchedRows DataTable as needed
                //    }
                //    else
                //    {
                //        // Handle case where there are no rows in the DataTable
                //    }




                //    //=============================================================================

                //    //// Sort the rows in descending order by RUN_TIME and select the first row
                //    //DataRow latestRow = QMFeMTDT.Rows.Cast<DataRow>()
                //    //    .OrderByDescending(row => row.Field<DateTime>("RUN_TIME"))
                //    //    .FirstOrDefault();

                //    //if (latestRow != null)
                //    //{
                //    //    // Subtract 2 hours from the RUN_TIME value of the latest row
                //    //    DateTime latestTime = latestRow.Field<DateTime>("RUN_TIME");
                //    //    DateTime newTime = latestTime.AddHours(-2);

                //    //    // Create a new DataTable to hold the matched row(s)
                //    //    matchedRows = QMFeMTDT.Clone();

                //    //    // Calculate the nearest matching timestamp
                //    //    DataRow nearestRow = QMFeMTDT.Rows.Cast<DataRow>()
                //    //        .OrderBy(row => Math.Abs((row.Field<DateTime>("RUN_TIME") - newTime).Ticks))
                //    //        .FirstOrDefault();

                //    //    if (nearestRow != null)
                //    //    {
                //    //        // Add the row with the nearest timestamp to the matchedRows DataTable
                            
                //    //        matchedRows.Rows.Add(nearestRow.ItemArray);
                //    //    }

                //    //    // Use the matchedRows DataTable as needed
                //    //}
                //    //else
                //    //{
                //    //    // Handle case where there are no rows in the DataTable
                //    //}


                //    //==========================================================================================

                //    //// Sort the rows in descending order by RUN_TIME and select the first row
                //    //DataRow latestRow = QMFeMTDT.Rows.Cast<DataRow>()
                //    //    .OrderByDescending(row => row.Field<DateTime>("RUN_TIME"))
                //    //    .FirstOrDefault();

                //    //if (latestRow != null)
                //    //{
                //    //    // Subtract 2 hours from the RUN_TIME value of the latest row
                //    //    DateTime latestTime = latestRow.Field<DateTime>("RUN_TIME");
                //    //    DateTime newTime = latestTime.AddHours(-2);

                //    //    // Create a new DataTable to hold the matched row(s)
                //    //    matchedRows = QMFeMTDT.Clone();

                //    //    // Add all rows with timestamps within 2 hours before newTime to the matchedRows DataTable
                //    //    foreach (DataRow row in QMFeMTDT.Rows)
                //    //    {
                //    //        DateTime rowTime = row.Field<DateTime>("RUN_TIME");
                //    //        if (rowTime >= newTime && rowTime < latestTime)
                //    //        {
                //    //            matchedRows.Rows.Add(row.ItemArray);
                //    //        }
                //    //    }

                //    //    // Use the matchedRows DataTable as needed
                //    //}
                //    //else
                //    //{
                //    //    // Handle case where there are no rows in the DataTable
                //    //}


                //}

                if (QMFeMTDT.Rows.Count > 0)
                {
                    foreach (DataRow Rows in QMFeMTDT.Rows)
                    {
                        T_JKI_CLASS obj = new T_JKI_CLASS();
                        DateTime date = Rows["RUN_TIME"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(Rows["RUN_TIME"].ToString());
                        obj.RUN_TIME = date.ToString("dd-MM-yyyy HH:mm:ss");
                        obj.FE_M = Rows["FE_M"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["FE_M"].ToString());
                        obj.FEM16 = Rows["FEM16"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["FEM16"].ToString());

                        finalQMFeMTData.Add(obj);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }


            return finalQMFeMTData;
        }
        //======================================================================= ENDS ===================================================
        //=================================================== FUNCTION GETTING Fe-M VS KILN-LENGTH DATA ==================================
        [WebMethod]
        public List<T_JKI_CLASS> QMFeMvsKilnLength(string KILN)
        {

            string KilnNo = "";
            string sql = "";
            if (KILN == "KILN-1")
            {
                KilnNo = "1";
            }
            if (KILN == "KILN-2")
            {
                KilnNo = "2";
            }
            if (KILN == "KILN-3")
            {
                KilnNo = "3";
            }
            OracleDataAdapter QMFeKilnDA;
            DataTable QMFeKilnDT = new DataTable();
            List<T_JKI_CLASS> finalQMFeKilnData = new List<T_JKI_CLASS>();
            try
            {

                sql = "SELECT DISTINCT run_time, FE_M, FEM16 FROM T_KILN56_INPUT WHERE run_time >= (SELECT MAX(run_time) FROM T_KILN56_INPUT) - (12/24) ORDER BY run_time ASC";

                //sql = "SELECT DISTINCT TO_CHAR(run_time, 'DD-MM-YYYY HH24:MI:SS') AS formatted_time, FE_M, FEM16 FROM T_KILN56_INPUT WHERE run_time >= (SELECT MAX(run_time) FROM T_KILN56_INPUT) - 12/24 ORDER BY formatted_time DESC";
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                // Adapter & Data Table
                QMFeKilnDA = new OracleDataAdapter(sql, con);
                QMFeKilnDA.Fill(QMFeKilnDT);
                QMFeKilnDA.Dispose();

                if (QMFeKilnDT.Rows.Count > 0)
                {
                    foreach (DataRow Rows in QMFeKilnDT.Rows)
                    {
                        T_JKI_CLASS obj = new T_JKI_CLASS();
                        DateTime date = Rows["RUN_TIME"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(Rows["RUN_TIME"].ToString());
                        obj.RUN_TIME = date.ToString("dd-MM-yyyy HH:mm:ss");
                        //obj.RUN_TIME = Rows["RUN_TIME"].ToString();
                        obj.FEM16 = Rows["FEM16"] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows["FEM16"].ToString());

                        finalQMFeKilnData.Add(obj);
                    }
                }
            }
            catch (Exception)
            {

                return null;
            }


            return finalQMFeKilnData;
        }
        //======================================================================= ENDS ===================================================

        [WebMethod]
        public List<T_JKI_CLASS> acerationModelTCTrend(string TC)
        {

            //string TC = "";
            string sql = "";
          // double maxVal=0.0;
          // double minVal=0.0;
           
            OracleDataAdapter AMtcTrendDA;
            DataTable AMtcTrendDT = new DataTable();
            List<T_JKI_CLASS> finalAccuracyTCData = new List<T_JKI_CLASS>();

            try
            {
                sql = "SELECT RUN_TIME, " + TC + " FROM T_KILN56_INPUT WHERE run_time >= (SELECT MAX(run_time) FROM T_KILN56_INPUT) - 14/24 order by run_time asc";
                //sql = "SELECT RUN_TIME, T1, T2,T3,T4,T5,T6,T7,T8,T9,T10,T11 FROM T_KILN56_INPUT WHERE run_time >= (SELECT MAX(run_time) FROM T_KILN56_INPUT) - 14/24 order by run_time desc";
          
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                // Adapter & Data Table
                AMtcTrendDA = new OracleDataAdapter(sql, con);
                AMtcTrendDA.Fill(AMtcTrendDT);
                AMtcTrendDA.Dispose();

                if (AMtcTrendDT.Rows.Count > 0)
                {
                    //int maxVal = AMtcTrendDT.AsEnumerable().Max(row => row.Field<int>(TC));
                    //int minVal = AMtcTrendDT.AsEnumerable().Min(row => row.Field<int>(TC));
                    var maxVal = AMtcTrendDT.AsEnumerable().Max(x => x[TC]);
                    var minVal = AMtcTrendDT.AsEnumerable().Min(x => x[TC]);


                    foreach (DataRow Rows in AMtcTrendDT.Rows)
                    {
                        T_JKI_CLASS obj = new T_JKI_CLASS();
                        DateTime date = Rows[0] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(Rows[0].ToString());
                        obj.RUN_TIME = date.ToString("dd-MM-yyyy HH:mm:ss");
                        obj.TCSelect = Rows[1] == DBNull.Value ? 0.0 : Convert.ToDouble(Rows[1].ToString());
                        obj.ucl = Convert.ToDouble(maxVal);
                        obj.lcl = Convert.ToDouble(minVal);


                        finalAccuracyTCData.Add(obj);
                    }
                }
            }
            catch (Exception)
            {
                
                return null;
            }

            return finalAccuracyTCData;
        }

        //=============================== FUNCTION TO GET ACCERATION MODEL'S 2D-PROFILE =======================================
        [WebMethod]
        public List<T_JK1_ACC_CLASS> accerationModel2D(string kiln, string acc2DDate)
        {
            DateTime acc2DDateFormat = Convert.ToDateTime(acc2DDate);
            List<T_JK1_ACC_CLASS> finalAccModel2D = new List<T_JK1_ACC_CLASS>();
            string sql = "";
            string tblName = "";
            if (kiln=="KILN1")
            {
                tblName = "T_KILN1_ACC";
            }
            if (kiln == "KILN2")
            {
                tblName = "T_KILN2_ACC";
            }
            if (kiln == "KILN3")
            {
                tblName = "T_KILN3_ACC";
            }
            OracleDataAdapter accModel2DDA;
            DataTable accModel2DDT = new DataTable();
            try
            {

                sql = "SELECT * FROM " + tblName + " WHERE ENTRY_DATE >= TO_DATE('" + acc2DDateFormat + "', 'DD-MM-YYYY HH24:MI:SS') ORDER BY ENTRY_DATE ASC";
                //sql = "SELECT ENTRY_DATE, TC5_ACC, TC6_ACC,TC7_ACC, TC8_ACC ,TC9_ACC, TC10_ACC, TC11_ACC FROM " + tblName+" ORDER BY ENTRY_DATE ASC";
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                // Adapter & Data Table
                accModel2DDA = new OracleDataAdapter(sql, con);
                accModel2DDA.Fill(accModel2DDT);
                accModel2DDA.Dispose();

                if (accModel2DDT.Rows.Count > 0)
                {
                    foreach (DataRow Rows in accModel2DDT.Rows)
                    {
                        T_JK1_ACC_CLASS obj = new T_JK1_ACC_CLASS();

                        DateTime date = Rows["ENTRY_DATE"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(Rows["ENTRY_DATE"].ToString());
                        obj.ENTRY_DATE = date.ToString("dd-MM-yyyy HH:mm:ss");

                        obj.TC5_ACC = Convert.ToDouble(Rows["TC5_ACC"].ToString());
                        obj.TC6_ACC = Convert.ToDouble(Rows["TC6_ACC"].ToString());
                        obj.TC7_ACC = Convert.ToDouble(Rows["TC7_ACC"].ToString());
                        obj.TC8_ACC = Convert.ToDouble(Rows["TC8_ACC"].ToString());
                        obj.TC9_ACC = Convert.ToDouble(Rows["TC9_ACC"].ToString());
                        obj.TC10_ACC = Convert.ToDouble(Rows["TC10_ACC"].ToString());
                        obj.TC11_ACC = Convert.ToDouble(Rows["TC11_ACC"].ToString());

                        finalAccModel2D.Add(obj);
                    }
                }
                return finalAccModel2D;
            }
            catch (Exception ex)
            {

                return null;
            }

            

        }
        //======================================================== END ========================================================
        
        
        
        //=============== CLASSES =======================

        public class T_JKI_CLASS
        {
            
            public string PAB_AirFlow { get; set; }
            public string SAB1_AirFlow { get; set; }
            public string SAB2_AirFlow { get; set; }
            public string SAB3_AirFlow { get; set; }
            public string SAB4_AirFlow { get; set; }
            public string SAB5_AirFlow { get; set; }
            public string SAB6_AirFlow { get; set; }
            public string SAB7_AirFlow { get; set; }
            public string SAB8_AirFlow { get; set; }
            public string SAB9_AirFlow { get; set; }
            public string SAB10_AirFlow { get; set; }
            public string KILN_RPM { get; set; }
            public string FeedCoalRate { get; set; }
            public string InjectionCoalRate { get; set; }
            public string IronOreFeedRate { get; set; }
            public string DolomiteFeedRate { get; set; }

            public string RUN_TIME { get; set; }
            public double FE_M { get; set; }
            public double FEM16 { get; set; }
            public double T1 { get; set; }
            public double T2 { get; set; }
            public double T3 { get; set; }
            public double T4 { get; set; }
            public double T5 { get; set; }
            public double T6 { get; set; }
            public double T7 { get; set; }
            public double T8 { get; set; }
            public double T9 { get; set; }
            public double T10 { get; set; }
            public double T11 { get; set; }

            public double TCSelect { get; set; }
            public double ucl { get; set; }
            public double lcl { get; set; }
        }


        public class T_JKO_CLASS
        {

            public string TIME_STAMP { get; set; }
            public string  FEM1  {get; set;}
            public string  FEM2   {get; set;}
            public string  FEM3   {get; set;}
            public string  FEM4   {get; set;}
            public string  FEM5   {get; set;}
            public string  FEM6   {get; set;}
            public string  FEM7   {get; set;}
            public string  FEM8   {get; set;}
            public string  FEM9   {get; set;}
            public string  FEM10  {get; set;}
            public string  FEM11  {get; set;}
            public string  FEM12  {get; set;}
            public string  FEM13  {get; set;}
            public string  FEM14  {get; set;}
            public string  FEM15  {get; set;}
            public string  FEM16 { get; set; }
        }

        public class T_JK1_ACC_CLASS
        {
          public string  ENTRY_DATE     {get; set;}
          public double  SHELL_TEMP_T5  {get; set;}
          public double  SHELL_TEMP_T6  {get; set;}
          public double  SHELL_TEMP_T7  {get; set;}
          public double  SHELL_TEMP_T8  {get; set;}
          public double  SHELL_TEMP_T9  {get; set;}
          public double  SHELL_TEMP_T10 {get; set;}
          public double  SHELL_TEMP_T11 {get; set;}
          public double  TC5            {get; set;}
          public double  TC6            {get; set;}
          public double  TC7            {get; set;}
          public double  TC8            {get; set;}
          public double  TC9            {get; set;}
          public double  TC10           {get; set;}
          public double  TC11           {get; set;}
          public double  TC5_ACC        {get; set;}
          public double  TC6_ACC        {get; set;}
          public double  TC7_ACC        {get; set;}
          public double  TC8_ACC        {get; set;}
          public double  TC9_ACC        {get; set;}
          public double  TC10_ACC       {get; set;}
          public double  TC11_ACC       {get; set;}
        }
    }
}
