﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using DRI_JODA_TDT.MODELS;
using Oracle.ManagedDataAccess.Client;

namespace DRI_JODA_TDT
{
    /// <summary>
    /// Summary description for DCSService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class DCSService : System.Web.Services.WebService
    {
        public static OracleConnection con = new OracleConnection("Data Source=(DESCRIPTION="
                + "(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=10.163.30.60)(PORT=1521)))"
                + "(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=autdevtsbsl)));"
                + "User Id=dril2;Password=dril22;");

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }
       


        //level 1 ddl
        [WebMethod]
        public object FillddlShowDataSource(string KILN)
        {
            List<DATACONFIG> lstDATACONFIG = new List<DATACONFIG>();
            // var objlstDataConfig = lstDATACONFIG;
            // string tblName = getInputTableName(KILN);
            OracleDataAdapter QMCPDA;
            DataTable dsPressure = new DataTable();

            try
            {
               // string sql = "select distinct data_source from t_dri_data_config where data_group='"+ Datagroup +"' and ID_KILN="+KILN+"";

                string sql = "select distinct data_source from t_dri_data_config where ID_KILN=" + KILN + " order by data_source";
                // select distinct data_group from t_dri_data_config;
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                // Adapter & Data Table
                QMCPDA = new OracleDataAdapter(sql, con);
                QMCPDA.Fill(dsPressure);
                QMCPDA.Dispose();

                if (dsPressure.Rows.Count > 0)
                {
                    foreach (DataRow Rows in dsPressure.Rows)
                    {
                        DATACONFIG obj = new DATACONFIG();

                        obj.DATA_SOURCE = (Rows["DATA_SOURCE"].ToString());

                        lstDATACONFIG.Add(obj);
                    }

                    var objlstDataConfig = lstDATACONFIG.Select(x => x.DATA_SOURCE).ToList();
                    return objlstDataConfig;
                }

            }
            catch (Exception ex)
            {

                return "";
            }


            return "";



        }


        [WebMethod]
        public object FillddlShowDataGroup(string Datasource, string KILN)
        {
            List<DATACONFIG> lstDATACONFIG = new List<DATACONFIG>();
            // var objlstDataConfig = lstDATACONFIG;
            // string tblName = getInputTableName(KILN);
            OracleDataAdapter QMCPDA;
            DataTable dsPressure = new DataTable();

            try
            {
                string sql = "select distinct data_group from t_dri_data_config where data_source='" + Datasource + "' and ID_KILN=" + KILN + "";

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                // Adapter & Data Table
                QMCPDA = new OracleDataAdapter(sql, con);
                QMCPDA.Fill(dsPressure);
                QMCPDA.Dispose();

                if (dsPressure.Rows.Count > 0)
                {
                    foreach (DataRow Rows in dsPressure.Rows)
                    {
                        DATACONFIG obj = new DATACONFIG();

                        obj.DATA_GROUP = (Rows["DATA_GROUP"].ToString());

                        lstDATACONFIG.Add(obj);
                    }

                    var objlstDataConfig = lstDATACONFIG.Select(x => x.DATA_GROUP).ToList();
                    return objlstDataConfig;
                }

            }
            catch (Exception ex)
            {

                return "";
            }


            return "";



        }
        [WebMethod]
        public object FillddlShowDataName(string Datagroup, string Datasource, string KILN)
        {
            List<DATACONFIG> lstDATACONFIG = new List<DATACONFIG>();
            // var objlstDataConfig = lstDATACONFIG;
            // string tblName = getInputTableName(KILN);
            OracleDataAdapter QMCPDA;
            DataTable dsPressure = new DataTable();

            try
            {
                string sql = "select distinct data_name from t_dri_data_config where data_group='" + Datagroup + "' and  data_source='" + Datasource + "' and ID_KILN=" + KILN + "";

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                // Adapter & Data Table
                QMCPDA = new OracleDataAdapter(sql, con);
                QMCPDA.Fill(dsPressure);
                QMCPDA.Dispose();

                if (dsPressure.Rows.Count > 0)
                {
                    foreach (DataRow Rows in dsPressure.Rows)
                    {
                        DATACONFIG obj = new DATACONFIG();

                        obj.DATA_NAME = (Rows["DATA_NAME"].ToString());

                        lstDATACONFIG.Add(obj);
                    }

                    var objlstDataConfig = lstDATACONFIG.Select(x => x.DATA_NAME).ToList();
                    return objlstDataConfig;
                }

            }
            catch (Exception ex)
            {

                return "";
            }


            return "";



        }
        [WebMethod]
        public object GetDCSGraphData( string KILN, string fromDate, string toDate, string Dataname )
        {
            DataTable dt = new DataTable();
            List<DATACONFIG> lstDATACONFIG = new List<DATACONFIG>();
            string fromDate1 = fromDate.Replace('T', ' ');
            string toDate1 = toDate.Replace('T', ' ');
          

            try
            {
                string sql = "SELECT  A.TAG_VALUE,A.DATA_TIME FROM V_DRI_DATA A JOIN T_DRI_DATA_CONFIG B on A.TAG_ID = B.ID_PLC_DATA_SEQ AND B.DATA_NAME ='" + Dataname +"' AND B.ID_KILN = " + KILN + " and DATA_TIME  >= TO_DATE('" + fromDate1 + "', 'yyyy-MM-dd HH24:MI') and DATA_TIME <= TO_DATE('" + toDate1 + "', 'yyyy-MM-dd HH24:MI') order by DATA_TIME ASC";




               








                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }




                OracleDataAdapter orcDA = new OracleDataAdapter(sql, con);
                orcDA.Fill(dt);
                orcDA.Dispose();

                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow Rows in dt.Rows)
                    {
                        DATACONFIG obj = new DATACONFIG();

                        obj.TAG_VALUE = (Rows["TAG_VALUE"].ToString());
                        obj.DATE_TIME= (Rows["DATA_TIME"].ToString());
                        lstDATACONFIG.Add(obj);
                    }

                    var objlstDataConfig = lstDATACONFIG.Select(i => new { i.TAG_VALUE, i.DATE_TIME }).ToList();
                    return objlstDataConfig;
                }

            }
            catch (Exception ex)
            {

                return "";
            }


            return "";



        }
    }
}

