﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DRI_JODA_TDT.MODELS
{
    public class USER
    {

        public string USER_NAME { get; set; }
        public string PASSWORD { get; set; }
    }
    public class Response
    {

        public string success { get; set; }
        public string message { get; set; }
    }

    public class MANUAL
    {

        public string Slno { get; set; }//get from hmi
                                        // public string Parameter { get; set; }//get
        public string UNIT { get; set; }// set to hmi
        public string ShiftA { get; set; }//get from hmi
        public string ShiftB { get; set; }//get from hmi
        public string ShiftC { get; set; }//get from hmi
        public string date { get; set; }// get from hmi
        public string ID_SEQ_MANUAL_DATA { get; set; } // set to hmi
        public string DESC_MANUAL_DATA { get; set; }// set to hmi
        public string MIN_VALUE { get; set; }// set to hmi
        public string MAX_VALUE { get; set; }/// set to hmi
        public string Value { get; set; }
        // public string DATA_RECEIVED_MOMENT { get; set; }
        public Nullable<System.DateTime> DATA_RECEIVED_MOMENT { get; set; }
        public string SHIFT { get; set; }
        public string ID_KILN { get; set; }

        public string ID { get; set; }
        public string PARAMETER { get; set; }
        public string SHIFT_A { get; set; }

        public string SHIFT_B { get; set; }

        public string SHIFT_C { get; set; }
        // public string DATE { get; set; }



    }
    //public string 


    public class ShiftData
    {

        public string ShiftA { get; set; }//get from hmi
        public string ShiftB { get; set; }//get from hmi
        public string ShiftC { get; set; }//get from hmi

        public string ID_SEQ_MANUAL_DATA { get; set; } // set to hmi
        public string DESC_MANUAL_DATA { get; set; }// set to hmi
        public string MIN_VALUE { get; set; }// set to hmi
        public string MAX_VALUE { get; set; }/// set to hmi
        public string UNIT { get; set; }// set to hmi

    }


    public class ActionLog
    {


        public string ID_KILN { get; set; }

        public DateTime ENTRY_DATE { get; set; }

        public string REMARKS { get; set; }


        public string FEM_ACTUAL { get; set; }
        public string ACTION_TAKEN { get; set; }
        public string FEM_PREDICTED { get; set; }

        public string Date { get; set; }
    }


    public class FORM_MODULE
    {


        public string MODULE_CODE { get; set; }
        public string MODULE_NAME { get; set; }
        public string MODULE_ICON { get; set; }
        public string MODULE_URL { get; set; }
        // public string MODULE_CODE { get; set; }

        public string MODULE_LEVEL { get; set; }

        public List<FormDetails> FormDetails { get; set; }
    }


    public class FormDetails
    {

        public string FORM_URL { get; set; }
        public string FORM_CODE { get; set; }
        public string FORM_ORDER { get; set; }
        public string FORM_NAME { get; set; }
        public string FORM_ICON { get; set; }
        public string MODULE_CODE { get; set; }
        public string FORM_LEVEL { get; set; }

    }

    public class DATACONFIG
    {

        public string DATA_NAME { get; set; }
        public string DATA_GROUP { get; set; }
        public string DATA_SOURCE { get; set; }
        public string DESCRIPTION { get; set; }
        public string ID_APP_TAG { get; set; }

        public string ID_PLC_DATA_SEQ { get; set; }

        public string TAG_VALUE { get; set; }

        public string DATE_TIME { get; set; }
    }

    public class TCDATADATE
    {
        public string DATA_TIME { get; set; }
        public List<TCDATA> lstTCdata { get; set; }
    }


    public class TCDATA
    {

        public string DATA_NAME { get; set; }
        public string DATA_TIME { get; set; }
        public string MINVALUE { get; set; }
        public string MAXVALUE { get; set; }
        public string AVGVALUE { get; set; }
        public string min_value { get; set; }
        public string max_value { get; set; }
    }
    public class LogBook
    {   public string TABLE_NAME { get; set; }
        public string DATA_SOURCE { get; set; }
        public string DATA_GROUP { get; set; }
        // [PrimaryKey]
        public string DATA_NAME { get; set; }
        public string MIN_VALUE { get; set; }
        public string MAX_VALUE { get; set; }
        public string ID_KILN { get; set; }
        public string ID_APP_TAG { get; set; }
        public List<LogBookGroup> lstDataGroup { get; set; }



    }


    public class ParamConfig
    {


        public string PARAM_NAME { get; set; }
        public string PARAM_DESC { get; set; }

        public string PARAM_ID { get; set; }
        //public string REASON { get; set; }
        //public DateTime FROM_DATE { get; set; }

    }




    public class LossBook
    {
        public string DURATION { get; set; }
        public string EQUIPMENT { get; set; }

        public string DEPARTMENT { get; set; }
        public string REASON { get; set; }
        public DateTime FROM_DATE { get; set; }
        public string ID_KILN { get; set; }
        public DateTime TO_DATE { get; set; }
        public string frmdate { get; set; }
        public string todate { get; set; }
        public string TYPE { get; set; }
    }

    public class LogBookGroup
    {   public string DESC_LAB_DATA { get; set; }
        public string TABLE_NAME { get; set; }
        public string DATA_SOURCE { get; set; }
        public string DATA_GROUP { get; set; }
        public string SHIFTA { get; set; }
        public string SHIFTB { get; set; }
        public string SHIFTC { get; set; }
        public string ON_DATE { get; set; }
        public string TO_DATE { get; set; }
        public string ID_SEQ_LAB_DATA { get; set; }
        public List<LogBookName> lstDataName { get; set; }

    }
    public class LogBookName
    {
        public string DATA_SOURCE { get; set; }
        public string DATA_GROUP { get; set; }
        public string DATA_NAME { get; set; }
        public string SHIFT_A { get; set; }
        public string SHIFT_B { get; set; }
        public string SHIFT_C { get; set; }
        public string AVGVALUE { get; set; }
        public string SHIFT { get; set; }
        public string ID_PLC_DATA_SEQ { get; set; }
        public string ON_DATE { get; set; }
        public string TO_DATE { get; set; }
        public string ID_KILN { get; set; }
        public string TAG_VALUE { get; set; }
        public string DATA_TIME { get; set; }
        public string MIN_VALUE { get; set; }
        public string MAX_VALUE { get; set; }
    }
    public class THERMAL
    {

       // public string ID_KILN { get; set; }
        public string Z1 { get; set; }
        public string Z2 { get; set; }
        public string Z3 { get; set; }
        public string Z4 { get; set; }
        public string Z5 { get; set; }
        public string Z6 { get; set; }
        public string Z7 { get; set; }
        public string Z8 { get; set; }
        public string Z9 { get; set; }

    }

    public class THERMALTIME
    {
        public DateTime TIME_STAMP { get; set; }
        public string DATE { get; set; }
        public string ID_KILN { get; set; }
    }


    public class VIEW
    {   
        public string VIEW_NAME { get; set; }
        public List<COLUMNVIEW> lstColumnView{get;set;}
    }

    public class COLUMNVIEW
    {
        public string COLUMN_NAME { get; set; }
        public string SHIFTA { get; set; }
        public string SHIFTB { get; set; }
        public string SHIFTC { get; set; }
    }

}
       
   