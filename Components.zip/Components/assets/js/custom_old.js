﻿$(document).ready(function () {
  var elements = document.getElementsByClassName("side-item");
  var check = document.getElementById("sidebar");
  debugger;
  // Get the current URL
  const currentURL = window.location.href;

  // Extract the page name from the URL
  const pageName = currentURL.substring(currentURL.lastIndexOf("/") + 1);

  // Log the page name to the console
  //if(localStorage.getItem('colStore') == 1){
  //  toggleMenu(check,elements);
  //}
  //var el = document.getElementsByClassName("side-item");
  //if (pageName == "" || pageName == "index.html") {
  //  el[0].classList.add("sactive");
  //}
  //if (pageName == "all-users.html") {
  //  el[1].classList.add("sactive");
  //}
  //if (pageName == "all-scores.html") {
  //  el[2].classList.add("sactive");
  //}
  //if (pageName == "settings.html") {
  //  el[3].classList.add("sactive");
  //}

  
  $("#btnSideCollapse").click(function () {
    debugger;
    
    toggleMenu(check,elements);
  });
});

//=================================== TOGGLE FUNCTION ======================================
function toggleMenu(check,elements){
  if (check.classList.contains("sidebar") == true) {
    localStorage.setItem("colStore", 1);
    $("#sidebar").removeClass("sidebar");
    $("#sidebar").addClass("sidebar-collapsed");
    for (var i = 0; i < elements.length; i++) {
      elements[i].classList.remove("justify-content-start");
      elements[i].classList.add("justify-content-center");
    }
    $("#tog").removeClass("fa-angle-left");
    $("#tog").addClass("fa-angle-right");

    document.getElementById("main-area").style.marginLeft = "60px";
  } else {
    $("#sidebar").removeClass("sidebar-collapsed");
    $("#sidebar").addClass("sidebar");
    localStorage.clear();
    for (var i = 0; i < elements.length; i++) {
      elements[i].classList.remove("justify-content-center");
      elements[i].classList.add("justify-content-start");
    }
    document.getElementById("main-area").style.marginLeft = "180px";
    $("#tog").removeClass("fa-angle-right");
    $("#tog").addClass("fa-angle-left");
  }
}

function togStyle(){
  $("#sidebar").removeClass("sidebar");
  $("#sidebar").addClass("sidebar-collapsed");
  for (var i = 0; i < elements.length; i++) {
    elements[i].classList.remove("justify-content-start");
    elements[i].classList.add("justify-content-center");
  }

  document.getElementById("main-area").style.marginLeft = "60px";
}



//-------------------------------------------------



function getControlPara(kiln)
{
    debugger;
    //var kiln = kiln;
    var kilnNo = (kiln.substring(2)).toUpperCase();
    kilnNo = kilnNo.substring(0,4)+"-"+kilnNo.substring(4,5)
    document.getElementById('cpTitle').innerHTML=kilnNo+" CONTROLABLE PARAMETERS";
    if (kiln != "" || dia != null) {
        $.ajax({
            type: "POST",
            url: "DRI.asmx/QMcontrollablePara",
            data:"{'KILN':'" +kilnNo +"'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                debugger;
                var cpData = response.d[0];
                var PAB_AirFlow        = cpData.PAB_AirFlow;      
                var SAB1_AirFlow       = cpData.SAB1_AirFlow; 
                var SAB2_AirFlow       = cpData.SAB2_AirFlow;
                var SAB3_AirFlow       = cpData.SAB3_AirFlow;    
                var SAB4_AirFlow       = cpData.SAB4_AirFlow;     
                var SAB5_AirFlow       = cpData.SAB5_AirFlow;    
                var SAB6_AirFlow       = cpData.SAB6_AirFlow;    
                var SAB7_AirFlow       = cpData.SAB7_AirFlow;    
                var SAB8_AirFlow       = cpData.SAB8_AirFlow;    
                var SAB9_AirFlow       = cpData.SAB9_AirFlow;    
                var SAB10_AirFlow      = cpData.SAB10_AirFlow;    
                var KILN_RPM           = cpData.KILN_RPM;         
                var FeedCoalRate       = cpData.FeedCoalRate;     
                var InjectionCoalRate  = cpData.InjectionCoalRate;
                var IronOreFeedRate    = cpData.IronOreFeedRate;  
                var DolomiteFeedRate   = cpData.DolomiteFeedRate; 

                if (SAB1_AirFlow =="" || SAB1_AirFlow ==null) {
                    SAB1_AirFlow=0;
                }
                if (SAB2_AirFlow =="" || SAB2_AirFlow ==null) {
                    SAB2_AirFlow=0;
                }
                if (SAB3_AirFlow =="" || SAB3_AirFlow ==null) {
                    SAB3_AirFlow=0;
                }
                if (SAB4_AirFlow =="" || SAB4_AirFlow ==null) {
                    SAB4_AirFlow=0;
                }
                if (SAB5_AirFlow =="" || SAB5_AirFlow ==null) {
                    SAB5_AirFlow=0;
                }
                if (SAB6_AirFlow =="" || SAB6_AirFlow ==null) {
                    SAB6_AirFlow=0;
                }
                if (SAB7_AirFlow =="" || SAB7_AirFlow ==null) {
                    SAB7_AirFlow=0;
                }
                if (SAB8_AirFlow =="" || SAB8_AirFlow ==null) {
                    SAB8_AirFlow=0;
                }
                if (SAB9_AirFlow =="" || SAB9_AirFlow ==null) {
                    SAB9_AirFlow=0;
                }
                if (SAB10_AirFlow =="" || SAB10_AirFlow ==null) {
                    SAB10_AirFlow=0;
                }

                // Binding the Controll Parameter Data in Tables
                document.getElementById('kilnRpmAct').innerHTML = KILN_RPM;
                document.getElementById('feedCoalRateAct').innerHTML = FeedCoalRate+ " T/Hr";
                document.getElementById('ironOreRateAct').innerHTML = IronOreFeedRate+ " T/Hr";
                document.getElementById('injectionCoalRateAct').innerHTML = InjectionCoalRate+ " T/Hr";
                document.getElementById('dolamiteRateAct').innerHTML = InjectionCoalRate+ " T/Hr";

                document.getElementById('PABAct').innerHTML = PAB_AirFlow+ " N/m<sup>3</sup>";
                document.getElementById('sab01Act').innerHTML = SAB1_AirFlow+ " N/m<sup>3</sup>";
                document.getElementById('sab02Act').innerHTML = SAB2_AirFlow + " N/m<sup>3</sup>";
                document.getElementById('sab03Act').innerHTML = SAB3_AirFlow + " N/m<sup>3</sup>";
                document.getElementById('sab04Act').innerHTML = SAB4_AirFlow + " N/m<sup>3</sup>";
                document.getElementById('sab05Act').innerHTML = SAB5_AirFlow + " N/m<sup>3</sup>";
                document.getElementById('sab06Act').innerHTML = SAB6_AirFlow + " N/m<sup>3</sup>";
                document.getElementById('sab07Act').innerHTML = SAB7_AirFlow + " N/m<sup>3</sup>";
                document.getElementById('sab08Act').innerHTML = SAB8_AirFlow + " N/m<sup>3</sup>";
                document.getElementById('sab09Act').innerHTML = SAB9_AirFlow + " N/m<sup>3</sup>";
                document.getElementById('sab10Act').innerHTML = SAB10_AirFlow+ " N/m<sup>3</sup>";
            },
            error: function (jqxhr) {
                alert(jqxhr.responseText);
            },
        });
    }
    else {
       
        return "";
    }
      
}


//============================================ AJAX FUNCTION FOR Fe-M VS TIME DATA ===================================================

function getFeVsTimeData(kiln)
{
    debugger;
    //var kiln = kiln;
    var kilnNo = (kiln.substring(2)).toUpperCase();
    kilnNo = kilnNo.substring(0,4)+"-"+kilnNo.substring(4,5)
    document.getElementById('fkTitle').innerHTML=kilnNo+" FeM VS TIME";
    if (kiln != "") {
        $.ajax({
            type: "POST",
            url: "DRI.asmx/QMFeMvsTime",
            data:"{'KILN':'" +kilnNo +"'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                debugger;
                if (response.d == null) {
                    alert("No data found");
                }
                if (response.d != null || response.d != "" || response.d.length != 0) {
                    var FeMtChartData = response.d;
                    //var lineChartData = response.d.slice(0, -1);
                    //var FeMtChartData = response.d[(response.d.length) - 1];
              
                    FeMvsTimeGraph(FeMtChartData);
                }
                
            },
            error: function (jqxhr) {
                alert(jqxhr.responseText);
            },
        });
    }
    else {
       
        return "";
    }
      
}

//==================================================================================================================


//================================ AJAX FUNCTION FOR FETCHING ACERATION MODEL'S TC TREND ===========================

function getAccProTCTrend(TC)
{
    debugger;
    //var kiln = kiln;  ftKiln1  ap2dT1 tcTrendT1
    var TC = (TC.substring(7)).toUpperCase();
  
    //kilnNo = kilnNo.substring(0,4)+"-"+kilnNo.substring(4,5)
    document.getElementById('aptcTrendTitle').innerHTML=TC+" TC TREND";
    if (TC != "") {
        $.ajax({
            type: "POST",
            url: "DRI.asmx/acerationModelTCTrend",
            data:"{'TC':'" +TC +"'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                debugger;
                if (response.d == null) {
                    alert("No data found");
                }
                if (response.d != null || response.d != "" || response.d.length != 0) {
                    var tcTrendData = response.d;
              
                    tcTrendGraph(tcTrendData,TC)
                }
                
            },
            error: function (jqxhr) {
                alert(jqxhr.responseText);
            },
        });
    }
    else {
       
        return "";
    }
      
}

//=============================================================================================================================



//================================ AJAX FUNCTION FOR FETCHING ACERATION MODEL'S 2D PROFILE ===========================

function getAccPro2D(kiln)
{
    debugger;
    
    document.getElementById('acc2Ddate').classList.remove("d-none");
    document.getElementById('acc2Ddate').classList.add("d-block");
    //var kiln = kiln;  ftKiln1  ap2dT1 tcTrendT1 acc2DKiln1
    var kiln = (kiln.substring(5)).toUpperCase();
  
    //kilnNo = kilnNo.substring(0,4)+"-"+kilnNo.substring(4,5)
    document.getElementById('acc2DProfileTitle').innerHTML=kiln+" ACCERATION 2D PROFILE";

    
    //ON DATE CHANGE
    $("#acc2Ddate").change(function(){
        debugger;
        var acc2DDate = document.getElementById('acc2Ddate').value;
        if (kiln != "") {
            $.ajax({
                type: "POST",
                url: "DRI.asmx/accerationModel2D",
                //data:"{'kiln':'" +kiln +"'}",
                data:"{ 'kiln':'" + kiln + "','acc2DDate':'" + acc2DDate + "'}",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (response) {
                    document.getElementById('acc2DProfileTitle').innerHTML=kiln+" ACCERATION 2D PROFILE FROM "+ acc2DDate;
                    debugger;
                    if (response.d == null) {
                        alert("No data found");
                    }
                    if (response.d != null || response.d != "" || response.d.length != 0) {
                        var acc2DProfileData = response.d;
              
                        acc2DProfileGraph(acc2DProfileData,kiln)
                    }
                
                },
                error: function (jqxhr) {
                    alert(jqxhr.responseText);
                },
            });
        }
        else {
       
            return "";
        }
    })
    
      
}

//=============================================================================================================================

//======================================================= GRAPH FOR FeM VS TIME ===============================================
function FeMvsTimeGraph(GraphData) {
    debugger;
    var FeMvsTimeGraphList = [];
    var FeMvsTimeGraphList_FE_M = [];
    for (var i = 0; i < GraphData.length; i++) {
        var Datalist = GraphData[i];
        if (Datalist.FEM16 == "" || Datalist.FEM16==null) {
            FeMvsTimeGraphList.push({
                label: Datalist.RUN_TIME,
                y: Datalist.FEM16,
                //markerType: "square", 
                //markerColor: "red",
                //markerSize: 8
            });
        }
        else {
            FeMvsTimeGraphList.push({
                label: Datalist.RUN_TIME,
                y: Datalist.FEM16,
                //markerType: "square", 
                //markerColor: "red",
                //markerSize: 8
            });
        }
        FeMvsTimeGraphList_FE_M.push({
            label:Datalist.RUN_TIME,
            y:Datalist.FE_M
        });
    }
    chart2 = new CanvasJS.Chart("chartContainer2",
    {
        zoomEnabled: true,
        animationEnabled: true,
        //title: {
        //    text: "FeM VS TIME",
        //    fontColor: "#ffffff",
        //    fontFamily: "Arial",
        //    fontWeight: "bold"
        //},
        backgroundColor: "#292F45",
        theme: "theme3",
        exportEnabled: false,
        zoomType: "x",
        interactivityEnabled: true,
        //height: 400,
        //width:1200,
        toolTip:
           {
               shared: true,

           },

        legend: {
            cursor: "pointer",
            verticalAlign: "top",
            horizontalAlign: "center",
            fontColor: "#ffffff",
            FontWeight: "bolder",
            FontSize: 15,
            itemMaxWidth: 1000,

        },
        axisX:
            {
                // valueFormatString: "MM/dd/yy HH:mm",
                lineColor: "black",
                titleFontColor: "#ffffff",
                labelFontColor: "#ffffff",
                labelFontSize: "12",
                titleFontSize: "12",
                titleFontWeight: "normal",
                labelFontWeight: "normal",
                gridThickness: 0,
                tickColor: "#ffffff",
                title: "TIME STAMP"

            },

        axisY: [

            {
                title: "VALUES",
                lineColor: "black",
                titleFontColor: "#ffffff",
                labelFontColor: "#ffffff",
                labelFontSize: "12",
                titleFontSize: "12",
                titleFontWeight: "normal",
                labelFontWeight: "normal",
                gridThickness: 0,
                tickColor: "black",
                minimum: 0.00,
                //maximum: 85.00,
                interval: 25

            }],

        dataPointMaxWidth: 20,

        data: [{
            //click: function (e) {

            //    viewDataPointGraph(e);
            //},
            
            lineThickness: 2,
            markerType: "cross",
            markerColor: "#FFFFFF",
            type: "line",
            name: "FEM16",
            showInLegend: true,
            axisYIndex: 0,
            indexLabel: "{y}",
            indexLabelFontSize: 0,
            indexLabelPlacement: "top",
            indexLabel: "FLAGGED",
            axisYType: "primary",
            color: "#1968B3",
            dataPoints: FeMvsTimeGraphList

        },
        
        {
            lineThickness: 2,
            markerType: "cross",
            markerColor: "#FFFFFF",
            type: "line",
            name: "FE_M",
            showInLegend: true,
            axisYIndex: 0,
            indexLabel: "{y}",
            indexLabelFontSize: 0,
            indexLabelPlacement: "top",
            indexLabel: "FLAGGED",
            axisYType: "primary",
            color: "#F00000",
            dataPoints: FeMvsTimeGraphList_FE_M
        
        }]
    });

    chart2.render();


}

//=============================================================================================================================



//======================================================= GRAPH FOR TC TREND ===============================================
function tcTrendGraph(GraphData, TC) 
{
    debugger;
    var tcTrendGraphList = [];
    var ucl = [];
    var lcl = [];
    //var FeMvsTimeGraphList_FE_M = [];
    for (var i = 0; i < GraphData.length; i++) {
        var Datalist = GraphData[i];
        if (Datalist.TCSelect == "" || Datalist.TCSelect==null) {
            tcTrendGraphList.push({
                label: Datalist.RUN_TIME,
                y: Datalist.TCSelect,
                
            });
        }
        else {
            tcTrendGraphList.push({
                label: Datalist.RUN_TIME,
                y: Datalist.TCSelect,
            });
        }
        ucl.push({
            label: Datalist.RUN_TIME,
            y: Datalist.ucl
        });
        lcl.push({
            label: Datalist.RUN_TIME,
            y: Datalist.lcl
        });
    }
    chart3 = new CanvasJS.Chart("chartContainer3",
    {
        zoomEnabled: true,
        animationEnabled: true,
        
        backgroundColor: "#292F45",
        theme: "theme3",
        exportEnabled: false,
        zoomType: "x",
        interactivityEnabled: true,
        toolTip:
           {
               shared: true,

           },

        legend: {
            cursor: "pointer",
            verticalAlign: "top",
            horizontalAlign: "center",
            fontColor: "#ffffff",
            FontWeight: "bolder",
            FontSize: 15,
            itemMaxWidth: 1000,

        },
        axisX:
            {
                lineColor: "black",
                titleFontColor: "#ffffff",
                labelFontColor: "#ffffff",
                labelFontSize: "12",
                titleFontSize: "12",
                titleFontWeight: "normal",
                labelFontWeight: "normal",
                gridThickness: 0,
                tickColor: "#ffffff",
                title: "TIME STAMP"

            },

        axisY: [

            {
                title: "VALUES",
                lineColor: "black",
                titleFontColor: "#ffffff",
                labelFontColor: "#ffffff",
                labelFontSize: "12",
                titleFontSize: "12",
                titleFontWeight: "normal",
                labelFontWeight: "normal",
                gridThickness: 0,
                tickColor: "black",
                //minimum: 0.00,
                //maximum: 1500,
                //interval: 200

            }],

        dataPointMaxWidth: 20,

        data: [{
            //click: function (e) {

            //    viewDataPointGraph(e);
            //},
            
            lineThickness: 2,
            markerType: "cross",
            markerColor: "#FFFFFF",
            type: "line",
            name: TC,
            showInLegend: true,
            axisYIndex: 0,
            indexLabel: "{y}",
            indexLabelFontSize: 0,
            indexLabelPlacement: "top",
            indexLabel: "FLAGGED",
            axisYType: "primary",
            color: "#1968B3",
            dataPoints: tcTrendGraphList

        },
        {
            lineThickness: 1,
            markerType: "none",
            markerColor: "blue",
            type: "line",
            name: "MAXIMUM",
            showInLegend: false,
            axisYIndex: 0,
            indexLabel: "{y}",
            indexLabelFontSize: 0,
            indexLabelPlacement: "top",
            axisYType: "primary",
            color: "green",
            dataPoints: ucl

        },
        {
            lineThickness: 1,
            markerType: "none",
            markerColor: "blue",
            type: "line",
            name: "MINIMUM",
            showInLegend: false,
            axisYIndex: 0,
            indexLabel: "{y}",
            indexLabelFontSize: 0,
            indexLabelPlacement: "top",
            axisYType: "primary",
            color: "red",
            dataPoints: lcl

        }]
    });

    chart3.render();


}

//=============================================================================================================================



//======================================================= GRAPH FOR ACC 2-D TREND ===============================================
function acc2DProfileGraph(GraphData, Kiln) 
{
    debugger;
    var accTC5List = [];
    var accTC6List = [];
    var accTC7List = [];
    var accTC8List = [];
    var accTC9List = [];
    var accTC10List = [];
    var accTC11List = [];
    for (var i = 0; i < GraphData.length; i++) {
        var Datalist = GraphData[i];
       
        accTC5List.push({
              label: Datalist.ENTRY_DATE,
              y: Datalist.TC5_ACC
        });

        accTC6List.push({
            label: Datalist.ENTRY_DATE,
            y: Datalist.TC6_ACC
        });

        accTC7List.push({
            label: Datalist.ENTRY_DATE,
            y: Datalist.TC7_ACC
        });
        accTC8List.push({
            label: Datalist.ENTRY_DATE,
            y: Datalist.TC8_ACC
        });
        accTC9List.push({
            label: Datalist.ENTRY_DATE,
            y: Datalist.TC9_ACC
        });
        accTC10List.push({
            label: Datalist.ENTRY_DATE,
            y: Datalist.TC10_ACC
        });
        accTC11List.push({
            label: Datalist.ENTRY_DATE,
            y: Datalist.TC11_ACC
        });
    }
    chart4 = new CanvasJS.Chart("chartContainer4",
    {
        zoomEnabled: true,
        animationEnabled: true,
        
        backgroundColor: "#292F45",
        theme: "theme3",
        exportEnabled: false,
        zoomType: "x",
        interactivityEnabled: true,
        toolTip:
           {
               shared: true,

           },

        legend: {
            cursor: "pointer",
            verticalAlign: "top",
            horizontalAlign: "center",
            fontColor: "#ffffff",
            FontWeight: "bolder",
            FontSize: 15,
            itemMaxWidth: 1000,

        },
        axisX:
            {
                lineColor: "black",
                titleFontColor: "#ffffff",
                labelFontColor: "#ffffff",
                labelFontSize: "12",
                titleFontSize: "12",
                titleFontWeight: "normal",
                labelFontWeight: "normal",
                gridThickness: 0,
                tickColor: "#ffffff",
                title: "ENTRY DATE"

            },

        axisY: [

            {
                title: "VALUES",
                lineColor: "black",
                titleFontColor: "#ffffff",
                labelFontColor: "#ffffff",
                labelFontSize: "12",
                titleFontSize: "12",
                titleFontWeight: "normal",
                labelFontWeight: "normal",
                gridThickness: 0,
                tickColor: "black",
                //minimum: 0.00,
                //maximum: 1500,
                //interval: 200

            }],

        dataPointMaxWidth: 20,

        data: [{
            //click: function (e) {

            //    viewDataPointGraph(e);
            //},
            
            lineThickness: 2,
            //markerType: "cross",
            //markerColor: "#FFFFFF",
            type: "line",
            name: "TC5_ACC",
            showInLegend: true,
            axisYIndex: 0,
            indexLabel: "{y}",
            indexLabelFontSize: 0,
            indexLabelPlacement: "top",
            indexLabel: "FLAGGED",
            axisYType: "primary",
            color: "#FFB533",
            dataPoints: accTC5List

        },
        {
            lineThickness: 2,
            //markerType: "cross",
            //markerColor: "#FFFFFF",
            type: "line",
            name: "TC6_ACC",
            showInLegend: true,
            axisYIndex: 0,
            indexLabel: "{y}",
            indexLabelFontSize: 0,
            indexLabelPlacement: "top",
            indexLabel: "FLAGGED",
            axisYType: "primary",
            color: "#FF3333",
            dataPoints: accTC6List

        },
        {
            lineThickness: 2,
            //markerType: "cross",
            //markerColor: "#FFFFFF",
            type: "line",
            name: "TC7_ACC",
            showInLegend: true,
            axisYIndex: 0,
            indexLabel: "{y}",
            indexLabelFontSize: 0,
            indexLabelPlacement: "top",
            indexLabel: "FLAGGED",
            axisYType: "primary",
            color: "#5D6D7E",
            dataPoints: accTC7List

        },
        {
            lineThickness: 2,
            //markerType: "cross",
            //markerColor: "#FFFFFF",
            type: "line",
            name: "TC8_ACC",
            showInLegend: true,
            axisYIndex: 0,
            indexLabel: "{y}",
            indexLabelFontSize: 0,
            indexLabelPlacement: "top",
            indexLabel: "FLAGGED",
            axisYType: "primary",
            color: "#1968B3",
            dataPoints: accTC8List

        },
        {
            lineThickness: 2,
            //markerType: "cross",
            //markerColor: "#FFFFFF",
            type: "line",
            name: "TC9_ACC",
            showInLegend: true,
            axisYIndex: 0,
            indexLabel: "{y}",
            indexLabelFontSize: 0,
            indexLabelPlacement: "top",
            indexLabel: "FLAGGED",
            axisYType: "primary",
            color: "#0E6655",
            dataPoints: accTC9List

        },
        {
            lineThickness: 2,
            //markerType: "cross",
            //markerColor: "#FFFFFF",
            type: "line",
            name: "TC10_ACC",
            showInLegend: true,
            axisYIndex: 0,
            indexLabel: "{y}",
            indexLabelFontSize: 0,
            indexLabelPlacement: "top",
            indexLabel: "FLAGGED",
            axisYType: "primary",
            color: "#C0392B",
            dataPoints: accTC10List
        },
        {
            lineThickness: 2,
            //markerType: "cross",
            //markerColor: "#FFFFFF",
            type: "line",
            name: "TC11_ACC",
            showInLegend: true,
            axisYIndex: 0,
            indexLabel: "{y}",
            indexLabelFontSize: 0,
            indexLabelPlacement: "top",
            indexLabel: "FLAGGED",
            axisYType: "primary",
            color: "#FF00B6",
            dataPoints: accTC11List

        },

        ]
    });

    chart4.render();


}

//=============================================================================================================================