﻿










var acc2DProfileData;
var acc2DVolData;
//var KilnNo = 1;
 var KilnNo = 5;
var graphModal = 0;
var ThreeD_Data;
var tcTrendData;
var FeMtChartData;

var graphdata_1;
var graphdata_Pressure_1;
var FemData_1;
var BHData_1;
var graphdata_2;
var graphdata_Pressure_2;
var FemData_2;
var BHData_2;

var graphdata_3;
var graphdata_Pressure_3;
var FemData_3;
var BHData_3;

var dataSulphur1
var dataChar1;
var dataBedHeight1;
var dataCoCo21;

var dataSulphur2;
var dataChar2;
var dataBedHeight2;
var dataCoCo22;

var dataSulphur3;
var dataChar3;
var dataBedHeight3;
var dataCoCo23;
var tab = "qualityModel";
var a = setInterval(callMethod, 5 * 60 * 1000);

/*$(document).ready(function ()*/

document.addEventListener("DOMContentLoaded",function()

{
    //const navigationType = performance.getEntriesByType('navigation')[0].type;
    //if (navigationType !== 'reload') {

    //    GetOnLoadSideBar();
    //    alert("dom loaded");
    //}
    //else {

    //    alert("reloaded");
    //    GetOnLoadSideBar();;
    //    getControlPara(3);
    //    return;
    //}
   
   
    
    debugger;
   
    


    var dt = new Date();
    $("#TimeandDate").html("CLOCK TIME" + " " + dt.toLocaleString());
   
    function UpdateDatetime()
    {
        var dt = new Date();
        $("#TimeandDate").html("CLOCK TIME" + " " + dt.toLocaleString());
        
    }

   
   

  
    //var b = setInterval(PlotLMonitoringTable(KilnNo), 1 * 60 * 10000);

  
    setInterval(UpdateDatetime, 1000); 
   // GetOnLoadSideBar();
   

    var elements = document.getElementsByClassName("side-item");
    var check = document.getElementById("sidebar");
   

    var dropdown = document.getElementsByClassName("dropdown-btn");
    var i;
    function btnclick() {
        for (i = 0; i < dropdown.length; i++) {
            dropdown[i].addEventListener("click", function () {
                alert("hello");
                this.classList.toggle("active");
                var dropdownContent = this.nextElementSibling;
                if (dropdownContent.style.display === "block") {
                    dropdownContent.style.display = "none";
                } else {
                    dropdownContent.style.display = "block";
                }
            }
            );
        }
    }

    //debugger;

    //function GetOnLoadSideBar() {

    //    debugger;
    //    $.ajax
    //        ({
    //            type: 'POST',
    //            url: 'FormModuleService.asmx/GetFORMMODULEData',
    //            data: '{ }',
    //            contentType: 'application/json; charset=utf-8',
    //            dataType: 'json',
    //            success: function (data) {
    //                GetSidebarData(data.d)
    //            }
    //        });

    //}


    

    $("#btnSideCollapse").click(function () {
        //debugger;

        toggleMenu(check, elements)
    });
    $(".allownumeric").on("keypress keyup blur", function (event) {
        $(this).val($(this).val().replace(/[^\d].+/, ""));
        if ((event.which < 48 || event.which > 57)) {
            event.preventDefault();
        }
    });
    $("#btnLogin").click(function () {
        //debugger;
        USERID = document.getElementById('txtUser').value;

        PASSWORD = document.getElementById('txtPassword').value;


        if (USERID == "" || PASSWORD == "") {

            alert("UserID/Password can't be Empty")
        }

        else {



            $.ajax({
                type: "POST",
                url: "LoginService.asmx/LoginValidation",
                data: "{'USERID':'" + USERID + "','PASSWORD':'" + PASSWORD + "'}",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (response) {
                    debugger;
                    var data = response.d;
                    if (data == "True")
                    {
                        let tab = 'Quality';
                        let kiln = KilnNo;
                        //let url = `index.html?tab=${tab}&kiln=${kiln}`;
                       // console.log(url); // Outputs: index.html?var1=Value1&var2=Value2
                        window.location.href = "index.html";


                        //window.location.href = "index.html?Quality&kiln=" + KilnNo +"";
                         //window.location.href = url;
                    }

                    else if (data == "False") {

                        alert("UserID/Password Incorrect!");
                    }


                    // alert(response.d);

                },
                error: function (jqxhr) {
                    alert(jqxhr.responseText);
                },
            });
        }

    });

   // -----------------------------QUALITY--------------------------------------------//
    $("#pills-QMKiln1-tab").click(function () {
       // preventDefault();
        KilnNo = 1;
        
        $("#rd_Bed1").prop("checked", true);
        getControlPara(KilnNo);
       // window.location.href = "index.html?kiln=" + KilnNo + "";
        //let tab = 'Quality';
        //let kiln = KilnNo;
        //let tabCid = 'pills-QMKiln1';
        //let url = `index.html?tab=${tab}&kiln=${kiln}&tabCid=${tabCid}`;
        // Push the new state onto the browser's history
       // window.history.pushState({ path: url }, '', url);

        // Prevent the default link click behavior
       // e.preventDefault();
    });
    
    $("#pills-QMKiln2-tab").click(function () {
        KilnNo = 2;
        
        $("#rd_Bed2").prop("checked", true);
        getControlPara(KilnNo);
        //let tab = 'Quality';
        //let kiln = KilnNo;
        //let url = `index.html?tab=${tab}&kiln=${kiln}`;
        //// Push the new state onto the browser's history
        //window.history.pushState({ path: url }, '', url);

        // Prevent the default link click behavior
       // e.preventDefault();
    });
    
    $("#pills-QMKiln3-tab").click(function () {
        KilnNo = 3;
        
       
        $("#rd_Bed3").prop("checked", true);
        getControlPara(KilnNo);
        //let tab = 'Quality';
        //let kiln = KilnNo;
        //let url = `index.html?tab=${tab}&kiln=${kiln}`;
        //// Push the new state onto the browser's history
        //window.history.pushState({ path: url }, '', url);

        // Prevent the default link click behavior
        //e.preventDefault();
    });

    $("#pills-QMKiln4-tab").click(function () {
        KilnNo = 4;
        
     
       
        $("#rd_Bed4").prop("checked", true);
        getControlPara(KilnNo);
        //let tab = 'Quality';
        //let kiln = KilnNo;
        //let url = `index.html?tab=${tab}&kiln=${kiln}`;
        //// Push the new state onto the browser's history
        //window.history.pushState({ path: url }, '', url);

        // Prevent the default link click behavior
        //e.preventDefault();
    });

    $("#pills-QMKiln5-tab").click(function () {
        KilnNo = 5;
      
        $("#rd_Bed5").prop("checked", true);
        getControlPara(KilnNo);
        //let tab = 'Quality';
        //let kiln = KilnNo;
        //let url = `index.html?tab=${tab}&kiln=${kiln}`;
        //// Push the new state onto the browser's history
        //window.history.pushState({ path: url }, '', url);

        // Prevent the default link click behavior
        //e.preventDefault();
    });
    $("#pills-QMKiln6-tab").click(function () {
        KilnNo = 6;
       
        $("#rd_Bed6").prop("checked", true);
        getControlPara(KilnNo);
        //let tab = 'Quality';
        //let kiln = KilnNo;
        //let url = `index.html?tab=${tab}&kiln=${kiln}`;
        //// Push the new state onto the browser's history
        //window.history.pushState({ path: url }, '', url);

        // Prevent the default link click behavior
        //e.preventDefault();
    });
 // -----------------------end------QUALITY--------------------------------------------//


    $("#v-pills-aceration-tab").click(function () {


        //alert("hi");
        tab = "acerationModel";
        getAccPro2D(KilnNo);
        // get_3D_Data(KilnNo);
    });

   //--------------------------Start--------Acceration Model-----------------------//

    

    $("#pills-AMKiln1-tab").click(function ()
    {
        KilnNo = 1;
        getAccPro2D(KilnNo);
        // get_3D_Data(KilnNo);
    });
    $("#pills-AMKiln2-tab").click(function () {
        KilnNo = 2;
        getAccPro2D(KilnNo);
        // get_3D_Data(KilnNo);
    });

    $("#pills-AMKiln3-tab").click(function () {
        KilnNo = 3;
        getAccPro2D(KilnNo);
        //get_3D_Data(KilnNo);
    });

    $("#pills-AMKiln4-tab").click(function () {
        KilnNo = 4;
        getAccPro2D(KilnNo);
        //get_3D_Data(KilnNo);
    });
    $("#pills-AMKiln5-tab").click(function () {
        KilnNo = 5;
        getAccPro2D(KilnNo);
        //get_3D_Data(KilnNo);
    });
    $("#pills-AMKiln6-tab").click(function () {
        KilnNo = 6;
        getAccPro2D(KilnNo);
        //get_3D_Data(KilnNo);
    });
    
      //--------------------------End--------Acceration Model-----------------------//

    //--------------------------Start--------REPORT-----------------------//

    $("#pills-RPKiln1-tab").click(function () {
        KilnNo = 1
        getReportData(KilnNo);
    });

    $("#pills-RPKiln2-tab").click(function () {
        KilnNo = 2
        getReportData(KilnNo);
    });
    $("#pills-RPKiln3-tab").click(function () {
        KilnNo = 3
        getReportData(KilnNo);
        /*  //*/
});

    $("#pills-RPKiln4-tab").click(function () {
        KilnNo = 4
        getReportData(KilnNo);
    });
    $("#pills-RPKiln5-tab").click(function () {
        KilnNo = 5;
        getReportData(KilnNo);
    });

    $("#pills-RPKiln6-tab").click(function () {
        KilnNo = 6
        getReportData(KilnNo);
    });
    //--------------------------END--------REPORT-----------------------//
    
    
    //--------------------------start--------TREND-----------------------//

    $("#pills-TKiln1-tab").click(function () {  //Trends Kiln 1 button      
        KilnNo = 1;
        document.getElementById("chartTrends1").innerHTML = "";
    });
    $("#pills-TKiln2-tab").click(function () {  //Trends Kiln 2 button      
        KilnNo = 2;
        document.getElementById("chartTrends1").innerHTML = "";
    });
    $("#pills-TKiln3-tab").click(function () {  //Trends Kiln 3 button      
        KilnNo = 3;
        document.getElementById("chartTrends1").innerHTML = "";
    });
    $("#pills-TKiln4-tab").click(function () {  //Trends Kiln 3 button      
        KilnNo = 4;
        document.getElementById("chartTrends1").innerHTML = "";
    });
    $("#pills-TKiln5-tab").click(function () {  //Trends Kiln 1 button      
        KilnNo = 5;
        document.getElementById("chartTrends1").innerHTML = "";
    });
    $("#pills-TKiln6-tab").click(function () {  //Trends Kiln 3 button      
        KilnNo = 6;
        document.getElementById("chartTrends1").innerHTML = "";
    });
     //---------------------end-------------TREND-----------------------//
    //--------------------------start--------MANUAL-----------------------//
   
    
    $("#pills-MKiln1-tab").click(function () {  //Trends Kiln 2 button      
        KilnNo = 1;
        getManualData(KilnNo);
        // document.getElementById("chartTrends1").innerHTML = "";
    });
    $("#pills-MKiln2-tab").click(function () {  //Trends Kiln 2 button      
        KilnNo = 2;
        getManualData(KilnNo);
        // document.getElementById("chartTrends1").innerHTML = "";
    });


    $("#pills-MKiln3-tab").click(function () {  //Trends Kiln 3 button      
        KilnNo = 3;
        getManualData(KilnNo);
        // document.getElementById("chartTrends1").innerHTML = "";
    });
    $("#pills-MKiln4-tab").click(function () {  //Trends Kiln 3 button      
        KilnNo = 4;
        //document.getElementById("chartTrends1").innerHTML = "";
        getManualData(KilnNo);
    });
    $("#pills-MKiln5-tab").click(function () {  //Trends Kiln 1 button      
        KilnNo = 5;
        getManualData(KilnNo);
        // document.getElementById("chartTrends1").innerHTML = "";
    });
    $("#pills-MKiln6-tab").click(function () {  //Trends Kiln 3 button      
        KilnNo = 6;

        getManualData(KilnNo);
    });

    //--------------------------end--------MANUAL-----------------------//

    $("#v-pills-Manuals-tab").click(function () {  //Trends Kiln 3 button
        KilnNo = 5;
        alert(kilnNo);

        getManualData(KilnNo);
    });

    $("#v-pills-reports-tab").click(function () {  //Trends Kiln 3 button
        KilnNo = 5;


        getReportData(KilnNo);
    });
    //=============LOG BOOK TAB click========================
    $("#v-pills-logbook-tab").click(function () {




        tab = "LogBook";
        KilnNo = 5;
        fillddlDateTime(KilnNo);
        getLogTableData(5);
    });
   //--------------------------start--------LOGBOOOK-----------------------//
    $("#pills-LBKiln1-tab").click(function () {  //Trends Kiln 1 button      
        KilnNo = 1;
        fillddlDateTime(KilnNo);
        getLogTableData(1);
    });
    $("#pills-LBKiln2-tab").click(function () {  //Trends Kiln 2 button      
        KilnNo = 2;
        fillddlDateTime(KilnNo);
        getLogTableData(2);
    });
    $("#pills-LBKiln3-tab").click(function () {  //Trends Kiln 3 buttona  
        //alert("hi");
        KilnNo = 3;
        fillddlDateTime(KilnNo);
        getLogTableData(3);
    });
    $("#pills-LBKiln4-tab").click(function () {  //Trends Kiln 3 button      
        KilnNo = 4;
        fillddlDateTime(KilnNo);
        getLogTableData(4);
    });
    $("#pills-LBKiln5-tab").click(function () {  //Trends Kiln 3 button      
        KilnNo = 5;
        fillddlDateTime(KilnNo);
        getLogTableData(5);
    });
    $("#pills-LBKiln6-tab").click(function () {  //Trends Kiln 3 button      
        KilnNo = 6;
        fillddlDateTime(KilnNo);
        getLogTableData(6);
    });
    //--------------------------end--------LOGBOOOK-----------------------//
    $("#pills-AMKiln3-tab").click(function () {
        KilnNo = 5;
        getManualData(KilnNo);
        //get_3D_Data(KilnNo);
    });

  

 //--------------------------start-------DCS-----------------------//


    $("#pills-dcsKiln1-tab").click(function () {
        KilnNo = 1;
        // getManualData(KilnNo);
        //get_3D_Data(KilnNo);
        fillddlShowDataGroup(KilnNo);
        fillddlShowDataSource(KilnNo);
        fillddlShowDataName(KilnNo);
    });
    $("#pills-dcsKiln2-tab").click(function () {
        KilnNo = 2;
        // getManualData(KilnNo);
        //get_3D_Data(KilnNo);
        fillddlShowDataGroup(KilnNo);
        fillddlShowDataSource(KilnNo);
        fillddlShowDataName(KilnNo);
    });




    $("#pills-dcsKiln3-tab").click(function () {
        KilnNo = 3;
       // getManualData(KilnNo);
        //get_3D_Data(KilnNo);
        fillddlShowDataGroup(KilnNo);
        fillddlShowDataSource(KilnNo);
        fillddlShowDataName(KilnNo);
    });
    $("#pills-dcsKiln4-tab").click(function () {
        KilnNo = 4;
        fillddlShowDataGroup(KilnNo);
        fillddlShowDataSource(KilnNo);
        fillddlShowDataName(KilnNo);
    });
    $("#pills-dcsKiln5-tab").click(function () {
        KilnNo = 5;
        fillddlShowDataGroup(KilnNo);
        fillddlShowDataSource(KilnNo);
        fillddlShowDataName(KilnNo);
    });

    $("#pills-dcsKiln6-tab").click(function () {
        KilnNo = 6;
        fillddlShowDataGroup(KilnNo);
        fillddlShowDataSource(KilnNo);
        fillddlShowDataName(KilnNo);
    });
    //--------------------------start-------DCS-----------------------//

     //--------------------------start------TC-----------------------//


    $("#pills-TCKiln1-tab").click(function () {
        KilnNo = 1;
        PlotTcTable(KilnNo)
        //let tab = 'TC';
        //let kiln = KilnNo;
        //let url = `index.html?tab=${tab}&kiln=${kiln}`;
        //// Push the new state onto the browser's history
        //window.history.pushState({ path: url }, '', url);

        // Prevent the default link click behavior
        //e.preventDefault();
    });

    $("#pills-TCKiln2-tab").click(function () {
        KilnNo = 2;
        PlotTcTable(KilnNo)
        //let tab = 'TC';
        //let kiln = KilnNo;
        //let url = `index.html?tab=${tab}&kiln=${kiln}`;
        //// Push the new state onto the browser's history
        //window.history.pushState({ path: url }, '', url);

        // Prevent the default link click behavior
        //e.preventDefault();
    });
    $("#pills-TCKiln3-tab").click(function () {
        KilnNo = 3;
        PlotTcTable(KilnNo)
        //let tab = 'TC';
        //let kiln = KilnNo;
        //let url = `index.html?tab=${tab}&kiln=${kiln}`;
        //// Push the new state onto the browser's history
        //window.history.pushState({ path: url }, '', url);

        // Prevent the default link click behavior
        //e.preventDefault();
    });
    $("#pills-TCKiln4-tab").click(function () {
        KilnNo = 4;
        PlotTcTable(KilnNo)
        //let tab = 'TC';
        //let kiln = KilnNo;
        //let url = `index.html?tab=${tab}&kiln=${kiln}`;
    });
    $("#pills-TCKiln5-tab").click(function () {
        KilnNo = 5;
        PlotTcTable(KilnNo)
        //let tab = 'TC';
        //let kiln = KilnNo;
        //let url = `index.html?tab=${tab}&kiln=${kiln}`;
        //// Push the new state onto the browser's history
        //window.history.pushState({ path: url }, '', url);

        // Prevent the default link click behavior
        //e.preventDefault();
    });

    $("#pills-TCKiln6-tab").click(function () {
        KilnNo = 6;
        PlotTcTable(KilnNo)
        //let tab = 'TC';
        //let kiln = KilnNo;
        //let url = `index.html?tab=${tab}&kiln=${kiln}`;
        //// Push the new state onto the browser's history
        //window.history.pushState({ path: url }, '', url);

        // Prevent the default link click behavior
        //e.preventDefault();
    });


    $("#pills-EBookKiln1-tab").click(function ()
    {
       // alert("hi");
        KilnNo = 1;
        //PlotTcTable(KilnNo)
        PlotEBookTable(KilnNo)
        
    });

    $("#pills-EBookKiln2-tab").click(function () {
       // alert("hi");
        KilnNo = 2;
        PlotEBookTable(KilnNo)
    });
    $("#pills-EBookKiln3-tab").click(function () {
        KilnNo = 3;
        PlotEBookTable(KilnNo)
    });
    $("#pills-EBookKiln4-tab").click(function () {
        KilnNo = 4;
        PlotEBookTable(KilnNo)
    });
    $("#pills-EBookKiln5-tab").click(function () {
        KilnNo = 5;
        PlotEBookTable(KilnNo)
    });

    $("#pills-EBookKiln6-tab").click(function () {
        KilnNo = 6;
        PlotEBookTable(KilnNo)
    });

    $("#pills-QualityEBookKiln1-tab").click(function () {
        // alert("hi");
        KilnNo = 1;
        PlotQualityEBookTable(KilnNo)
    });
    $("#pills-QualityEBookKiln2-tab").click(function () {
        KilnNo = 2;
        PlotQualityEBookTable(KilnNo)
    });
    $("#pills-QualityEBookKiln3-tab").click(function () {
        //alert("hi");
        KilnNo = 3;
        PlotQualityEBookTable(KilnNo)
    });
    $("#pills-QualityEBookKiln4-tab").click(function () {
        KilnNo = 4;
        PlotQualityEBookTable(KilnNo)
    });

    $("#pills-QualityEBookKiln5-tab").click(function () {
        KilnNo = 5;
        PlotQualityEBookTable(KilnNo)
    });

    $("#pills-QualityEBookKiln6-tab").click(function () {
        KilnNo = 6;
       PlotQualityEBookTable(KilnNo)
    });

    $("#pills-MMEBookKiln6-tab").click(function () {
        // alert("hi");
         KilnNo = 6;
        //PlotTcTable(KilnNo)
       // PlotEBookTable(KilnNo)

        PlotMMEBookTable(KilnNo);
    });

    $("#pills-MMEBookKiln2-tab").click(function () {
        // alert("hi");
        KilnNo = 2;
        PlotMMEBookTable(KilnNo);
    });
    $("#pills-MMEBookKiln3-tab").click(function () {
        KilnNo = 3;
        PlotMMEBookTable(KilnNo);
    });
    $("#pills-MMEBookKiln4-tab").click(function () {
        KilnNo = 4;
        PlotMMEBookTable(KilnNo);
    });
    $("#pills-MMEBookKiln5-tab").click(function () {
        KilnNo = 5;
        PlotMMEBookTable(KilnNo);
    });

    $("#pills-MMEBookKiln6-tab").click(function () {
        KilnNo = 6;
        PlotMMEBookTable(KilnNo);
    });

    $("#pills-IEMEBookKiln1-tab").click(function () {
        // alert("hi");
        KilnNo = 1;
        //PlotTcTable(KilnNo)
       // PlotEBookTable(KilnNo)
        PlotIEMEBookTable(KilnNo);
    });

    $("#pills-IEMEBookKiln2-tab").click(function () {
        // alert("hi");
        KilnNo = 2;
        PlotIEMEBookTable(KilnNo);
    });
    $("#pills-IEMEBookKiln3-tab").click(function () {
        KilnNo = 3;
        PlotIEMEBookTable(KilnNo);
    });
    $("#pills-IEMEBookKiln4-tab").click(function () {
        KilnNo = 4;
        PlotIEMEBookTable(KilnNo);
    });
    $("#pills-IEMEBookKiln5-tab").click(function () {
        KilnNo = 5;
        PlotIEMEBookTable(KilnNo);
    });

    $("#pills-IEMEBookKiln6-tab").click(function () {
        KilnNo = 6;
        PlotIEMEBookTable(KilnNo);
    });


    $("#pills-LMonitorKiln1-tab").click(function () {
        // alert("hi");
        KilnNo = 1;
        //PlotTcTable(KilnNo)
        PlotLMonitoringTable(KilnNo)
    });





   




    $("#pills-LMonitorKiln2-tab").click(function () {
        // alert("hi");
        KilnNo = 2;
        PlotLMonitoringTable(KilnNo)
    });
    $("#pills-LMonitorKiln3-tab").click(function () {
        KilnNo = 3;
       PlotLMonitoringTable(KilnNo)
    });
    $("#pills-LMonitorKiln4-tab").click(function () {
        KilnNo = 4;
        PlotLMonitoringTable(KilnNo)
    });
    $("#pills-LMonitorKiln5-tab").click(function () {
        KilnNo = 5;
        PlotLMonitoringTable(KilnNo)
    });

    $("#pills-LMonitorKiln6-tab").click(function () {
        KilnNo = 6;
        PlotLMonitoringTable(KilnNo)
    });

    $("#pills-LConfigurationDataKiln1-tab").click(function () {
        // alert("hi");
        KilnNo = 1;
        //PlotTcTable(KilnNo)
       // PlotLMonitoringTable(KilnNo)

        PlotLConfigurationTable(KilnNo);
    });

    $("#pills-LConfigurationDataKiln2-tab").click(function () {
        // alert("hi");
        KilnNo = 2;
        PlotLConfigurationTable(KilnNo);
    });
    $("#pills-LConfigurationDataKiln3-tab").click(function () {
        KilnNo = 3;
        PlotLConfigurationTable(KilnNo);
    });
    $("#pills-LConfigurationDataKiln4-tab").click(function () {
        KilnNo = 4;
        PlotLConfigurationTable(KilnNo);
    });
    $("#pills-LConfigurationDataKiln5-tab").click(function () {
        KilnNo = 5;
        PlotLConfigurationTable(KilnNo);
    });

    $("#pills-FeedLossBookKiln1-tab").click(function () {
        KilnNo = 1;
        selectiontype = document.getElementById('mySelectlossbooktype');
       // getDuration();
        GetFeedTableData(KilnNo, selectiontype.value);
    });
    $("#pills-FeedLossBookKiln2-tab").click(function () {
        KilnNo = 2;
        selectiontype = document.getElementById('mySelectlossbooktype');
       // getDuration();
        GetFeedTableData(KilnNo, selectiontype.value);
    });
    $("#pills-FeedLossBookKiln3-tab").click(function () {
        KilnNo = 3;
        selectiontype = document.getElementById('mySelectlossbooktype');
       // getDuration();
        GetFeedTableData(KilnNo, selectiontype.value);
    });
    $("#pills-FeedLossBookKiln4-tab").click(function () {
        KilnNo = 4;
        selectiontype = document.getElementById('mySelectlossbooktype');
       // getDuration();
        GetFeedTableData(KilnNo, selectiontype.value);
    });
    $("#pills-FeedLossBookKiln5-tab").click(function () {
        KilnNo = 5;
        selectiontype = document.getElementById('mySelectlossbooktype');
       // getDuration();
        GetFeedTableData(KilnNo, selectiontype.value);
    });
    $("#pills-FeedLossBookKiln6-tab").click(function () {
        KilnNo = 6;
        selectiontype = document.getElementById('mySelectlossbooktype');
       // getDuration();
        GetFeedTableData(KilnNo, selectiontype.value);
    });
  
   

    //--------------------------end------TC-----------------------//

    var Today = new Date();


    $lastDate = new Date();
    $lastDate2 = new Date();
    $lastDate3 = new Date();

    $lastDate.setDate(Today.getDate() - 1);
    $lastDate2.setDate(Today.getDate() - 3);

    $lastDate3.setHours(Today.getHours() - 18); // default date for graph 1,2,3 from date

    document.getElementById('FromDate').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2);//"2023-03-25";
    document.getElementById('ToDate').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2);//"2023-03-25";


    document.getElementById('FromDateFeed').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2) + " " + ('0' + $lastDate.getHours()).slice(-2) + ":" + ('0' + $lastDate.getMinutes()).slice(-2);
    document.getElementById('ToDateFeed').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);
    //document.getElementById('FromDateCoal').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2);//"2023-03-25";
   // document.getElementById('ToDateCoal').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2);//"2023-03-25";


   // document.getElementById('FromDateTc').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2);//"2023-03-25";
    document.getElementById('ToDateTc').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2);//"2023-03-25";
    document.getElementById('ToDateLog').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2);//"2023-03-25";
    document.getElementById('DateLogQuality').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2);//"2023-03-25";
    document.getElementById('ToDateIEMLog').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2);//"2023-03-25";
    document.getElementById('ToDateMMLog').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2);//"2023-03-25";
    document.getElementById('DateManual').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2);//"2023-03-25";
    document.getElementById('FromDateFemK1').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2) + " " + ('0' + $lastDate.getHours()).slice(-2) + ":" + ('0' + $lastDate.getMinutes()).slice(-2);

    

    document.getElementById('ToDateFemK1').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);

    document.getElementById('FromDateFemK2').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2) + " " + ('0' + $lastDate.getHours()).slice(-2) + ":" + ('0' + $lastDate.getMinutes()).slice(-2);
    document.getElementById('ToDateFemK2').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2) + " " + ('0' + $lastDate.getHours()).slice(-2) + ":" + ('0' + $lastDate.getMinutes()).slice(-2);
    document.getElementById('FromDateFemK6').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2) + " " + ('0' + $lastDate.getHours()).slice(-2) + ":" + ('0' + $lastDate.getMinutes()).slice(-2);
    document.getElementById('ToDateFemK6').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2) + " " + ('0' + $lastDate.getHours()).slice(-2) + ":" + ('0' + $lastDate.getMinutes()).slice(-2);


    document.getElementById('FromDateLB').defaultValue = $lastDate2.getFullYear() + "-" + ('0' + ($lastDate2.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate2.getDate()).slice(-2) + " " + ('0' + $lastDate2.getHours()).slice(-2) + ":" + ('0' + $lastDate2.getMinutes()).slice(-2);

   
    document.getElementById('ToDateLB').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);


   


    document.getElementById('FromDateKPI').defaultValue = $lastDate2.getFullYear() + "-" + ('0' + ($lastDate2.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate2.getDate()).slice(-2) + " " + ('0' + $lastDate2.getHours()).slice(-2) + ":" + ('0' + $lastDate2.getMinutes()).slice(-2);

   
    document.getElementById('ToDateKPI').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);


   



    document.getElementById('FromDateFemK3').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2) + " " + ('0' + $lastDate.getHours()).slice(-2) + ":" + ('0' + $lastDate.getMinutes()).slice(-2);

    //document.getElementById('FromDateFemK3').defaultValue = $lastDate3.getFullYear() + "-" + ('0' + ($lastDate3.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate3.getDate()).slice(-2) + " " + ('0' + $lastDate3.getHours()).slice(-2) + ":" + ('0' + $lastDate3.getMinutes()).slice(-2);

    document.getElementById('ToDateFemK3').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);


    document.getElementById('FromDateFemK4').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2) + " " + ('0' + $lastDate.getHours()).slice(-2) + ":" + ('0' + $lastDate.getMinutes()).slice(-2);

    //document.getElementById('FromDateFemK3').defaultValue = $lastDate3.getFullYear() + "-" + ('0' + ($lastDate3.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate3.getDate()).slice(-2) + " " + ('0' + $lastDate3.getHours()).slice(-2) + ":" + ('0' + $lastDate3.getMinutes()).slice(-2);
    document.getElementById('FromDateFemK4').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2) + " " + ('0' + $lastDate.getHours()).slice(-2) + ":" + ('0' + $lastDate.getMinutes()).slice(-2);

    document.getElementById('ToDateFemK4').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2) + " " + ('0' + $lastDate.getHours()).slice(-2) + ":" + ('0' + $lastDate.getMinutes()).slice(-2);

    //document.getElementById('FromDateFemK3').defaultValue = $lastDate3.getFullYear() + "-" + ('0' + ($lastDate3.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate3.getDate()).slice(-2) + " " + ('0' + $lastDate3.getHours()).slice(-2) + ":" + ('0' + $lastDate3.getMinutes()).slice(-2);
    document.getElementById('FromDateFemK33').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2) + " " + ('0' + $lastDate.getHours()).slice(-2) + ":" + ('0' + $lastDate.getMinutes()).slice(-2);
    document.getElementById('ToDateFemK33').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);


    document.getElementById('FromDateSulphurK1').defaultValue = $lastDate2.getFullYear() + "-" + ('0' + ($lastDate2.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate2.getDate()).slice(-2) + " " + ('0' + $lastDate2.getHours()).slice(-2) + ":" + ('0' + $lastDate2.getMinutes()).slice(-2);
    document.getElementById('ToDateSulphurK1').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);

    document.getElementById('FromDateSulphurK2').defaultValue = $lastDate2.getFullYear() + "-" + ('0' + ($lastDate2.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate2.getDate()).slice(-2) + " " + ('0' + $lastDate2.getHours()).slice(-2) + ":" + ('0' + $lastDate2.getMinutes()).slice(-2);
    document.getElementById('ToDateSulphurK2').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);
    document.getElementById('FromDateSulphurK6').defaultValue = $lastDate2.getFullYear() + "-" + ('0' + ($lastDate2.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate2.getDate()).slice(-2) + " " + ('0' + $lastDate2.getHours()).slice(-2) + ":" + ('0' + $lastDate2.getMinutes()).slice(-2);
    document.getElementById('ToDateSulphurK6').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);


    document.getElementById('FromDateSulphurK3').defaultValue = $lastDate2.getFullYear() + "-" + ('0' + ($lastDate2.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate2.getDate()).slice(-2) + " " + ('0' + $lastDate2.getHours()).slice(-2) + ":" + ('0' + $lastDate2.getMinutes()).slice(-2);
    document.getElementById('ToDateSulphurK3').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);

    document.getElementById('FromDateSulphurK33').defaultValue = $lastDate2.getFullYear() + "-" + ('0' + ($lastDate2.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate2.getDate()).slice(-2) + " " + ('0' + $lastDate2.getHours()).slice(-2) + ":" + ('0' + $lastDate2.getMinutes()).slice(-2);
    document.getElementById('ToDateSulphurK33').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);
    document.getElementById('FromDateSulphurK4').defaultValue = $lastDate2.getFullYear() + "-" + ('0' + ($lastDate2.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate2.getDate()).slice(-2) + " " + ('0' + $lastDate2.getHours()).slice(-2) + ":" + ('0' + $lastDate2.getMinutes()).slice(-2);
    document.getElementById('ToDateSulphurK4').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);


    document.getElementById('FromDateCharK1').defaultValue = $lastDate2.getFullYear() + "-" + ('0' + ($lastDate2.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate2.getDate()).slice(-2) + " " + ('0' + $lastDate2.getHours()).slice(-2) + ":" + ('0' + $lastDate2.getMinutes()).slice(-2);
    document.getElementById('ToDateCharK1').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);

    document.getElementById('FromDateCharK2').defaultValue = $lastDate2.getFullYear() + "-" + ('0' + ($lastDate2.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate2.getDate()).slice(-2) + " " + ('0' + $lastDate2.getHours()).slice(-2) + ":" + ('0' + $lastDate2.getMinutes()).slice(-2);
    document.getElementById('ToDateCharK2').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);


    document.getElementById('FromDateCharK3').defaultValue = $lastDate2.getFullYear() + "-" + ('0' + ($lastDate2.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate2.getDate()).slice(-2) + " " + ('0' + $lastDate2.getHours()).slice(-2) + ":" + ('0' + $lastDate2.getMinutes()).slice(-2);
    document.getElementById('ToDateCharK3').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);
    document.getElementById('FromDateCharK6').defaultValue = $lastDate2.getFullYear() + "-" + ('0' + ($lastDate2.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate2.getDate()).slice(-2) + " " + ('0' + $lastDate2.getHours()).slice(-2) + ":" + ('0' + $lastDate2.getMinutes()).slice(-2);
    document.getElementById('ToDateCharK6').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);




    document.getElementById('FromDateCharK33').defaultValue = $lastDate2.getFullYear() + "-" + ('0' + ($lastDate2.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate2.getDate()).slice(-2) + " " + ('0' + $lastDate2.getHours()).slice(-2) + ":" + ('0' + $lastDate2.getMinutes()).slice(-2);
    document.getElementById('ToDateCharK33').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);

    document.getElementById('FromDateCharK4').defaultValue = $lastDate2.getFullYear() + "-" + ('0' + ($lastDate2.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate2.getDate()).slice(-2) + " " + ('0' + $lastDate2.getHours()).slice(-2) + ":" + ('0' + $lastDate2.getMinutes()).slice(-2);
    document.getElementById('ToDateCharK4').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);
    
    document.getElementById('FromDateTrendK1').defaultValue = $lastDate2.getFullYear() + "-" + ('0' + ($lastDate2.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate2.getDate()).slice(-2) + " " + ('0' + $lastDate2.getHours()).slice(-2) + ":" + ('0' + $lastDate2.getMinutes()).slice(-2);
    document.getElementById('ToDateTrendK1').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);


    document.getElementById('FromDateDcs').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2) + " " + ('0' + $lastDate.getHours()).slice(-2) + ":" + ('0' + $lastDate.getMinutes()).slice(-2);

   // document.getElementById('FromDateTc').defaultValue = $lastDate.getFullYear() + "-" + ('0' + ($lastDate.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate.getDate()).slice(-2) + " " + ('0' + $lastDate.getHours()).slice(-2) + ":" + ('0' + $lastDate.getMinutes()).slice(-2);

       // $lastDate2.getFullYear() + "-" + ('0' + ($lastDate2.getMonth() + 1)).slice(-2) + "-" + ('0' + $lastDate2.getDate()).slice(-2) + " " + ('0' + $lastDate2.getHours()).slice(-2) + ":" + ('0' + $lastDate2.getMinutes()).slice(-2);
    document.getElementById('ToDateDcs').defaultValue = Today.getFullYear() + "-" + ('0' + (Today.getMonth() + 1)).slice(-2) + "-" + ('0' + Today.getDate()).slice(-2) + " " + ('0' + Today.getHours()).slice(-2) + ":" + ('0' + Today.getMinutes()).slice(-2);
    GetOnLoadSideBar();

   // alert("hi");
   // CheckLoadOrReload();
    getControlPara(KilnNo);
    $("#rd_Bed5").prop("checked", true);
   updateBedHeightFillingDegreeDivs(KilnNo);
    
});

function GetOnLoadSideBar()
{

        debugger;
        $.ajax
            ({
                type: 'POST',
                url: 'FormModuleService.asmx/GetFORMMODULEData',
                data: '{ }',
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                success: function (data) {
                    GetSidebarData(data.d)
                }
            });

    }
//function CheckLoadOrReload()
//    {
//    const urlParams = new URLSearchParams(window.location.search);
//    const tabParam = urlParams.get("tab");
//    const kilnParam = urlParams.get("kiln");
//    const tabContentid = urlParams.get("tabCid");
//    if (!isNaN(parseFloat(kilnParam)) && isFinite(kilnParam))
//    {

//        KilnNo = parseFloat(kilnParam);
//        getControlPara(KilnNo);
//    }
//    else
//    {
//        console.error(`Invalid KilnNo: ${kilnParam}. Please provide a numeric KilnNo.`);
//    }


//    const navigationType = performance.getEntriesByType('navigation')[0].type;
//    if (navigationType === 'reload')
//    {
//        //$("#pills-QMKiln5-tab").removeClass('active');
//        //$("#pills-QMKiln5").removeClass('active');

//        // $("#pills-QMKiln3-tab").addClass('active');
//        //$("#pills-QMKiln3").addClass('active');
       
//        getControlPara(KilnNo);
//        updateBedHeightFillingDegreeDivs(KilnNo);
//        $("#rd_Bed3").prop("checked", true);
//        console.log('The page was reloaded or refreshed');
        
//    }
//    else
//    {
//        getControlPara(KilnNo);
//        updateBedHeightFillingDegreeDivs(KilnNo);
//        $("#rd_Bed5").prop("checked", true);
//       // GetOnLoadSideBar();
//        console.log('The page was first time');
//    }


//}

//$(window).on('load', function () {
//    alert("reload");
//    //debugger;
//    //let performanceEntry = performance.getEntriesByType("navigation")[0];
//    //let KilnNo = NaN;
//    //let kilnParam = "";
//    //// let tabParam = "";

//    //if (performanceEntry.type === "reload") {
//    //    //kilnParam = prompt("Enter Kiln Number:", "");
//    //    // tabParam = prompt("Enter Tab Parameter:", "");
//    //    alert("hi");
//    //    if (!isNaN(parseFloat(kilnParam)) && isFinite(kilnParam)) {
//    //        KilnNo = parseFloat(kilnParam);

//    //        if (tabParam == "Quality") {
//    //            alert("hi1");
//    //            // Switch to Quality tab for the specified kiln number
//    //            /* $("#myTabs a[href='#pills-QMKiln" + KilnNo + "-tab']").tab("show");*/
//    //            $("#pills-QMKiln3-tab']").tab("show");

//    //            getControlPara(KilnNo);
//    //            updateBedHeightFillingDegreeDivs(KilnNo);
//    //        }
//    //    }
//    //}


//    //else { }
//});




//=================================== TOGGLE FUNCTION ======================================




function toggleMenu(check, elements) {
    if (check.classList.contains("sidebar") == true) {
        localStorage.setItem("colStore", 1);
        $("#sidebar").removeClass("sidebar");
        $("#sidebar").addClass("sidebar-collapsed");
        for (var i = 0; i < elements.length; i++) {
            elements[i].classList.remove("justify-content-start");
            elements[i].classList.add("justify-content-center");
        }
        $("#tog").removeClass("fa-angle-left");
        $("#tog").addClass("fa-angle-right");

        document.getElementById("main-area").style.marginLeft = "60px";
    } else {
        $("#sidebar").removeClass("sidebar-collapsed");
        $("#sidebar").addClass("sidebar");
        localStorage.clear();
        for (var i = 0; i < elements.length; i++) {
            elements[i].classList.remove("justify-content-center");
            elements[i].classList.add("justify-content-start");
        }
        document.getElementById("main-area").style.marginLeft = "120px";
        $("#tog").removeClass("fa-angle-right");
        $("#tog").addClass("fa-angle-left");
    }
}

function togStyle() {
    $("#sidebar").removeClass("sidebar");
    $("#sidebar").addClass("sidebar-collapsed");
    for (var i = 0; i < elements.length; i++) {
        elements[i].classList.remove("justify-content-start");
        elements[i].classList.add("justify-content-center");



    }



    document.getElementById("main-area").style.marginLeft = "60px";
}

       //  Call the function initially
       // PlotLMonitoringTable(KilnNo);

        // Repeat calling the function every 60000ms (1 minute)
    window.setInterval(() =>
    {
            PlotLMonitoringTable(KilnNo);
        }, 60000);
function callMethod() {
    debugger;
    if (tab == "qualityModel") {
       getControlPara(KilnNo);
        //  setInterval(getControlPara(KilnNo), 1* 60 * 1000);       
    }
    //else if(tab=="acerationModel")
    //{
    //    getAccPro2D(KilnNo);                      
    //}
    //else if(tab=="reports")
    //{
    //    getReportData();      
    //}
}
function FunfillddlShowDataSource(kilnNo)
{
    debugger;
   fillddlShowDataSource(kilnNo);
   fillddlShowDataGroup(kilnNo);
   fillddlShowDataName(kilnNo);
}

function FunfillddlShowDataName(kilnNo) {
    debugger;
    //fillddlShowDataSource(kilnNo);
    //fillddlShowDataGroup(kilnNo);
    fillddlShowDataName(kilnNo);
}
document.getElementById('FromDateFeed').addEventListener('change', function (event) {
    //// This code will run when the value of the input changes
    //var selectedDateTime = event.target.value;
    //console.log("Selected date and time:", selectedDateTime);


    getDuration();
});

document.getElementById('ToDateFeed').addEventListener('change', function (event) {
    //// This code will run when the value of the input changes
    //var selectedDateTime = event.target.value;
    //console.log("Selected date and time:", selectedDateTime);
    getDuration();
});
function getDuration()
{
    debugger;
    // Remove any unnecessary debugging statements
    // debugger;

    // Get references to the input elements
    var frmdateInputEl = document.getElementById('FromDateFeed');
    var todateInputEl = document.getElementById('ToDateFeed');

    // Replace 'T' with a space in the input string
    const replaceTChar = str => str.replace(/T/, ' ');

    // Create Date objects from corrected strings
    const frmdateStrCorr = replaceTChar(frmdateInputEl.value);
    const todateStrCorr = replaceTChar(todateInputEl.value);

    const frmdateObj = new Date(frmdateStrCorr);
    const todateObj = new Date(todateStrCorr);


    if (frmdateObj > todateObj)
    {
       return alert("from date should be less than To date!")
    }
    // Check if both conversions were successful
    if (isNaN(frmdateObj.getTime()) || isNaN(todateObj.getTime())) {
        console.error("Invalid date formats!");
        return;
    }

    // Calculate the time difference
    const diffInMilliseconds = todateObj - frmdateObj;

    // Convert milliseconds to minutes
    const diffInMinutes = Math.floor(diffInMilliseconds / (1000 * 60));

    // Display the FromDateFeed value in an alert dialog
    //alert(diffInMinutes);
    var txtduration = document.getElementById('txt_feedduration');

    txtduration.value = diffInMinutes;
    //return diffInMinutes;
}
document.getElementById('myreasonselect').addEventListener('change', function (event)
{
    

    if ($("#myreasonselect").val() === "OTHER")
    {
        $("#other-input").show();
    }
    else
    {
        $("#other-input").hide();
    }
}
);



//-------------------------------------------------

//=======================RADIO BUTTON CLICK EVENT==================================
function updateBedHeightFillingDegreeDivs(kiln) {
    debugger;
    const bedHeightDiv = document.getElementById("chartContainerBedHeight" + kiln);
    const FillingDegreeDiv = document.getElementById("chartContainerFillingDegree" + kiln);
    const rd_Bed = document.getElementById("rd_Bed" + kiln);
    const rd_FD = document.getElementById("rd_FD" + kiln);
    if (rd_Bed.checked) {
        bedHeightDiv.style.opacity = "1";//Show BedHeight Graph
        bedHeightDiv.style.zIndex = "2";
        FillingDegreeDiv.style.opacity = "0";
        FillingDegreeDiv.style.zIndex = "1";
    } else if (rd_FD.checked) {
        bedHeightDiv.style.opacity = "0";
        bedHeightDiv.style.zIndex = "1";
        FillingDegreeDiv.style.opacity = "1"; //Show FillingDegree Graph
        FillingDegreeDiv.style.zIndex = "2";
    }
}
//==================================END RADIO BUTTON===============================
// Control Parameter function
function getFemVsTime(KilnNo) {
    var fromDate = "";
    var toDate = "";
    if (KilnNo == 1)
    {
        fromDate = document.getElementById('FromDateFemK1').value;
        toDate = document.getElementById('ToDateFemK1').value;
    }
     if (KilnNo == 2) {
        fromDate = document.getElementById('FromDateFemK2').value;
        toDate = document.getElementById('ToDateFemK2').value;
    }
    if (KilnNo == 3) {
        fromDate = document.getElementById('FromDateFemK33').value;
        toDate = document.getElementById('ToDateFemK33').value;
    }
    if (KilnNo == 4) {
        fromDate = document.getElementById('FromDateFemK4').value;
        toDate = document.getElementById('ToDateFemK4').value;
    }
    if (KilnNo == 5) {
        fromDate = document.getElementById('FromDateFemK3').value;
        toDate = document.getElementById('ToDateFemK3').value;
    }

    if (KilnNo == 6) {
        fromDate = document.getElementById('FromDateFemK6').value;
        toDate = document.getElementById('ToDateFemK6').value;
    }
    debugger;
    $.ajax({
        type: "POST",
        url: "DRIService.asmx/getFemVsTime",
        data: "{'KILN':'" + KilnNo + "','FromDate':'" + fromDate + "','ToDate':'" + toDate + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            debugger;
            var data = response.d;
            if (data.length != 0) {
                //  FeMvsTimeGraph(data, KilnNo);
                // drawPlotlyFemVsTime(data, KilnNo); //old graph1

                drawGraphFemVsTime(data, KilnNo) //new graph 1
            }


        },
        error: function (jqxhr) {
            alert(jqxhr.responseText);
        },
    });
}

function getSulphurVsTime(kilnNo) {
    var fromDate = "";
    var toDate = "";
    if (KilnNo == 6)
    {
        fromDate = document.getElementById('FromDateSulphurK6').value;
        toDate = document.getElementById('ToDateSulphurK6').value;
    }
    else if (KilnNo == 2) {
        fromDate = document.getElementById('FromDateSulphurK2').value;
        toDate = document.getElementById('ToDateSulphurK2').value;
    }
    else if (KilnNo == 5)
    {
        fromDate = document.getElementById('FromDateSulphurK3').value;
        toDate = document.getElementById('ToDateSulphurK3').value;
    }
    else if (KilnNo == 1) {
        fromDate = document.getElementById('FromDateSulphurK1').value;
        toDate = document.getElementById('ToDateSulphurK1').value;
    }
    else if (KilnNo == 3) {
        fromDate = document.getElementById('FromDateSulphurK33').value;
        toDate = document.getElementById('ToDateSulphurK33').value;
    }
    else if (KilnNo == 4) {
        fromDate = document.getElementById('FromDateSulphurk4').value;
        toDate = document.getElementById('ToDateSulphurK4').value;
    }


    debugger;
    $.ajax({
        type: "POST",
        url: "DRIService.asmx/getSulphurVsTime",
        data: "{'KILN':'" + KilnNo + "','FromDate':'" + fromDate + "','ToDate':'" + toDate + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            debugger;
            var data = response.d;
            //drawGraph(data, kilnNo,"Sulphur(%)") ;
            drawGraphSulpherVsTime(data, kilnNo)
        },
        error: function (jqxhr) {
            alert(jqxhr.responseText);
        },
    });
}

function getCharVsTime(kilnNo) {
    var fromDate = "";
    var toDate = "";
    if (KilnNo == 6) {
        fromDate = document.getElementById('FromDateCharK6').value;
        toDate = document.getElementById('ToDateCharK6').value;
    }
    else if (KilnNo == 2) {
        fromDate = document.getElementById('FromDateCharK2').value;
        toDate = document.getElementById('ToDateCharK2').value;
    }
    else if (KilnNo == 5) {
        fromDate = document.getElementById('FromDateCharK3').value;
        toDate = document.getElementById('ToDateCharK3').value;
    }

    else if (KilnNo == 3) {
        fromDate = document.getElementById('FromDateCharK33').value;
        toDate = document.getElementById('ToDateCharK33').value;
    }
    else if (KilnNo == 4) {
        fromDate = document.getElementById('FromDateCharK4').value;
        toDate = document.getElementById('ToDateCharK4').value;
    }

    else if (KilnNo == 1) {
        fromDate = document.getElementById('FromDateCharK1').value;
        toDate = document.getElementById('ToDateCharK1').value;
    }
    debugger;
    $.ajax({
        type: "POST",
        url: "DRIService.asmx/getCharVsTime",
        data: "{'KILN':'" + KilnNo + "','FromDate':'" + fromDate + "','ToDate':'" + toDate + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            debugger;
            var data = response.d;
            //drawGraph(data, kilnNo,"Carbon in Char(%)") ; old graph 3
            drawGraphCarbonChar(data, kilnNo); // new graph 3
        },
        error: function (jqxhr) {
            alert(jqxhr.responseText);
        },
    });
}

//function getBedHeightVsTime(kilnNo){
//    var fromDate="";
//    var toDate ="";
//    if(KilnNo==1)
//    {
//        //fromDate = document.getElementById('FromDateBedHeightK1').value;
//       //Date = document.getElementById('ToDateBedHeightK1').value;
//    }
//    else if(KilnNo==2)
//    {
//        //fromDate = document.getElementById('FromDateBedHeightK2').value;
//        //toDate = document.getElementById('ToDateBedHeightK2').value;
//    }
//    else if(KilnNo==3)
//    {
//        //fromDate = document.getElementById('FromDateBedHeightK3').value;
//        //toDate = document.getElementById('ToDateBedHeightK3').value;
//    }
//    debugger;
//    $.ajax({
//        type: "POST",
//        url: "DRIService.asmx/getBedHeightVsTime",
//        data:"{'KILN':'" +KilnNo +"','FromDate':'" +fromDate +"','ToDate':'" +toDate +"'}",
//        contentType: "application/json; charset=utf-8",
//        dataType: "json",
//        success: function (response) {
//            debugger;
//            var data=response.d;
//            drawGraph(data, kilnNo,"chartContainerBedHeight1","Bed Height") ;

//        },
//        error: function (jqxhr) {
//            alert(jqxhr.responseText);
//        },
//    });
//}

//function getCoCo2VsTime(kilnNo){
//    var fromDate="";
//    var toDate ="";
//    if(KilnNo==1)
//    {
//        fromDate = document.getElementById('FromDateCoCo2K1').value;
//        toDate = document.getElementById('ToDateCoCo2K1').value;
//    }
//    else if(KilnNo==2)
//    {
//        fromDate = document.getElementById('FromDateCoCo2K2').value;
//        toDate = document.getElementById('ToDateCoCo2K2').value;
//    }
//    else if(KilnNo==3)
//    {
//        fromDate = document.getElementById('FromDateCoCo2K3').value;
//        toDate = document.getElementById('ToDateCoCo2K3').value;
//    }
//    debugger;
//    $.ajax({
//        type: "POST",
//        url: "DRIService.asmx/getCOCO2VsTime",
//        data:"{'KILN':'" +KilnNo +"','FromDate':'" +fromDate +"','ToDate':'" +toDate +"'}",
//        contentType: "application/json; charset=utf-8",
//        dataType: "json",
//        success: function (response) {
//            debugger;
//            var data=response.d;
//            drawGraph(data, kilnNo,"chartContainerCoCo2_1","CO/CO2") ;

//        },
//        error: function (jqxhr) {
//            alert(jqxhr.responseText);
//        },
//    });
//}
function btnClick() {
   // document.getElementById("field2").value = document.getElementById("field1").value;
    //alert('hi');
    var y = document.getElementById("divlogin");
    var x = document.getElementById("dataconfig");
    //y.style.display = "none";
    //if (x.style.display === "none")
    //{
    //    x.style.display = "block";
    //}
    ////} else {
    ////    x.style.display = "none";
    ////}
    //PlotLConfigurationTable(5);


    USERID = document.getElementById('txtusernameconfig').value;

    PASSWORD = document.getElementById('txtpasswordconfig').value;


    if (USERID == "" || PASSWORD == "") {

        alert("UserID/Password can't be Empty")
    }

    else {



        $.ajax({
            type: "POST",
            url: "LoginService.asmx/LoginValidation",
            data: "{'USERID':'" + USERID + "','PASSWORD':'" + PASSWORD + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                debugger;
                var data = response.d;
                if (data == "True")
                {
                    // window.location.href = "index.html";
                    y.style.display = "none";

                    x.style.display = "block";
                    PlotLConfigurationTable(5);
                }

                else if (data == "False")
                {

                    alert("UserID/Password Incorrect!")
                }


                // alert(response.d);

            },
            error: function (jqxhr) {
                alert(jqxhr.responseText);
            },
        });
    }








}

function getControlPara(kilnNo) {

   // e.preventDefault();
    debugger;
    var fromDate = "";
    var toDate = "";
    var fromDateSul = "";
    var toDateSul = "";

    if (kilnNo == 6) {
        fromDate = document.getElementById('FromDateFemK6').value; // kiln 1 changed to 6
        toDate = document.getElementById('ToDateFemK6').value;

        fromDateSul = document.getElementById('FromDateSulphurK6').value;
        toDateSul = document.getElementById('ToDateSulphurK6').value;


    }
    else if (kilnNo == 3) {
        fromDate = document.getElementById('FromDateFemK33').value;
        toDate = document.getElementById('ToDateFemK33').value;
        fromDateSul = document.getElementById('FromDateSulphurK33').value;
        toDateSul = document.getElementById('ToDateSulphurK33').value;
    }

    else if (kilnNo == 4) {
        fromDate = document.getElementById('FromDateFemK4').value;
        toDate = document.getElementById('ToDateFemK4').value;
        fromDateSul = document.getElementById('FromDateSulphurK4').value;
        toDateSul = document.getElementById('ToDateSulphurK4').value;
    }

    else if (kilnNo == 5) {
        fromDate = document.getElementById('FromDateFemK3').value;
        toDate = document.getElementById('ToDateFemK3').value;
        fromDateSul = document.getElementById('FromDateSulphurK3').value; //kiln 3 changed to 5
        toDateSul = document.getElementById('ToDateSulphurK3').value;
    }

    else if (kilnNo == 1)
    {
        fromDate = document.getElementById('FromDateFemK1').value;
        toDate = document.getElementById('ToDateFemK1').value;
        fromDateSul = document.getElementById('FromDateSulphurK1').value; //kiln 3 changed to 5
        toDateSul = document.getElementById('ToDateSulphurK1').value;

    }
    else if (kilnNo == 2)
    {

        fromDate = document.getElementById('FromDateFemK2').value;
        toDate = document.getElementById('ToDateFemK2').value;
        fromDateSul = document.getElementById('FromDateSulphurK2').value; //kiln 3 changed to 5
        toDateSul = document.getElementById('ToDateSulphurK2').value;
    }



    if (kilnNo != "" || kilnNo != null) {
        $.ajax({
            type: "POST",
            url: "DRIService.asmx/QMcontrollablePara",
            data: "{'KILN':'" + kilnNo + "','FromDate':'" + fromDate + "','ToDate':'" + toDate + "','FromDateSul':'" + fromDateSul + "','ToDateSul':'" + toDateSul + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            beforeSend: function () {
                x = document.getElementById("loading-image");
                x.style.display = "block";
            },
            complete: function () {
                // Hide image container
                x = document.getElementById("loading-image");
                x.style.display = "none";
            },
            success: function (response) {
                debugger;
                if (response.d == null) {
                    window.location.href = "login.html";
                    //alert("No Data Found.")
                    return;
                }
                var cpData = response.d[0];
                FemData_1 = response.d[1];
                graphdata_Pressure_1 = response.d[2];
                FemTimeData = response.d[3];    // FeM Vs Time Data           
                dataSulphur1 = response.d[4];
                dataChar1 = response.d[5];

                BHData = response.d[6];  //ArrayList Containing current and Avg Values(Bed Height vs Kiln Length)
                FillingData = response.d[7]; //ArrayList Containing current and Avg Values(Filling Degree vs Kiln Length)
                dataCoCo21 = response.d[8]; //ArrayList Containing current and Avg Values(COCO2 vs Kiln Length)
                carbonAvailData = response.d[9];


                fillControllableParamTable(cpData, kilnNo) // ist table

                drawGraphFemVsLength(FemData_1, kilnNo);
                console.log(FemData_1);
                drawGraphPressure(graphdata_Pressure_1, kilnNo);

                // drawPlotlyFemVsTime(FemTimeData, kilnNo); //graph1 old 



                drawGraph(dataSulphur1, kilnNo, "Sulphur(%)"); // 2nd  graph old




                drawGraph(dataChar1, kilnNo, "Carbon in Char(%)"); //3 rd graph  

                drawGraphFemVsTime(FemTimeData, kilnNo)//graph1 new
                drawGraphSulpherVsTime(dataSulphur1, kilnNo)//graph2 new
                drawGraphCarbonChar(dataChar1, kilnNo)//graph3 new




                drawCOCO2Graph(dataCoCo21, kilnNo, "chartContainerCoCo2_1", "CO/CO2");

                drawBedHeight_FillingDegreeGraph(BHData, kilnNo, 'Bed Height')

                drawBedHeight_FillingDegreeGraph(FillingData, kilnNo, 'Filling Degree')

                drawCarbonAvailabilityGraph(carbonAvailData, kilnNo)


                //if (SAB1_AirFlow =="" || SAB1_AirFlow ==null) {
                //    SAB1_AirFlow=0;
                //}
                //if (SAB2_AirFlow =="" || SAB2_AirFlow ==null) {
                //    SAB2_AirFlow=0;
                //}
                //if (SAB3_AirFlow =="" || SAB3_AirFlow ==null) {
                //    SAB3_AirFlow=0;
                //}
                //if (SAB4_AirFlow =="" || SAB4_AirFlow ==null) {
                //    SAB4_AirFlow=0;
                //}
                //if (SAB5_AirFlow =="" || SAB5_AirFlow ==null) {
                //    SAB5_AirFlow=0;
                //}
                //if (SAB6_AirFlow =="" || SAB6_AirFlow ==null) {
                //    SAB6_AirFlow=0;
                //}
                //if (SAB7_AirFlow =="" || SAB7_AirFlow ==null) {
                //    SAB7_AirFlow=0;
                //}
                //if (SAB8_AirFlow =="" || SAB8_AirFlow ==null) {
                //    SAB8_AirFlow=0;
                //}
                //if (SAB9_AirFlow =="" || SAB9_AirFlow ==null) {
                //    SAB9_AirFlow=0;
                //}
                //if (SAB10_AirFlow =="" || SAB10_AirFlow ==null) {
                //    SAB10_AirFlow=0;
                //}
                //if (KILN_RPM == "" || KILN_RPM == null) {
                //    KILN_RPM = 0;
                //}
                //if (FeedCoalRate == "" || FeedCoalRate == null) {
                //    FeedCoalRate = 0;
                //}

                //if (InjectionCoalRate == "" || InjectionCoalRate == null) {
                //    InjectionCoalRate = 0;
                //}

                //if (IronOreFeedRate == "" || IronOreFeedRate == null) {
                //    IronOreFeedRate = 0;
                //}

                //if (DolomiteFeedRate == "" || DolomiteFeedRate == null) {
                //    DolomiteFeedRate = 0;
                //}


                //if (PRIM_AIR_SET == "" || PRIM_AIR_SET == null) {
                //    PRIM_AIR_SET = 0;
                //}
                //if (RPM_SET == "" || RPM_SET == null) {
                //    RPM_SET = 0;
                //}
                //if (FE_FEED_SET == "" || FE_FEED_SET == null) {
                //    FE_FEED_SET = 0;
                //}
                //if (FEEDCOAL_SET == "" || FEEDCOAL_SET == null) {
                //    FEEDCOAL_SET = 0;
                //}
                //if (FINECOAL_SET == "" || FINECOAL_SET == null) {
                //    FINECOAL_SET = 0;
                //}




            },
            error: function (jqxhr) {
                alert(jqxhr.responseText);
            },
        });
    }
    else {

        return "";
    }

}



function fillControllableParamTable(finalData, kiln)
{


    debugger;
    if (finalData == null)
        return "";
    var recommData = null; var cpData = null;
    if (finalData[0] != "" && finalData[1] != "") {
        cpData = finalData[0]; recommData = finalData[1];
    }
    console.log(cpData);
    // cpData = finalData[0]; recommData = finalData[1];
    // cpData = finalData[0]; recommData = finalData[0]; // changed by neeraj for testing 

    var controllableParamNames = [];
    //if (kiln == 1 || kiln == 2) {
    //    controllableParamNames = {
    //         "KILN RPM": [recommData[0].KILN_RPM, cpData[0].RPM_SET, cpData[0].RPM_SET],     // Set Recommendation, setpoint,Actual Values
    //        "FEED COAL RATE": [recommData[0].FeedCoalRate, cpData[0].FEEDCOAL_SET, cpData[0].FeedCoalRate],
    //        "INJECTION COAL RATE": [recommData[0].InjectionCoalRate, cpData[0].FINECOAL_SET, cpData[0].InjectionCoalRate],
    //        "IRON ORE RATE": [recommData[0].IronOreFeedRate, cpData[0].FE_FEED_SET, cpData[0].IronOreFeedRate],
    //        "DOLOMITE RATE": [recommData[0].DolomiteFeedRate, "-", cpData[0].DolomiteFeedRate],
    //        "PAB": [recommData[0].PAB_AirFlow, cpData[0].PRIM_AIR_SET, cpData[0].PAB_AirFlow],
    //        "INJ COAL AIR FLOW 1": [cpData[0].INJ_AIR_FLOW1, cpData[0].INJ_AIR_FLOW1, cpData[0].INJ_AIR_FLOW1],
    //        "INJ COAL AIR FLOW 2": [cpData[0].INJ_AIR_FLOW2, cpData[0].INJ_AIR_FLOW2, cpData[0].INJ_AIR_FLOW2],
    //        "SAB 02": [recommData[0].SAB1_AirFlow, cpData[0].SAB2_AirFlow, cpData[0].SAB2_AirFlow],
    //        "SAB 03": [recommData[0].SAB2_AirFlow, cpData[0].SAB3_AirFlow, cpData[0].SAB3_AirFlow],
    //        "SAB 04": [recommData[0].SAB3_AirFlow, cpData[0].SAB4_AirFlow, cpData[0].SAB4_AirFlow],
    //        "SAB 05": [recommData[0].SAB4_AirFlow, cpData[0].SAB5_AirFlow, cpData[0].SAB5_AirFlow],
    //        "SAB 06": [recommData[0].SAB5_AirFlow, cpData[0].SAB6_AirFlow, cpData[0].SAB6_AirFlow],
    //        "SAB 07": [recommData[0].SAB6_AirFlow, cpData[0].SAB7_AirFlow, cpData[0].SAB7_AirFlow],
    //        "SAB 08": [recommData[0].SAB7_AirFlow, cpData[0].SAB8_AirFlow, cpData[0].SAB8_AirFlow],
    //        "SAB 09": [recommData[0].SAB8_AirFlow, cpData[0].SAB9_AirFlow, cpData[0].SAB9_AirFlow],
    //        "SAB 10": [recommData[0].SAB9_AirFlow, cpData[0].SAB10_AirFlow, cpData[0].SAB10_AirFlow]
    //    }
    //}
   /* else {*/

        if (recommData != null && recommData.length>0 )
            controllableParamNames =
            {
               //alert()
                

            //"KILN RPM": [recommData[0].KILN_RPM, cpData[0].RPM_SET, cpData[0].RPM_SET],     // Set Recommendation, setpoint,Actual Values
             "KILN RPM": [recommData[0].KILN_RPM, cpData[0].KILN_RPM, cpData[0].KILN_RPM],
            "FEED COAL RATE": [recommData[0].FeedCoalRate, cpData[0].FEEDCOAL_SET, cpData[0].FeedCoalRate],
            "INJECTION COAL RATE": [recommData[0].InjectionCoalRate, cpData[0].FINECOAL_SET, cpData[0].InjectionCoalRate],
            "IRON ORE RATE": [recommData[0].IronOreFeedRate, cpData[0].FE_FEED_SET, cpData[0].IronOreFeedRate],
            "DOLOMITE RATE": [recommData[0].DolomiteFeedRate, "-", cpData[0].DolomiteFeedRate],
            "PAB": [recommData[0].PAB_AirFlow, cpData[0].PRIM_AIR_SET, cpData[0].PAB_AirFlow],
            //"INJ COAL AIR FLOW 1":[cpData[0].INJ_AIR_FLOW1,cpData[0].INJ_AIR_FLOW1,cpData[0].INJ_AIR_FLOW1],
            //"INJ COAL AIR FLOW 2":[cpData[0].INJ_AIR_FLOW2,cpData[0].INJ_AIR_FLOW2,cpData[0].INJ_AIR_FLOW2],
            "SAB 01": [recommData[0].SAB1_AirFlow, cpData[0].SAB1_AirFlow, cpData[0].SAB1_AirFlow],
            "SAB 02": [recommData[0].SAB2_AirFlow, cpData[0].SAB2_AirFlow, cpData[0].SAB2_AirFlow],
            "SAB 03": [recommData[0].SAB3_AirFlow, cpData[0].SAB3_AirFlow, cpData[0].SAB3_AirFlow],
            "SAB 04": [recommData[0].SAB4_AirFlow, cpData[0].SAB4_AirFlow, cpData[0].SAB4_AirFlow],
            "SAB 05": [recommData[0].SAB5_AirFlow, cpData[0].SAB5_AirFlow, cpData[0].SAB5_AirFlow],
            "SAB 06": [recommData[0].SAB6_AirFlow, cpData[0].SAB6_AirFlow, cpData[0].SAB6_AirFlow],
            "SAB 07": [recommData[0].SAB7_AirFlow, cpData[0].SAB7_AirFlow, cpData[0].SAB7_AirFlow],
            "SAB 08": [recommData[0].SAB8_AirFlow, cpData[0].SAB8_AirFlow, cpData[0].SAB8_AirFlow],
        }
    
    if (recommData != null && recommData.length > 0) {

        document.getElementById("txt_CFE" + kiln).value = recommData[0].C_FE;
        document.getElementById("txt_CFERef" + kiln).value = recommData[0].C_FE_REF;
        document.getElementById("txt_backFlow" + kiln).value = recommData[0].BackFlow;
        document.getElementById("txt_backFlow_Ref" + kiln).value = recommData[0].BackFlow_Ref;
    }
    //debugger;
    var table = document.getElementById("tbl_ControlParam" + kiln)
    const tableBody = table.querySelector("tbody");
    tableBody.innerHTML = ""

   // data = cpData[0]; 8/3/2024

    for (const key in controllableParamNames) {
        if (controllableParamNames.hasOwnProperty(key)) {
            const row = document.createElement("tr");
            row.classList.add("text")
            // Create and append table cell for the key
            const keyCell = document.createElement("td");
            keyCell.textContent = key;
            row.appendChild(keyCell);

            // RECOMMENDATION
            const RecvalueCell = document.createElement("td");
            RecvalueCell.textContent = controllableParamNames[key][0];
            row.appendChild(RecvalueCell);

            //// SETPOINT VALUES
            //const SPvalueCell = document.createElement("td");
            //SPvalueCell.textContent = controllableParamNames[key][1];
            //row.appendChild(SPvalueCell);

            // ACTUAL VALUES
            const ActvalueCell = document.createElement("td");

            var actvalue = controllableParamNames[key][2];

            ActvalueCell.textContent = actvalue;
            row.appendChild(ActvalueCell);

            // Append the row to the table body
            tableBody.appendChild(row);
        }
    }

    //var PAB_AirFlow = cpData[0].PAB_AirFlow;
    //var SAB1_AirFlow = cpData[0].SAB1_AirFlow;
    //var SAB2_AirFlow = cpData[0].SAB2_AirFlow;
    //var SAB3_AirFlow = cpData[0].SAB3_AirFlow;
    //var SAB4_AirFlow = cpData[0].SAB4_AirFlow;
    //var SAB5_AirFlow = cpData[0].SAB5_AirFlow;
    //var SAB6_AirFlow = cpData[0].SAB6_AirFlow;
    //var SAB7_AirFlow = cpData[0].SAB7_AirFlow;
    //var SAB8_AirFlow = cpData[0].SAB8_AirFlow;
    //var SAB9_AirFlow = cpData[0].SAB9_AirFlow;
    //var SAB10_AirFlow = cpData[0].SAB10_AirFlow;
    //var KILN_RPM = cpData[0].KILN_RPM;
    //var FeedCoalRate = cpData[0].FeedCoalRate;
    //var InjectionCoalRate = cpData[0].InjectionCoalRate;
    //var IronOreFeedRate = cpData[0].IronOreFeedRate;
    //var DolomiteFeedRate = cpData[0].DolomiteFeedRate;
    //var INJCOAL_AIRFLOW1 = cpData[0].INJ_AIR_FLOW1
    //var INJCOAL_AIRFLOW2 = cpData[0].INJ_AIR_FLOW2

    //var PRIM_AIR_SET = cpData[0].PRIM_AIR_SET;
    //var RPM_SET = cpData[0].RPM_SET;
    //var FE_FEED_SET = cpData[0].FE_FEED_SET;
    //var FEEDCOAL_SET = cpData[0].FEEDCOAL_SET;
    //var FINECOAL_SET = cpData[0].FINECOAL_SET;

    // Binding the Controll Parameter Data in Tables
    //document.getElementById('kilnRpmAct').innerHTML = KILN_RPM;
    //document.getElementById('feedCoalRateAct').innerHTML = FeedCoalRate + " T/Hr";
    //document.getElementById('ironOreRateAct').innerHTML = IronOreFeedRate + " T/Hr";
    //document.getElementById('injectionCoalRateAct').innerHTML = InjectionCoalRate + " T/Hr";
    //document.getElementById('dolamiteRateAct').innerHTML = DolomiteFeedRate + " T/Hr";


    //document.getElementById('kilnRpmSp').innerHTML = RPM_SET;
    //document.getElementById('feedCoalRateSp').innerHTML = FEEDCOAL_SET;
    //document.getElementById('PABSp').innerHTML = PRIM_AIR_SET;
    //document.getElementById('injectionCoalRateSp').innerHTML = FINECOAL_SET;
    //document.getElementById('ironOreRateSp').innerHTML = FE_FEED_SET;


    //document.getElementById('PABAct').innerHTML = PAB_AirFlow + " N/m<sup>3</sup>";
    ////document.getElementById('sab01Act').innerHTML = SAB1_AirFlow+ " N/m<sup>3</sup>";
    //document.getElementById('sab02Act').innerHTML = SAB2_AirFlow + " N/m<sup>3</sup>";
    //document.getElementById('sab03Act').innerHTML = SAB3_AirFlow + " N/m<sup>3</sup>";
    //document.getElementById('sab04Act').innerHTML = SAB4_AirFlow + " N/m<sup>3</sup>";
    //document.getElementById('sab05Act').innerHTML = SAB5_AirFlow + " N/m<sup>3</sup>";
    //document.getElementById('sab06Act').innerHTML = SAB6_AirFlow + " N/m<sup>3</sup>";
    //document.getElementById('sab07Act').innerHTML = SAB7_AirFlow + " N/m<sup>3</sup>";
    //document.getElementById('sab08Act').innerHTML = SAB8_AirFlow + " N/m<sup>3</sup>";
    //document.getElementById('sab09Act').innerHTML = SAB9_AirFlow + " N/m<sup>3</sup>";
    //document.getElementById('sab10Act').innerHTML = SAB10_AirFlow + " N/m<sup>3</sup>";
}

function drawGraph(graphdata, kilnNo, series) {
    if (graphdata == null)
        return "";
    // debugger;
    var lstDataActual = [];
    var lstDataActual2 = [];
    var lstdataPred = [];
    var lcl = []; var ucl = [];
    var seriesVal; var minVal; var maxVal;
    var Datalist = graphdata[i];

    if (series == "Sulphur(%)") {
        seriesVal = "Sulphur Lumps"
        minVal = 0; maxVal = 0.030;
    }
    else {
        seriesVal = "Actual";
        minVal = 30; maxVal = 35;
    }
    for (var i = 0; i < graphdata.length - 1; i++) {
        var Datalist = graphdata[i];
        lstDataActual.push({
            label: Datalist.TIME_STAMP,
            y: Datalist.ActualValue,

        });
    }
    for (var i = 0; i < graphdata.length; i++) {
        var Datalist = graphdata[i];
        lstdataPred.push({
            label: Datalist.TIME_STAMP,
            y: Datalist.PredictedValue,

        });
        ucl.push({
            label: Datalist.TIME_STAMP,
            y: maxVal
        });
        lcl.push({
            label: Datalist.TIME_STAMP,
            y: minVal
        });
        //if (series == "Sulphur(%)") {
        //    lstDataActual2.push({
        //        label: Datalist.TIME_STAMP,
        //        y: Datalist.ActualValue2,

        //    });
        //}
        // }
    }

    var chartarea;
    if (graphModal == 1)
        chartarea = "chartContainer";
    else {
        if (series == "Sulphur(%)")
            chartarea = "chartContainerSulpher" + kilnNo;
        else
            chartarea = "chartContainerChar" + kilnNo;

    }


    chart1 = new CanvasJS.Chart(chartarea,
        {
            zoomEnabled: true,
            animationEnabled: true,
            backgroundColor: "white",
            theme: "theme3",
            exportEnabled: false,
            zoomType: "x",
            interactivityEnabled: true,
            toolTip:
            {
                shared: true,


            },

            axisX:
            {
                gridThickness: 1,
                tickColor: "white",
                lineColor: "black",
                titleFontColor: "black",
                labelFontColor: "black",
                labelFontSize: "12",
                titleFontSize: "12",
                titleFontWeight: "normal",
                labelFontWeight: "normal",
                tickColor: "#ffffff",
                title: "Date Time",
                // interval: 50,
                labelAngle: 180


            },

            axisY:
                [
                    {
                        gridThickness: 1,
                        tickColor: "white",
                        title: series,
                        lineColor: "black",
                        titleFontColor: "black",
                        labelFontColor: "black",
                        labelFontSize: "12",
                        titleFontSize: "12",
                        titleFontWeight: "normal",
                        labelFontWeight: "normal",
                        tickColor: "black"
                    }],

            // dataPointMaxWidth: 20,

            legend: {
                cursor: "pointer",
                verticalAlign: "top",
                horizontalAlign: "center",
                fontColor: "black",
                FontWeight: "bold",
                fontSize: 14,
                //itemMaxWidth: 1000
            },

            data: [

                {
                    type: "line",
                    name: "Actual",
                    showInLegend: true,
                    axisYIndex: 0,
                    //color: "red",
                    dataPoints: lstDataActual

                },

                {
                    type: "line",
                    name: "Predicted",
                    showInLegend: true,
                    axisYIndex: 0,
                    //color: "blue",
                    dataPoints: lstdataPred

                },
                {
                    markerType: "none",
                    type: "line",
                    // toolTipContent: null,  
                    lineDashType: "dash",
                    name: "UCL",
                    showInLegend: true,
                    color: "green",
                    dataPoints: ucl

                },
                {
                    markerType: "none",
                    toolTipContent: null,
                    type: "line",
                    lineDashType: "dash",
                    name: "LCL",
                    showInLegend: true,
                    color: "red",
                    dataPoints: lcl

                }
            ]
        });

    chart1.render();
    if (series == "Sulphur(%)") {
        chart1.data[3].remove();
    }
    chart1.render();
    //else if (series == "Carbon in Char(%)") {
    //    chart1.axisY[0].set("minimum", 30);
    //    chart1.axisY[0].set("maximum", 35);
    //}
}

function drawBedHeight_FillingDegreeGraph(DataList, kilnNo, param) {
    if (DataList == null) {
        return;
    }
    var lstBedHeight = []; var lstBedHeight_avg = [];
    BHData = DataList[0]; BHData_avg = DataList[1]; var chartarea; var yTitle;
    if (BHData == null && BHData_avg == null) {
        return;
    }

    if (param == 'Bed Height') {
        yTitle = "Bed Height (%)"
        if (kilnNo == 6)
            chartarea = "chartContainerBedHeight6";
        if (kilnNo == 2)
            chartarea = "chartContainerBedHeight2";
        if (kilnNo == 1)
            chartarea = "chartContainerBedHeight1";
        if (kilnNo == 5)
            chartarea = "chartContainerBedHeight5";

        if (kilnNo == 3)
            chartarea = "chartContainerBedHeight3";
        if (kilnNo == 4)
            chartarea = "chartContainerBedHeight4";

        for (var i = 0; i < BHData.length; i++) {
            var Datalist = BHData[i];
            lstBedHeight.push({
                label: Datalist.Kiln_Length,
                y: Datalist.BH_Value
            });
        }
        for (var i = 0; i < BHData_avg.length; i++) {
            var Datalist = BHData_avg[i];
            lstBedHeight_avg.push({
                label: Datalist.Kiln_Length,
                y: Datalist.BH_Value

            });
        }
    }
    else {
        yTitle = "Filling Degree (%)"
        if (kilnNo == 6)
            chartarea = "chartContainerFillingDegree6";
        if (kilnNo == 2)
            chartarea = "chartContainerFillingDegree2";
        if (kilnNo == 1)
            chartarea = "chartContainerFillingDegree1";
        if (kilnNo == 5)
            chartarea = "chartContainerFillingDegree5";
        if (kilnNo == 3)
            chartarea = "chartContainerFillingDegree3";
        if (kilnNo == 4)
            chartarea = "chartContainerFillingDegree4";

        for (var i = 0; i < BHData.length; i++) {
            var Datalist = BHData[i];
            lstBedHeight.push({
                label: Datalist.Kiln_Length,
                y: Datalist.FDegree_Value
            });
        }
        for (var i = 0; i < BHData_avg.length; i++) {
            var Datalist = BHData_avg[i];
            lstBedHeight_avg.push({
                label: Datalist.Kiln_Length,
                y: Datalist.FDegree_Value

            });
        }
    }

    chart1 = new CanvasJS.Chart(chartarea,
        {
            zoomEnabled: true,
            animationEnabled: true,
            backgroundColor: "white",
            theme: "theme3",
            exportEnabled: false,
            zoomType: "x",
            interactivityEnabled: true,
            toolTip:
            {
                enabled: true,
                shared: true,
                hidden: function (e) {
                    console.log("ToolTip has hidden");
                }

            },

            //legend: {
            //    cursor: "pointer",
            //    verticalAlign: "top",
            //    horizontalAlign: "center",
            //    fontColor: "#ffffff",
            //    FontWeight: "bolder",
            //    FontSize: 15,
            //    itemMaxWidth: 1000,

            //},
            axisX:
            {
                gridThickness: 1,
                //gridColor:"white",
                lineColor: "black",
                titleFontColor: "black",
                labelFontColor: "black",
                labelFontSize: "12",
                titleFontSize: "12",
                titleFontWeight: "normal",
                labelFontWeight: "normal",
                tickColor: "#ffffff",
                title: "KILN LENGTH (m)",
                interval: 1

            },

            axisY: [

                {
                    gridThickness: 1,
                    tickColor: "white",
                    title: yTitle,
                    lineColor: "black",
                    titleFontColor: "black",
                    labelFontColor: "black",
                    labelFontSize: "12",
                    titleFontSize: "12",
                    titleFontWeight: "normal",
                    labelFontWeight: "normal",
                    tickColor: "black",

                }],

            //  dataPointMaxWidth: 20,

            data: [{

                lineThickness: 2,
                markerType: "circle",
                // markerColor: "#FFFFFF",
                type: "line",
                name: param,
                showInLegend: true,
                axisYIndex: 0,
                axisYType: "primary",
                color: "red",
                dataPoints: lstBedHeight
            },
            {

                lineThickness: 2,
                markerType: "circle",
                // markerColor: "#FFFFFF",
                type: "line",
                name: param + " AVG",
                showInLegend: true,
                axisYIndex: 0,
                axisYType: "primary",
                color: "blue",
                dataPoints: lstBedHeight_avg
            }

            ]
        });

    chart1.render();
}

function drawCOCO2Graph(DataList, kilnNo) {
    //  debugger;
    if (DataList == null) {
        return;
    }
    var lstCOCO2 = []; var lstCOCO2_avg = [];
    COCO2Data = DataList[0]; COCO2Data_avg = DataList[1]; var chartarea;

    if (COCO2Data == null || COCO2Data_avg == null) {
        return;
    }

    if (kilnNo == 6)
        chartarea = "chartContainerCoCo2_6";
    if (kilnNo == 2)
        chartarea = "chartContainerCoCo2_2";
    if (kilnNo == 1)
        chartarea = "chartContainerCoCo2_1";
    if (kilnNo == 5)
        chartarea = "chartContainerCoCo2_5";
    if (kilnNo == 3)
        chartarea = "chartContainerCoCo2_3";
    if (kilnNo == 4)
        chartarea = "chartContainerCoCo2_4";

    for (var i = 0; i < COCO2Data.length; i++) {
        var Datalist = COCO2Data[i];
        lstCOCO2.push({
            label: Datalist.Kiln_Length,
            y: Datalist.COCO2_Value
        });
    }
    for (var i = 0; i < COCO2Data_avg.length; i++) {
        var Datalist = COCO2Data_avg[i];
        lstCOCO2_avg.push({
            label: Datalist.Kiln_Length,
            y: Datalist.COCO2_Value

        });
    }


    chart1 = new CanvasJS.Chart(chartarea,
        {
            zoomEnabled: true,
            animationEnabled: true,
            backgroundColor: "white",
            theme: "theme3",
            exportEnabled: false,
            zoomType: "x",
            interactivityEnabled: true,
            toolTip:
            {
                shared: true,

            },

            //legend: {
            //    cursor: "pointer",
            //    verticalAlign: "top",
            //    horizontalAlign: "center",
            //    fontColor: "#ffffff",
            //    FontWeight: "bolder",
            //    FontSize: 15,
            //    itemMaxWidth: 1000,

            //},
            axisX:
            {
                gridThickness: 1,
                //gridColor:"white",
                lineColor: "black",
                titleFontColor: "black",
                labelFontColor: "black",
                labelFontSize: "12",
                titleFontSize: "12",
                titleFontWeight: "normal",
                labelFontWeight: "normal",
                tickColor: "#ffffff",
                title: "KILN LENGTH (m)",
                interval: 1

            },

            axisY: [

                {
                    gridThickness: 1,
                    tickColor: "white",
                    title: "CO/CO2 (%)",
                    lineColor: "black",
                    titleFontColor: "black",
                    labelFontColor: "black",
                    labelFontSize: "12",
                    titleFontSize: "12",
                    titleFontWeight: "normal",
                    labelFontWeight: "normal",
                    tickColor: "black",

                }],

            //  dataPointMaxWidth: 20,

            data: [{

                lineThickness: 2,
                markerType: "circle",
                // markerColor: "#FFFFFF",
                type: "line",
                name: "CO/CO2",
                showInLegend: true,
                axisYIndex: 0,
                axisYType: "primary",
                color: "red",
                dataPoints: lstCOCO2
            },
            {

                lineThickness: 2,
                markerType: "circle",
                // markerColor: "#FFFFFF",
                type: "line",
                name: "CO/CO2 AVG",
                showInLegend: true,
                axisYIndex: 0,
                axisYType: "primary",
                color: "blue",
                dataPoints: lstCOCO2_avg
            }

            ]
        });

    chart1.render();
}

function drawCarbonAvailabilityGraph(finalData, kilnNo) {
    if (finalData == null) {
        return;
    }
    var lstCarbon = []; var lstCarbon_avg = [];
    //CarbonData = DataList[0]; CarbonData_avg = DataList[1]; 
    var chartarea;



    if (kilnNo == 6)
        chartarea = "chartcarbonAvailability6";
    if (kilnNo == 2)
        chartarea = "chartcarbonAvailability2";
    if (kilnNo == 1)
        chartarea = "chartcarbonAvailability1";
    if (kilnNo == 5)
        chartarea = "chartcarbonAvailability5";
    if (kilnNo == 3)
        chartarea = "chartcarbonAvailability3";
    if (kilnNo == 4)
        chartarea = "chartcarbonAvailability4";

    CarbonData = finalData[0]; CarbonData_avg = finalData[1];
    if (CarbonData == null || CarbonData_avg == null) {
        return;
    }
    for (var i = 0; i < CarbonData.length; i++) {
        var Datalist = CarbonData[i];
        lstCarbon.push({
            label: Datalist.Kiln_Length,
            y: Datalist.Carbon_Value
        });
    }
    for (var i = 0; i < CarbonData_avg.length; i++) {
        var Datalist = CarbonData_avg[i];
        lstCarbon_avg.push({
            label: Datalist.Kiln_Length,
            y: Datalist.Carbon_Value

        });
    }


    chart1 = new CanvasJS.Chart(chartarea,
        {
            zoomEnabled: true,
            animationEnabled: true,
            backgroundColor: "white",
            theme: "theme3",
            exportEnabled: false,
            zoomType: "x",
            interactivityEnabled: true,
            toolTip:
            {
                shared: true,

            },

            //legend: {
            //    cursor: "pointer",
            //    verticalAlign: "top",
            //    horizontalAlign: "center",
            //    fontColor: "#ffffff",
            //    FontWeight: "bolder",
            //    FontSize: 15,
            //    itemMaxWidth: 1000,

            //},
            axisX:
            {
                gridThickness: 1,
                //gridColor:"white",
                lineColor: "black",
                titleFontColor: "black",
                labelFontColor: "black",
                labelFontSize: "12",
                titleFontSize: "12",
                titleFontWeight: "normal",
                labelFontWeight: "normal",
                tickColor: "#ffffff",
                title: "KILN LENGTH (m)",
                interval: 1

            },

            axisY: [

                {
                    gridThickness: 1,
                    tickColor: "white",
                    title: "CARBON AVAILABILITY",
                    lineColor: "black",
                    titleFontColor: "black",
                    labelFontColor: "black",
                    labelFontSize: "12",
                    titleFontSize: "12",
                    titleFontWeight: "normal",
                    labelFontWeight: "normal",
                    tickColor: "black",

                }],

            //  dataPointMaxWidth: 20,

            data: [{

                lineThickness: 2,
                markerType: "circle",
                // markerColor: "#FFFFFF",
                type: "line",
                name: "Carbon Availability",
                showInLegend: true,
                axisYIndex: 0,
                axisYType: "primary",
                color: "red",
                dataPoints: lstCarbon
            },
            {
                lineThickness: 2,
                markerType: "circle",
                // markerColor: "#FFFFFF",
                type: "line",
                name: "Carbon Availability AVG",
                showInLegend: true,
                axisYIndex: 0,
                axisYType: "primary",
                color: "blue",
                dataPoints: lstCarbon_avg
            }

            ]
        });

    chart1.render();
}

function drawGraphFemVsLength(graphdata, kilnNo) {
    //debugger;
    var lstFemVsLength = [];
    if (graphdata == null)
        return "";
    for (var i = 0; i < graphdata.length; i++) {
        var Datalist = graphdata[i];
        lstFemVsLength.push({
            label: Datalist.Kiln_Length,
            y: Datalist.Fem_Value,

        });

    }

    var chartarea;
    if (graphModal == 1)
        chartarea = "chartContainer";
    else {
        if (kilnNo == 6)
            chartarea = "chartContainerKiln6FemVsLength";
        if (kilnNo == 1)
            chartarea = "chartContainerKiln1FemVsLength";
        if (kilnNo == 2)
            chartarea = "chartContainerKiln2FemVsLength";
        if (kilnNo == 5)
            chartarea = "chartContainerKiln5FemVsLength";
        if (kilnNo == 3)
            chartarea = "chartContainerKiln3FemVsLength";
        if (kilnNo == 4)
            chartarea = "chartContainerKiln4FemVsLength";
    }
    chart1 = new CanvasJS.Chart(chartarea,
        {
            zoomEnabled: true,
            animationEnabled: true,
            //title: {
            //    text: "FeM VS TIME",
            //    fontColor: "#ffffff",
            //    fontFamily: "Arial",
            //    fontWeight: "bold"
            //},
            backgroundColor: "white",
            theme: "theme3",
            exportEnabled: false,
            zoomType: "x",
            interactivityEnabled: true,
            //height: 400,
            //width:1200,
            toolTip:
            {
                shared: true,

            },

            //legend: {
            //    cursor: "pointer",
            //    verticalAlign: "top",
            //    horizontalAlign: "center",
            //    fontColor: "#ffffff",
            //    FontWeight: "bolder",
            //    FontSize: 15,
            //    itemMaxWidth: 1000,

            //},
            axisX:
            {

                gridThickness: 1,
                // gridColor:"white",
                //lineColor: "black",
                titleFontColor: "black",
                labelFontColor: "black",
                labelFontSize: "12",
                titleFontSize: "12",
                titleFontWeight: "normal",
                labelFontWeight: "normal",
                tickColor: "#ffffff",
                title: "KILN LENGTH (m)",
                interval: 1

            },

            axisY: [

                {
                    gridThickness: 1,
                    // gridColor:"white",
                    title: "Fe-M (%)",
                    lineColor: "black",
                    titleFontColor: "black",
                    labelFontColor: "black",
                    labelFontSize: "12",
                    titleFontSize: "12",
                    titleFontWeight: "normal",
                    labelFontWeight: "normal",
                    tickColor: "black",
                    //minimum: 50,
                    //maximum: 90,
                    // interval: 25

                }],

            dataPointMaxWidth: 20,

            data: [{
                //click: function (e) {

                //    viewDataPointGraph(e);
                //},

                lineThickness: 2,
                markerType: "circle",
                // markerColor: "#FFFFFF",
                type: "line",
                name: "Fem",
                showInLegend: false,
                axisYIndex: 0,
                indexLabel: "{y}",
                indexLabelFontSize: 0,
                indexLabelPlacement: "top",
                indexLabel: "FLAGGED",
                axisYType: "primary",
                color: "red",
                dataPoints: lstFemVsLength

            }

            ]
        });

    chart1.render();

}

function drawGraphPressure(graphdata, kilnNo) {
    if (graphdata == null)
        return "";
    var lstPressureInlet = [];
    var lstPressureOutlet = [];
    // debugger;
    for (var i = 0; i < graphdata.length; i++) {
        var Datalist = graphdata[i];
        lstPressureInlet.push({
            label: Datalist.Date_Time,
            y: Datalist.P_INLET,

        });
        lstPressureOutlet.push({
            label: Datalist.Date_Time,
            y: Datalist.P_OUTLET,

        });
    }
    var chartarea;
    if (graphModal == 1)
        chartarea = "chartContainer";
    else {
        if (kilnNo == 6)
            chartarea = "chartContainerKiln6Pressure";
        if (kilnNo == 1)
            chartarea = "chartContainerKiln1Pressure";
        if (kilnNo == 2)
            chartarea = "chartContainerKiln2Pressure";
        if (kilnNo == 5)
            chartarea = "chartContainerKiln5Pressure";
        if (kilnNo == 3)
            chartarea = "chartContainerKiln3Pressure";
        if (kilnNo == 4)
            chartarea = "chartContainerKiln4Pressure";
    }


    chart1 = new CanvasJS.Chart(chartarea,
        {
            zoomEnabled: true,
            animationEnabled: true,
            //title: {
            //    text: "FeM VS TIME",
            //    fontColor: "#ffffff",
            //    fontFamily: "Arial",
            //    fontWeight: "bold"
            //},
            backgroundColor: "white",
            theme: "theme3",
            exportEnabled: false,
            zoomType: "x",
            interactivityEnabled: true,
            //height: 400,
            //width:1200,
            toolTip:
            {
                shared: true,

            },

            //legend: {
            //    cursor: "pointer",
            //    verticalAlign: "top",
            //    horizontalAlign: "center",
            //    fontColor: "#ffffff",
            //    FontWeight: "bolder",
            //    FontSize: 15,
            //    itemMaxWidth: 1000,

            //},
            axisX:
            {
                gridThickness: 1,
                tickColor: "white",
                lineColor: "black",
                titleFontColor: "black",
                labelFontColor: "black",
                labelFontSize: "12",
                titleFontSize: "12",
                titleFontWeight: "normal",
                labelFontWeight: "normal",
                tickColor: "#ffffff",
                title: "Date Time",
                interval: 50,
                labelAngle: 180


            },

            axisY: [

                {
                    gridThickness: 1,
                    tickColor: "white",
                    title: "Pressure (mm WC)",
                    lineColor: "black",
                    titleFontColor: "black",
                    labelFontColor: "black",
                    labelFontSize: "12",
                    titleFontSize: "12",
                    titleFontWeight: "normal",
                    labelFontWeight: "normal",
                    tickColor: "black",
                    //minimum: 50,
                    //maximum: 90,
                    // interval: 2

                }],

            dataPointMaxWidth: 20,

            legend: {
                cursor: "pointer",
                verticalAlign: "top",
                horizontalAlign: "center",
                fontColor: "black",
                FontWeight: "bolder",
                FontSize: 15,
                itemMaxWidth: 1000
            },

            data: [

                {
                    //click: function (e) {

                    //    viewDataPointGraph(e);
                    //},

                    lineThickness: 2,
                    markerType: "circle",
                    markerColor: "#FFFFFF",
                    type: "line",
                    name: "Pres_Inlet",
                    showInLegend: true,
                    axisYIndex: 0,
                    indexLabel: "{y}",
                    indexLabelFontSize: 0,
                    indexLabelPlacement: "top",
                    indexLabel: "FLAGGED",
                    axisYType: "primary",
                    color: "red",
                    dataPoints: lstPressureInlet

                },



                {
                    //click: function (e) {

                    //    viewDataPointGraph(e);
                    //},

                    lineThickness: 2,
                    markerType: "circle",
                    markerColor: "#FFFFFF",
                    type: "line",
                    name: "Pres_Outlet",
                    showInLegend: true,
                    axisYIndex: 0,
                    indexLabel: "{y}",
                    indexLabelFontSize: 0,
                    indexLabelPlacement: "top",
                    indexLabel: "FLAGGED",
                    axisYType: "primary",
                    color: "blue",
                    dataPoints: lstPressureOutlet

                }

            ]
        });

    chart1.render();

}





function drawGraphFemVsTime(graphdata, kilnNo) {

    debugger;
    //modified New Requirement Graph1
    if (graphdata == null)
        return "";
    var lstFEM16 = [];
    var lstFEM_ACT = [];
    // debugger;
    for (var i = 0; i < graphdata.length; i++) {
        var Datalist = graphdata[i];
        lstFEM16.push({
            label: Datalist.TIME_STAMP,
            y: Datalist.FEM16,

        });
        lstFEM_ACT.push({
            label: Datalist.TIME_STAMP,
            y: Datalist.FEM_ACT,

        });
    }
    var chartarea;
    if (graphModal == 1)
        chartarea = "chartContainer";
    else {
        if (kilnNo == 6)


            chartarea = "chartContainerKiln6";
        if (kilnNo == 1)


            chartarea = "chartContainerKiln1";
        if (kilnNo == 2)
            chartarea = "chartContainerKiln2";
        if (kilnNo == 3)
            chartarea = "chartContainerKiln3";
        if (kilnNo == 4)
            chartarea = "chartContainerKiln4";
        if (kilnNo == 5)
            chartarea = "chartContainerKiln5";
    }


    chart1 = new CanvasJS.Chart(chartarea,
        {
            zoomEnabled: true,
            animationEnabled: true,
            //title: {
            //    text: "FeM VS TIME",
            //    fontColor: "#ffffff",
            //    fontFamily: "Arial",
            //    fontWeight: "bold"
            //},
            backgroundColor: "white",
            theme: "theme3",
            exportEnabled: false,
            zoomType: "x",
            interactivityEnabled: true,

            //height: 400,
            //width:1200,
            toolTip:
            {
                shared: true,

            },

            //legend: {
            //    cursor: "pointer",
            //    verticalAlign: "top",
            //    horizontalAlign: "center",
            //    fontColor: "#ffffff",
            //    FontWeight: "bolder",
            //    FontSize: 15,
            //    itemMaxWidth: 1000,

            //},
            axisX:
            {
                gridThickness: 1,
                tickColor: "white",
                lineColor: "black",
                titleFontColor: "black",
                labelFontColor: "black",
                labelFontSize: "12",
                titleFontSize: "12",
                titleFontWeight: "normal",
                labelFontWeight: "normal",
                tickColor: "#ffffff",
                title: "Date Time",




            },

            axisY: [

                {
                    gridThickness: 1,

                    tickColor: "white",
                    title: "Fe-M(%)",
                    lineColor: "black",
                    titleFontColor: "black",
                    labelFontColor: "black",
                    labelFontSize: "12",
                    titleFontSize: "12",
                    titleFontWeight: "normal",
                    labelFontWeight: "normal",
                    tickColor: "black",
                    minimum: 70,
                    maximum: 90,
                    interval: 5

                }],

            dataPointMaxWidth: 20,

            legend: {
                cursor: "pointer",
                verticalAlign: "top",
                horizontalAlign: "center",
                fontColor: "black",
                FontWeight: "bolder",
                FontSize: 15,
                itemMaxWidth: 1000
            },

            data: [

                {
                    //click: function (e) {

                    //    viewDataPointGraph(e);
                    //},

                    lineThickness: 2,
                    markerType: "circle",
                    markerColor: "#FFFFFF",
                    type: "line",
                    name: "Fe-M Predicted",
                    showInLegend: true,
                    axisYIndex: 0,
                    indexLabel: "{y}",
                    indexLabelFontSize: 0,
                    indexLabelPlacement: "top",
                    indexLabel: "FLAGGED",
                    axisYType: "primary",
                    color: "red",
                    dataPoints: lstFEM16

                },



                {
                    //click: function (e) {

                    //    viewDataPointGraph(e);
                    //},

                    lineThickness: 2,
                    markerType: "circle",
                    markerColor: "#FFFFFF",
                    type: "line",
                    name: "Fe-M ACT",
                    showInLegend: true,
                    axisYIndex: 0,
                    indexLabel: "{y}",
                    indexLabelFontSize: 0,
                    indexLabelPlacement: "top",
                    indexLabel: "FLAGGED",
                    axisYType: "primary",
                    color: "blue",
                    dataPoints: lstFEM_ACT

                }

            ]
        });

    chart1.render();

}
function drawGraphSulpherVsTime(graphdata, kilnNo) {

    debugger;
    //modified New Requirement Graph1
    if (graphdata == null)
        return "";
    var lstSU1 = [];
    var lstSUL_FINE_ACT = [];

    var lstSUL_LUMP_ACT = [];
    // debugger;
    for (var i = 0; i < graphdata.length; i++) {
        var Datalist = graphdata[i];
        lstSU1.push({
            label: Datalist.TIME_STAMP,
            y: Datalist.SU1,

        });
        lstSUL_FINE_ACT.push({
            label: Datalist.TIME_STAMP,
            y: Datalist.SUL_FINE_ACT,

        });

        lstSUL_LUMP_ACT.push({
            label: Datalist.TIME_STAMP,
            y: Datalist.SUL_LUMP_ACT,

        });
    }
    var chartarea;
    if (graphModal == 1)
        chartarea = "chartContainer";
    else {



        chartarea = "chartContainerSulpher" + kilnNo;
    }


    chart1 = new CanvasJS.Chart(chartarea,
        {
            zoomEnabled: true,
            animationEnabled: true,

            backgroundColor: "white",
            theme: "theme3",
            exportEnabled: false,
            zoomType: "x",
            interactivityEnabled: true,

            toolTip:
            {
                shared: true,

            },


            axisX:
            {
                gridThickness: 1,
                tickColor: "white",
                lineColor: "black",
                titleFontColor: "black",
                labelFontColor: "black",
                labelFontSize: "12",
                titleFontSize: "12",
                titleFontWeight: "normal",
                labelFontWeight: "normal",
                tickColor: "#ffffff",
                title: "Date Time",




            },

            axisY: [

                {
                    gridThickness: 1,

                    tickColor: "white",
                    title: "SULPHER(%)",
                    lineColor: "black",
                    titleFontColor: "black",
                    labelFontColor: "black",
                    labelFontSize: "12",
                    titleFontSize: "12",
                    titleFontWeight: "normal",
                    labelFontWeight: "normal",
                    tickColor: "black",
                    //minimum: 50,
                    //maximum: 100,
                    interval: 0.01

                }],

            dataPointMaxWidth: 20,

            legend: {
                cursor: "pointer",
                verticalAlign: "top",
                horizontalAlign: "center",
                fontColor: "black",
                FontWeight: "bolder",
                FontSize: 15,
                itemMaxWidth: 1000
            },

            data: [

                {
                    //click: function (e) {

                    //    viewDataPointGraph(e);
                    //},

                    lineThickness: 2,
                    markerType: "circle",
                    markerColor: "#FFFFFF",
                    type: "line",
                    name: "SU1",
                    showInLegend: true,
                    axisYIndex: 0,
                    indexLabel: "{y}",
                    indexLabelFontSize: 0,
                    indexLabelPlacement: "top",
                    indexLabel: "FLAGGED",
                    axisYType: "primary",
                    color: "red",
                    dataPoints: lstSU1

                },



                {


                    lineThickness: 2,
                    markerType: "circle",
                    markerColor: "#FFFFFF",
                    type: "line",
                    name: "SUL_FINE_ACT",
                    showInLegend: true,
                    axisYIndex: 0,
                    indexLabel: "{y}",
                    indexLabelFontSize: 0,
                    indexLabelPlacement: "top",
                    indexLabel: "FLAGGED",
                    axisYType: "primary",
                    color: "blue",
                    dataPoints: lstSUL_FINE_ACT

                },
                {


                    lineThickness: 2,
                    markerType: "circle",
                    markerColor: "#FFFFFF",
                    type: "line",
                    name: "SUL_LUMP_ACT",
                    showInLegend: true,
                    axisYIndex: 0,
                    indexLabel: "{y}",
                    indexLabelFontSize: 0,
                    indexLabelPlacement: "top",
                    indexLabel: "FLAGGED",
                    axisYType: "primary",
                    color: "yellow",
                    dataPoints: lstSUL_LUMP_ACT

                }
            ]
        });

    chart1.render();

}
//graph 3
function drawGraphCarbonChar(graphdata, kilnNo) {

    debugger;
    //modified New Requirement Graph1
    if (graphdata == null)
        return "";
    var lstC1 = [];
    // var lstFEM_ACT = [];
    // debugger;
    for (var i = 0; i < graphdata.length; i++) {
        var Datalist = graphdata[i];
        lstC1.push({
            label: Datalist.TIME_STAMP,
            y: Datalist.C1,

        });

    }
    var chartarea;
    if (graphModal == 1)
        chartarea = "chartContainer";
    else {
        chartarea = "chartContainerChar" + kilnNo;
    }


    chart1 = new CanvasJS.Chart(chartarea,
        {
            zoomEnabled: true,
            animationEnabled: true,
            //title: {
            //    text: "FeM VS TIME",
            //    fontColor: "#ffffff",
            //    fontFamily: "Arial",
            //    fontWeight: "bold"
            //},
            backgroundColor: "white",
            theme: "theme3",
            exportEnabled: false,
            zoomType: "x",
            interactivityEnabled: true,
            //height: 400,
            //width:1200,
            toolTip:
            {
                shared: true,

            },

            //legend: {
            //    cursor: "pointer",
            //    verticalAlign: "top",
            //    horizontalAlign: "center",
            //    fontColor: "#ffffff",
            //    FontWeight: "bolder",
            //    FontSize: 15,
            //    itemMaxWidth: 1000,

            //},
            axisX:
            {
                gridThickness: 1,
                tickColor: "white",
                lineColor: "black",
                titleFontColor: "black",
                labelFontColor: "black",
                labelFontSize: "12",
                titleFontSize: "12",
                titleFontWeight: "normal",
                labelFontWeight: "normal",
                tickColor: "#ffffff",
                title: "Date Time",



            },

            axisY: [

                {
                    gridThickness: 1,

                    tickColor: "red",
                    title: "Carbon-Char(%)",
                    lineColor: "black",
                    titleFontColor: "black",
                    labelFontColor: "black",
                    labelFontSize: "12",
                    titleFontSize: "12",
                    titleFontWeight: "normal",
                    labelFontWeight: "normal",
                    tickColor: "black",
                    //minimum: 50,
                    //maximum: 90,
                    // interval: 2

                }],

            dataPointMaxWidth: 20,

            legend: {
                cursor: "pointer",
                verticalAlign: "top",
                horizontalAlign: "center",
                fontColor: "black",
                FontWeight: "bolder",
                FontSize: 15,
                itemMaxWidth: 1000
            },

            data: [

                {
                    //click: function (e) {

                    //    viewDataPointGraph(e);
                    //},

                    lineThickness: 2,
                    markerType: "circle",
                    markerColor: "#FFFFFF",
                    type: "line",
                    name: "C1",
                    showInLegend: true,
                    axisYIndex: 0,
                    indexLabel: "{y}",
                    indexLabelFontSize: 0,
                    indexLabelPlacement: "top",
                    indexLabel: "FLAGGED",
                    axisYType: "primary",
                    color: "red",
                    dataPoints: lstC1

                }





            ]
        });

    chart1.render();

}
//============================================ AJAX FUNCTION FOR Fe-M VS TIME DATA ===================================================
//graph 1
function getFeVsTimeData(kilnNo) {
    ////debugger;
    //var kiln = kiln;
    //var kilnNo = (kiln.substring(2)).toUpperCase();
    //kilnNo = kilnNo.substring(0,4)+"-"+kilnNo.substring(4,5)


    // document.getElementById('kiln'+kilnNo+'FvtTitle').innerHTML="KILN-"+kilnNo+" FeM VS TIME";
    if (kilnNo != "") {
        $.ajax({
            type: "POST",
            url: "DRIService.asmx/QMFeMvsTime",
            data: "{'KILN':'" + kilnNo + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                //debugger;
                if (response.d == null) {
                    alert("No data found");
                }
                if (response.d != null || response.d != "" || response.d.length != 0) {
                    FeMtChartData = response.d;
                    //var lineChartData = response.d.slice(0, -1);
                    //var FeMtChartData = response.d[(response.d.length) - 1];

                    //  FeMvsTimeGraph(FeMtChartData, kilnNo);
                    // drawPlotlyFemVsTime(FeMtChartData, kilnNo);
                    drawGraphFemVsTime(FeMtChartData, kilnNo) // new 

                }

            },
            error: function (jqxhr) {
                alert(jqxhr.responseText);
            },
        });
    }
    else {

        return "";
    }

}
//graph 1

//==================================================================================================================


//================================ AJAX FUNCTION FOR FETCHING ACERATION MODEL'S TC TREND ===========================

function getAccProTCTrend(TC, kilnNo) {

    // kilnNo = 5;
    //debugger;
    //var kiln = kiln;  ftKiln1  ap2dT1 tcTrendT1
    //var TC = (TC.substring(7)).toUpperCase();

    //kilnNo = kilnNo.substring(0,4)+"-"+kilnNo.substring(4,5)
    //document.getElementById('aptcTrendTitleKiln'+kilnNo).innerHTML="KILN-"+kilnNo+" "+TC+" TC TREND";
    if (TC != "") {
        $.ajax({
            type: "POST",
            url: "DRIService.asmx/acerationModelTCTrend",
            ///data:"{'TC':'" +TC +"'}",
            data: "{ 'TC':'" + TC + "','kilnNo':'" + kilnNo + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                //debugger;
                if (response.d == null) {
                    alert("No data found");
                }
                if (response.d != null || response.d != "" || response.d.length != 0) {
                    tcTrendData = response.d;

                    tcTrendGraph(tcTrendData, TC, kilnNo);
                }

            },
            error: function (jqxhr) {
                alert(jqxhr.responseText);
            },
        });
    }
    else {

        return "";
    }

}

//=============================================================================================================================



//================================ AJAX FUNCTION FOR FETCHING ACERATION MODEL'S 2D PROFILE ===========================

$("#acc2DdateKiln1").change(function () {
    //debugger;
    acc2DDate = document.getElementById('acc2DdateKiln1').value;
    getAreaChartData(1, acc2DDate);
})
$("#acc2DdateKiln2").change(function () {
    debugger;
    acc2DDate = document.getElementById('acc2DdateKiln2').value;
    getAreaChartData(2, acc2DDate);
})
$("#acc2DdateKiln3").change(function () {
    debugger;
    acc2DDate = document.getElementById('acc2DdateKiln3').value;
    getAreaChartData(3, acc2DDate);
})
$("#acc2DdateKiln4").change(function () {
    debugger;
    acc2DDate = document.getElementById('acc2DdateKiln4').value;
    getAreaChartData(4, acc2DDate);
})
$("#acc2DdateKiln5").change(function () {
    debugger;
    acc2DDate = document.getElementById('acc2DdateKiln5').value;
    getAreaChartData(4, acc2DDate);
})
$("#acc2DdateKiln6").change(function () {
    debugger;
    acc2DDate = document.getElementById('acc2DdateKiln6').value;
    getAreaChartData(4, acc2DDate);
})






function getAccPro2D(kiln) {
    debugger;
    KilnNo = kiln;
    var acc2DDate;
    document.getElementById('acc2DdateKiln' + kiln).classList.remove("d-none");
    document.getElementById('acc2DdateKiln' + kiln).classList.add("d-block");

    document.getElementById('acc2DSelKiln' + kiln).classList.remove("d-none");
    document.getElementById('acc2DSelKiln' + kiln).classList.add("d-block");
    //var kiln = kiln;  ftKiln1  ap2dT1 tcTrendT1 acc2DKiln1
    //var kiln = (kiln.substring(5)).toUpperCase();

    //kilnNo = kilnNo.substring(0,4)+"-"+kilnNo.substring(4,5)
    //document.getElementById('acc2DProfileTitleKiln'+kiln).innerHTML="KILN-"+kiln+" ACCERATION 2D PROFILE";

    var Today = new Date();

    if (kiln != "") {
        //document.getElementById('acc2DdateKiln'+kiln).defaultValue =Today.getFullYear()+"-"+('0' + (Today.getMonth()+1)).slice(-2)+"-"+('0' + Today.getDate()).slice(-2);
        document.getElementById('acc2DdateKiln' + kiln).defaultValue = "2023-03-25";
    }

    acc2DDate = document.getElementById('acc2DdateKiln' + kiln).value;
    debugger;
    //ON DATE CHANGE
    getAreaChartData(kiln, acc2DDate);
    getAccVolumeData(kiln);
    getAccProTCTrend("T1", kiln)
}

function getAreaChartData(kiln, acc2DDate) {
    debugger;
    if (kiln != "") {
        $.ajax({
            type: "POST",
            url: "DRIService.asmx/accerationModel2D",
            //data:"{'kiln':'" +kiln +"'}",
            data: "{ 'kiln':'" + kiln + "','acc2DDate':'" + acc2DDate + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            beforeSend: function () {
                x = document.getElementById("loading-image");
                x.style.display = "block";
            },
            complete: function () {
                // Hide image container
                x = document.getElementById("loading-image");
                x.style.display = "none";
            },
            success: function (response) {
                // document.getElementById('acc2DProfileTitleKiln'+kiln).innerHTML="KILN-"+kiln+" ACCERATION 2D PROFILE FROM "+ acc2DDate;


                // alert(response);
                debugger;
                if (response.d == null) {
                    debugger;
                    alert("No data found");
                }
                if (response.d != null || response.d != "" || response.d.length != 0) {
                    acc2DProfileData = response.d;
                    if (kiln == 5)
                        document.getElementById('acc2DdateKiln5').value = acc2DProfileData[0].CAMPGN_DATE;
                    if (kiln == 2)
                        document.getElementById('acc2DdateKiln2').value = acc2DProfileData[0].CAMPGN_DATE;
                    if (kiln == 3)
                        document.getElementById('acc2DdateKiln3').value = acc2DProfileData[0].CAMPGN_DATE;
                    if (kiln == 4)
                        document.getElementById('acc2DdateKiln4').value = acc2DProfileData[0].CAMPGN_DATE;
                    if (kiln == 6)
                        document.getElementById('acc2DdateKiln6').value = acc2DProfileData[0].CAMPGN_DATE;

                    if (kiln == 1)
                        document.getElementById('acc2DdateKiln1').value = acc2DProfileData[0].CAMPGN_DATE;
                    if (kiln == 2)
                        document.getElementById('acc2DdateKiln2').value = acc2DProfileData[0].CAMPGN_DATE;
                    acc2DProfileGraph(acc2DProfileData, kiln)
                }

            },
            error: function (jqxhr) {
                debugger;
                alert(jqxhr.responseText);
            },
        });
    }
    else {

        return "";
    }

}

function getAccVolumeData(kiln) {
    if (kiln != "") {
        $.ajax({
            type: "POST",
            url: "DRIService.asmx/getAccVolumeData",
            data: "{ 'kiln':'" + kiln + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            beforeSend: function () {
                x = document.getElementById("loading-image");
                x.style.display = "block";
            },
            complete: function () {
                // Hide image container
                x = document.getElementById("loading-image");
                x.style.display = "none";
            },
            success: function (response) {
                debugger;
                if (response.d == null) {
                    alert("No data found");
                }
                if (response.d != null || response.d != "" || response.d.length != 0) {
                    acc2DVolData = response.d;
                    acc2DVolumeGraph(acc2DVolData, kiln)
                }

            },
            error: function (jqxhr) {
                debugger;
                alert(jqxhr.responseText);
            },
        });
    }
    else {

        return "";
    }
}
//=============================================================================================================================

//========================================TRENDS TAB GRAPH DATA ====================================================
function getTrendsGraph(kilnNo) {
    debugger;
    var fromDate = document.getElementById("FromDateTrendK1").value;
    var toDate = document.getElementById("ToDateTrendK1").value;
    var param = $("#param_ddl").val();
    var kiln = KilnNo
    $.ajax({
        type: "POST",
        url: "DRIService.asmx/ParameterTrendsData",
        data: "{ 'FromDate':'" + fromDate + "','ToDate':'" + toDate + "','Param':'" + param + "','Kiln':'" + kilnNo + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {
            debugger;
            document.getElementById("chartTrends1").innerHTML = "";
            if (response.d == null || response.d == "" && response.d.length == 0)
            {
               //alert("No data found");
            }
            if (response.d != null && response.d != "" && response.d.length != 0) {
                data = response.d;
                drawParamVsTimeGraph(data, param, kiln);
            }

        },
        error: function (jqxhr) {
            debugger;
            alert(jqxhr.responseText);
        },
    });
}

function drawParamVsTimeGraph(graphdata, param, kiln) {
    debugger;
    var lstseries = []; var lstseries2 = []; var lstseries3 = []; var lstseries4 = []; var lstseries5 = []; var lstseries6 = []; var lstseries7 = [];
    var lstseries8 = []; var lstseries9 = []; var lstseries10 = [];

    var lstdataPred = []; var prepDataSet = [];
    if (param == "RPM") {
        for (var i = 0; i < graphdata.length; i++) {
            var Datalist = graphdata[i];
            lstseries.push({
                label: Datalist.Date_Time,
                y: Datalist.KILN_RPM,
            });
        }
        prepDataSet.push({
            type: "line",
            name: param,
            showInLegend: true,
            dataPoints: lstseries
        })
    }
    else if (param == "Iron Ore Rate") {
        for (var i = 0; i < graphdata.length; i++) {
            var Datalist = graphdata[i];
            lstseries.push({
                label: Datalist.Date_Time,
                y: Datalist.FE_FEED,
            });
        }
        prepDataSet.push({
            type: "line",
            name: param,
            showInLegend: true,
            dataPoints: lstseries
        })
    }
    else if (param == "Dolomite Rate") {
        for (var i = 0; i < graphdata.length; i++) {
            var Datalist = graphdata[i];
            lstseries.push({
                label: Datalist.Date_Time,
                y: Datalist.DOLO,
            });
        }
        prepDataSet.push({
            type: "line",
            name: param,
            showInLegend: true,
            dataPoints: lstseries
        })
    }
    else if (param == "Fuel Rate/Coal Rate") {
        for (var i = 0; i < graphdata.length; i++) {
            var Datalist = graphdata[i];
            lstseries.push({
                label: Datalist.Date_Time,
                y: Datalist.FEEDCOAL,
            });
            lstseries2.push({
                label: Datalist.Date_Time,
                y: Datalist.FINECOAL,
            });
        }
        prepDataSet.push({
            type: "line",
            name: "Fuel Rate",
            showInLegend: true,
            dataPoints: lstseries
        },
            {
                type: "line",
                name: "Coal Rate",
                showInLegend: true,
                dataPoints: lstseries2
            })
    }
    else if (param == "Air_Flow" && (kiln == "1" || kiln == "2")) {
        for (var i = 0; i < graphdata.length; i++) {
            var Datalist = graphdata[i];
            lstseries.push({
                label: Datalist.Date_Time,
                y: Datalist.PAB,
            });
            lstseries2.push({
                label: Datalist.Date_Time,
                y: Datalist.SAB2,
            });
            lstseries3.push({
                label: Datalist.Date_Time,
                y: Datalist.SAB3,
            });
            lstseries4.push({
                label: Datalist.Date_Time,
                y: Datalist.SAB4,
            });
            lstseries5.push({
                label: Datalist.Date_Time,
                y: Datalist.SAB5,
            });
            lstseries6.push({
                label: Datalist.Date_Time,
                y: Datalist.SAB6,
            });
            lstseries7.push({
                label: Datalist.Date_Time,
                y: Datalist.SAB7,
            });
            lstseries8.push({
                label: Datalist.Date_Time,
                y: Datalist.SAB8,
            });
            lstseries9.push({
                label: Datalist.Date_Time,
                y: Datalist.SAB9,
            });
            lstseries10.push({
                label: Datalist.Date_Time,
                y: Datalist.SAB10,
            });
        }
        prepDataSet.push({
            type: "line",
            name: "PAB",
            showInLegend: true,
            dataPoints: lstseries
        },
            {
                type: "line",
                name: "SAB2",
                showInLegend: true,
                dataPoints: lstseries2
            },
            {
                type: "line",
                name: "SAB3",
                showInLegend: true,
                dataPoints: lstseries3
            },
            {
                type: "line",
                name: "SAB4",
                showInLegend: true,
                dataPoints: lstseries4
            },
            {
                type: "line",
                name: "SAB5",
                showInLegend: true,
                dataPoints: lstseries5
            },
            {
                type: "line",
                name: "SAB6",
                showInLegend: true,
                dataPoints: lstseries6
            },
            {
                type: "line",
                name: "SAB7",
                showInLegend: true,
                dataPoints: lstseries7
            },
            {
                type: "line",
                name: "SAB8",
                showInLegend: true,
                dataPoints: lstseries8
            },
            {
                type: "line",
                name: "SAB9",
                showInLegend: true,
                dataPoints: lstseries9
            },
            {
                type: "line",
                name: "SAB10",
                showInLegend: true,
                dataPoints: lstseries10
            }
        );
    }
    else if (param == "Air_Flow" && kiln == "3") {
        for (var i = 0; i < graphdata.length; i++) {
            var Datalist = graphdata[i];
            lstseries.push({
                label: Datalist.Date_Time,
                y: Datalist.PAB
            });
            lstseries2.push({
                label: Datalist.Date_Time,
                y: Datalist.SAB2
            });
            lstseries3.push({
                label: Datalist.Date_Time,
                y: Datalist.SAB3,
            });
            lstseries4.push({
                label: Datalist.Date_Time,
                y: Datalist.SAB4
            });
            lstseries5.push({
                label: Datalist.Date_Time,
                y: Datalist.SAB5
            });
            lstseries6.push({
                label: Datalist.Date_Time,
                y: Datalist.SAB6
            });
            lstseries7.push({
                label: Datalist.Date_Time,
                y: Datalist.SAB7
            });
            lstseries8.push({
                label: Datalist.Date_Time,
                y: Datalist.SAB8
            });
            lstseries9.push({
                label: Datalist.Date_Time,
                y: Datalist.SAB9
            });
        }
        prepDataSet.push({
            type: "line",
            name: "PAB",
            showInLegend: true,
            dataPoints: lstseries
        },
            {
                type: "line",
                name: "SAB1",
                showInLegend: true,
                dataPoints: lstseries2
            },
            {
                type: "line",
                name: "SAB2",
                showInLegend: true,
                dataPoints: lstseries3
            },
            {
                type: "line",
                name: "SAB3",
                showInLegend: true,
                dataPoints: lstseries4
            },
            {
                type: "line",
                name: "SAB4",
                showInLegend: true,
                dataPoints: lstseries5
            },
            {
                type: "line",
                name: "SAB5",
                showInLegend: true,
                dataPoints: lstseries6
            },
            {
                type: "line",
                name: "SAB6",
                showInLegend: true,
                dataPoints: lstseries7
            },
            {
                type: "line",
                name: "SAB7",
                showInLegend: true,
                dataPoints: lstseries8
            },
            {
                type: "line",
                name: "SAB8",
                showInLegend: true,
                dataPoints: lstseries9
            });
    }
    else if (param == "FC analysis") {
        for (var i = 0; i < graphdata.length; i++) {
            var Datalist = graphdata[i];
            lstseries.push({
                label: Datalist.Date_Time,
                y: Datalist.FC_MC,
            });
            lstseries2.push({
                label: Datalist.Date_Time,
                y: Datalist.FC_VM,
            });
            lstseries3.push({
                label: Datalist.Date_Time,
                y: Datalist.FC_ASH,
            });
            lstseries4.push({
                label: Datalist.Date_Time,
                y: Datalist.FC_FIXEDCARBON,
            });
        }
        prepDataSet.push({
            type: "line",
            name: "FC_MC",
            showInLegend: true,
            dataPoints: lstseries
        },
            {
                type: "line",
                name: "FC_VM",
                showInLegend: true,
                dataPoints: lstseries2
            },
            {
                type: "line",
                name: "FC_ASH",
                showInLegend: true,
                dataPoints: lstseries3
            },
            {
                type: "line",
                name: "FC_FIXEDCARBON",
                showInLegend: true,
                dataPoints: lstseries4
            })
    }
    else if (param == "IC analysis") {
        for (var i = 0; i < graphdata.length; i++) {
            var Datalist = graphdata[i];
            lstseries.push({
                label: Datalist.Date_Time,
                y: Datalist.IC_MC,
            });
            lstseries2.push({
                label: Datalist.Date_Time,
                y: Datalist.IC_VM,
            });
            lstseries3.push({
                label: Datalist.Date_Time,
                y: Datalist.IC_ASH,
            });
            lstseries4.push({
                label: Datalist.Date_Time,
                y: Datalist.IC_FIXEDCARBON,
            });
        }
        prepDataSet.push({
            type: "line",
            name: "IC_MC",
            showInLegend: true,
            dataPoints: lstseries
        },
            {
                type: "line",
                name: "IC_VM",
                showInLegend: true,
                dataPoints: lstseries2
            },
            {
                type: "line",
                name: "IC_ASH",
                showInLegend: true,
                dataPoints: lstseries3
            },
            {
                type: "line",
                name: "IC_FIXEDCARBON",
                showInLegend: true,
                dataPoints: lstseries4
            })
    }
    else if (param == "Ore analysis") {
        for (var i = 0; i < graphdata.length; i++) {
            var Datalist = graphdata[i];
            lstseries.push({
                label: Datalist.Date_Time,
                y: Datalist.ORE_LOI
            });
            lstseries2.push({
                label: Datalist.Date_Time,
                y: Datalist.ORE_MOIST
            });
            lstseries3.push({
                label: Datalist.Date_Time,
                y: Datalist.ORE_FETOTAL
            });
        }
        prepDataSet.push({
            type: "line",
            name: "ORE_LOI",
            showInLegend: true,
            dataPoints: lstseries
        },
            {
                type: "line",
                name: "ORE_MOIST",
                showInLegend: true,
                dataPoints: lstseries2
            },
            {
                type: "line",
                name: "ORE_FETOTAL",
                showInLegend: true,
                dataPoints: lstseries3
            })
    }
    else if (param == "C/Fe Ratio") {
        for (var i = 0; i < graphdata.length; i++) {
            var Datalist = graphdata[i];
            lstseries.push({
                label: Datalist.Date_Time,
                y: Datalist.C_Fe_Ratio,
            });
        }
        prepDataSet.push({
            type: "line",
            name: param,
            showInLegend: true,
            dataPoints: lstseries
        })
    }
    chart1 = new CanvasJS.Chart("chartTrends1",
        {
            zoomEnabled: true,
            animationEnabled: true,
            backgroundColor: "white",
            theme: "theme3",
            exportEnabled: false,
            zoomType: "x",
            interactivityEnabled: true,
            //height: 400,
            //width:1200,
            toolTip:
            {
                shared: true,

            },


            axisX:
            {
                gridThickness: 1,
                tickColor: "white",
                lineColor: "black",
                titleFontColor: "black",
                labelFontColor: "black",
                labelFontSize: "12",
                titleFontSize: "12",
                titleFontWeight: "normal",
                labelFontWeight: "normal",
                tickColor: "#ffffff",
                title: "Date Time",
                // interval: 50,
                labelAngle: 180


            },

            axisY: [

                {
                    gridThickness: 1,
                    tickColor: "white",
                    title: param,
                    lineColor: "black",
                    titleFontColor: "black",
                    labelFontColor: "black",
                    labelFontSize: "12",
                    titleFontSize: "12",
                    titleFontWeight: "normal",
                    labelFontWeight: "normal",
                    tickColor: "black"
                }],

            dataPointMaxWidth: 20,

            legend: {
                cursor: "pointer",
                verticalAlign: "top",
                horizontalAlign: "center",
                fontColor: "black",
                FontWeight: "bolder",
                FontSize: 15,
                itemMaxWidth: 1000
            },

            data: prepDataSet
        });

    chart1.render();
}
//=================================================END=============================================================

//======================================================= GRAPH FOR FeM VS TIME ===============================================

//function drawPlotlyFemVsTime(GraphData,kilnNo) {
//    if(GraphData == null)
//        return "";
//    //  var lineDiv = document.getElementById('line-chart');
//    var x1 = [];
//    var x2 = [];
//    var y1 = [];
//    var y2 = [];
//    var y3=[];
//    var y4=[];
//    var x3=[];
//    var x4=[];
//    var x5=[];
//    var y5=[];

//    var chartarea;
//    var length = GraphData.length;
//    if(  graphModal==1)
//        chartarea="chartContainer";
//    else
//        chartarea="chartContainerKiln"+kilnNo;


//    for (var j = 0; j <GraphData.length; j++) {
//        var dataList = GraphData[j];
//        x1.push(dataList.Date_Time);
//        y1.push(dataList.FEM_PRED_CORR);


//        if( dataList.FE_M_LUMPS!=0 && j < GraphData.length-1)
//        {
//            x2.push(dataList.Date_Time);
//            y2.push(dataList.FE_M_LUMPS);
//        }

//        y3.push(80);
//        y4.push(82);
//        x3.push(dataList.Date_Time);
//        x4.push(dataList.Date_Time);

//        //if( dataList.Fem_Actual2!=0)
//        //{
//        //    x5.push(dataList.Date_Time);
//        //    y5.push(dataList.Fem_Actual2);
//        //}

//    }

//    var traceA = {
//        x: x1,
//        y: y1,
//        type: 'scatter',
//        name: "Predicted",
//        mode: 'lines  markers',
//        line:{
//            color:"blue",
//        }

//    };
//    var traceB = {
//        x: x2,
//        y: y2,
//        type: 'scatter',
//        name: "FE_M LUMPS",
//        mode: 'lines  markers',
//        line:{
//            color:"red",
//        }
//    };

//    var traceC = {
//        x: x3,
//        y: y3,
//       // type: 'scatter',
//        name: "LCL",
//        mode: 'lines',
//        line:{
//            dash: 'dot',
//            color:"green",
//        }
//    };


//    var traceD = {
//        x: x4,
//        y: y4,
//        type: 'scatter',
//        name: "UCL",
//        mode: 'lines ',
//        line:{
//            dash: 'dot',
//            color:"#FF33AF",
//        }
//    };

//    //var traceE= {
//    //    x: x5,
//    //    y: y5,
//    //    type: 'scatter',
//    //    name: "FE_M FINES",
//    //    mode: 'lines',
//    //    line:{          
//    //        color:"brown",
//    //    }
//    //};

//    var data = [traceA, traceB,traceC,traceD];
//    var layout = {
//        height: 220,

//        margin: {
//            l:40,
//            r:20,
//            t: 0,
//            b: 30,
//            pad:1,
//        },
//        yaxis: {

//            title: {
//                text: "Fe-M(%)",
//                font: {
//                    family: 'Arial',
//                    size: 12,
//                    color: 'black'
//                }
//            },
//            //range: [80, 82],
//            showgrid: true,
//            zeroline: true,
//            showline: true,
//            mirror: 'ticks',
//            gridcolor: '#bdbdbd',
//            gridwidth: 1,
//            zerolinecolor: '#969696',
//            zerolinewidth: 1,
//            linecolor: '#636363',
//            linewidth: 1,

//            range:[70,90]
//        },
//        xaxis: {
//            title: {
//               // text: 'Time',
//                font: {
//                    family: 'Courier New, monospace',
//                    size: 12,
//                    color: '#7f7f7f'
//                }
//            },
//            tickmode: "linear",
//            dtick: length/5,
//            showticklabels: true,
//            tickangle:0,
//            tickfont: {
//                family: 'Old Standard TT, serif',
//                size: 14,
//                color: 'black'
//            },
//            //exponentformat: 'e',
//            //showexponent: 'all',
//            showgrid: true,
//            zeroline: true,
//            showline: true,
//            mirror: 'ticks',
//            gridcolor: '#bdbdbd',
//            gridwidth: 1,
//            zerolinecolor: '#969696',
//            zerolinewidth: 1,
//            linecolor: '#636363',
//            linewidth: 1,

//        },
//        showlegend: true,
//        legend: { "orientation": "h", x: 0.1, y:1.2 }
//    };
//    var config = {
//        responsive: true,
//    };

//    Plotly.newPlot(chartarea, data, layout);
//}













//=============================================================================================================================



//======================================================= GRAPH FOR TC TREND ===============================================
function tcTrendGraph(GraphData, TC, kilnNo) {
    //debugger;
    var tcTrendGraphList = [];
    var ucl = [];
    var lcl = []; var minVal;
    //var FeMvsTimeGraphList_FE_M = [];
    for (var i = 0; i < GraphData.length; i++) {
        var Datalist = GraphData[i];
        if (Datalist.TCSelect == "" || Datalist.TCSelect == null) {
            tcTrendGraphList.push({
                label: Datalist.RUN_TIME,
                y: Datalist.TCSelect,

            });
        }
        else {
            tcTrendGraphList.push({
                label: Datalist.RUN_TIME,
                y: Datalist.TCSelect,
            });
        }
        ucl.push({
            label: Datalist.RUN_TIME,
            y: Datalist.ucl
        });
        lcl.push({
            label: Datalist.RUN_TIME,
            y: Datalist.lcl
        });
    }
    minVal = GraphData[0].lcl;

    var chartarea;
    if (graphModal == 1)
        chartarea = "chartContainer";
    else
        chartarea = "TCTrendChartKiln" + kilnNo;



    chart3 = new CanvasJS.Chart(chartarea,
        {
            zoomEnabled: true,
            animationEnabled: true,

            backgroundColor: "white",
            theme: "theme3",
            exportEnabled: false,
            zoomType: "x",
            interactivityEnabled: true,
            toolTip:
            {
                shared: true,

            },

            legend: {
                gridThickness: 1,
                cursor: "pointer",
                verticalAlign: "top",
                horizontalAlign: "center",
                fontColor: "black",
                FontWeight: "bolder",
                FontSize: 15,
                itemMaxWidth: 1000,

            },
            axisX:
            {
                gridThickness: 1,
                lineColor: "black",
                titleFontColor: "black",
                labelFontColor: "black",
                labelFontSize: "12",
                titleFontSize: "14",
                titleFontWeight: "bold",
                labelFontWeight: "normal",
                tickColor: "#ffffff",
                title: "TIME",
                interval: 20

            },

            axisY: [

                {
                    title: "TEMPERATURE (°C)",
                    lineColor: "black",
                    titleFontColor: "black",
                    labelFontColor: "black",
                    labelFontSize: "12",
                    titleFontSize: "14",
                    titleFontWeight: "bold",
                    labelFontWeight: "normal",
                    tickColor: "black",
                    minimum: minVal - 50,
                    //maximum: 1500,
                    //interval: 200

                }],

            dataPointMaxWidth: 20,

            data: [{
                //click: function (e) {

                //    viewDataPointGraph(e);
                //},

                lineThickness: 2,
                markerType: "cross",
                markerColor: "#FFFFFF",
                type: "line",
                name: TC,
                showInLegend: true,
                axisYIndex: 0,
                indexLabel: "{y}",
                indexLabelFontSize: 0,
                indexLabelPlacement: "top",
                indexLabel: "FLAGGED",
                axisYType: "primary",
                color: "#1968B3",
                dataPoints: tcTrendGraphList

            },
            {
                lineThickness: 1,
                markerType: "none",
                markerColor: "blue",
                type: "line",
                name: "MAXIMUM",
                showInLegend: false,
                axisYIndex: 0,
                indexLabel: "{y}",
                indexLabelFontSize: 0,
                indexLabelPlacement: "top",
                axisYType: "primary",
                color: "green",
                dataPoints: ucl

            },
            {
                lineThickness: 1,
                markerType: "none",
                markerColor: "blue",
                type: "line",
                name: "MINIMUM",
                showInLegend: false,
                axisYIndex: 0,
                indexLabel: "{y}",
                indexLabelFontSize: 0,
                indexLabelPlacement: "top",
                axisYType: "primary",
                color: "red",
                dataPoints: lcl

            }]
        });

    chart3.render();


}

//=============================================================================================================================



//======================================================= GRAPH FOR ACC 2-D TREND ===============================================
function acc2DProfileGraph(GraphData, Kiln) {
    //debugger;
    var accTC5List = [];
    var accTC6List = [];
    var accTC7List = [];
    var accTC8List = [];
    var accTC9List = [];
    var accTC10List = [];
    var accTC11List = [];
    TC = document.getElementById('acc2DSelKiln' + Kiln).value;
    if (GraphData.length > 0)
        for (var i = 0; i < GraphData.length; i++) {
            var Datalist = GraphData[i];


            if (TC == 'All' || TC == 'T5') {
                accTC5List.push({
                    label: Datalist.ENTRY_DATE,
                    y: Datalist.TC5_ACC
                });
            }
            if (TC == 'All' || TC == 'T6') {
                accTC6List.push({
                    label: Datalist.ENTRY_DATE,
                    y: Datalist.TC6_ACC
                });
            }
            if (TC == 'All' || TC == 'T7') {
                accTC7List.push({
                    label: Datalist.ENTRY_DATE,
                    y: Datalist.TC7_ACC
                });
            }
            if (TC == 'All' || TC == 'T8') {
                accTC8List.push({
                    label: Datalist.ENTRY_DATE,
                    y: Datalist.TC8_ACC
                });
            }
            if (TC == 'All' || TC == 'T9') {
                accTC9List.push({
                    label: Datalist.ENTRY_DATE,
                    y: Datalist.TC9_ACC
                });
            }
            if (TC == 'All' || TC == 'T10') {
                accTC10List.push({
                    label: Datalist.ENTRY_DATE,
                    y: Datalist.TC10_ACC
                });
            }
            if (TC == 'All' || TC == 'T11') {
                accTC11List.push({
                    label: Datalist.ENTRY_DATE,
                    y: Datalist.TC11_ACC
                });
            }
        }
    debugger;
    var chartarea;
    if (graphModal == 1)
        chartarea = "chartContainer";
    else
        chartarea = "acc2dChartKiln" + Kiln;
    chart4 = new CanvasJS.Chart(chartarea,
        {
            zoomEnabled: true,
            animationEnabled: true,

            backgroundColor: "white",
            theme: "theme3",
            exportEnabled: false,
            zoomType: "x",
            interactivityEnabled: true,
            toolTip:
            {
                shared: true,

            },

            legend: {
                cursor: "pointer",
                verticalAlign: "top",
                horizontalAlign: "center",
                fontColor: "black",
                FontWeight: "bolder",
                FontSize: 15,
                itemMaxWidth: 1000,
                itemclick: toggleDataSeries
            },

            axisX:
            {
                gridThickness: 1,
                tickColor: "white",
                lineColor: "black",
                titleFontColor: "black",
                labelFontColor: "black",
                labelFontSize: "12",
                titleFontSize: "14",
                titleFontWeight: "bold",
                labelFontWeight: "normal",
                tickColor: "#ffffff",
                title: "DATE",
                interval: 5

            },

            axisY: [

                {
                    gridThickness: 1,
                    tickColor: "white",
                    title: "ACCRETION THICKNESS (mm)",
                    lineColor: "black",
                    titleFontColor: "black",
                    labelFontColor: "black",
                    labelFontSize: "12",
                    titleFontSize: "14",
                    titleFontWeight: "bold",
                    labelFontWeight: "normal",
                    tickColor: "black",
                    //minimum: 0.00,
                    //maximum: 1500,
                    //interval: 200

                }],

            // dataPointMaxWidth: 20,

            data: [{
                //click: function (e) {

                //    viewDataPointGraph(e);
                //},

                lineThickness: 2,
                //markerType: "cross",
                //markerColor: "#FFFFFF",
                type: "area",
                name: "TC5_ACC",
                showInLegend: true,
                axisYIndex: 0,
                indexLabel: "{y}",
                indexLabelFontSize: 0,
                indexLabelPlacement: "top",
                indexLabel: "FLAGGED",
                axisYType: "primary",
                color: "#FFB533",
                dataPoints: accTC5List

            },
            {
                lineThickness: 2,
                //markerType: "cross",
                //markerColor: "#FFFFFF",
                type: "area",
                name: "TC6_ACC",
                showInLegend: true,
                axisYIndex: 0,
                indexLabel: "{y}",
                indexLabelFontSize: 0,
                indexLabelPlacement: "top",
                indexLabel: "FLAGGED",
                axisYType: "primary",
                color: "#FF3333",
                dataPoints: accTC6List

            },
            {
                lineThickness: 2,
                //markerType: "cross",
                //markerColor: "#FFFFFF",
                type: "area",
                name: "TC7_ACC",
                showInLegend: true,
                axisYIndex: 0,
                indexLabel: "{y}",
                indexLabelFontSize: 0,
                indexLabelPlacement: "top",
                indexLabel: "FLAGGED",
                axisYType: "primary",
                color: "#5D6D7E",
                dataPoints: accTC7List

            },
            {
                lineThickness: 2,
                //markerType: "cross",
                //markerColor: "#FFFFFF",
                type: "area",
                name: "TC8_ACC",
                showInLegend: true,
                axisYIndex: 0,
                indexLabel: "{y}",
                indexLabelFontSize: 0,
                indexLabelPlacement: "top",
                indexLabel: "FLAGGED",
                axisYType: "primary",
                color: "#1968B3",
                dataPoints: accTC8List

            },
            {
                lineThickness: 2,
                //markerType: "cross",
                //markerColor: "#FFFFFF",
                type: "area",
                name: "TC9_ACC",
                showInLegend: true,
                axisYIndex: 0,
                indexLabel: "{y}",
                indexLabelFontSize: 0,
                indexLabelPlacement: "top",
                indexLabel: "FLAGGED",
                axisYType: "primary",
                color: "#0E6655",
                dataPoints: accTC9List

            },
            {
                lineThickness: 2,
                //markerType: "cross",
                //markerColor: "#FFFFFF",
                type: "area",
                name: "TC10_ACC",
                showInLegend: true,
                axisYIndex: 0,
                indexLabel: "{y}",
                indexLabelFontSize: 0,
                indexLabelPlacement: "top",
                indexLabel: "FLAGGED",
                axisYType: "primary",
                color: "#C0392B",
                dataPoints: accTC10List
            },
            {
                lineThickness: 2,
                //markerType: "cross",
                //markerColor: "#FFFFFF",
                type: "area",
                name: "TC11_ACC",
                showInLegend: true,
                axisYIndex: 0,
                indexLabel: "{y}",
                indexLabelFontSize: 0,
                indexLabelPlacement: "top",
                indexLabel: "FLAGGED",
                axisYType: "primary",
                color: "#FF00B6",
                dataPoints: accTC11List

            },

            ]
        });

    chart4.render();

    function toggleDataSeries(e) {
        if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
            e.dataSeries.visible = false;
        }
        else {
            e.dataSeries.visible = true;
        }
        chart4.render();
    }

}
function acc2DVolumeGraph(GraphData, Kiln) {
    //debugger;
    var volList = [];

    if (GraphData.length > 0) {
        var Datalist = GraphData[0];
        document.getElementById("accVolDate" + Kiln).innerHTML = "";
        document.getElementById("accVolDate" + Kiln).innerHTML = Datalist.ENTRY_DATE;
        volList.push({
            label: "TC5",
            y: Datalist.TC5_ACC
        },
            {
                label: "TC6",
                y: Datalist.TC6_ACC
            },
            {
                label: "TC7",
                y: Datalist.TC7_ACC
            },
            {
                label: "TC8",
                y: Datalist.TC8_ACC
            },
            {
                label: "TC9",
                y: Datalist.TC9_ACC
            },
            {
                label: "TC10",
                y: Datalist.TC10_ACC
            },
            {
                label: "TC11",
                y: Datalist.TC11_ACC
            });
    }
    debugger;
    var chartarea;
    if (graphModal == 1)
        chartarea = "chartContainer";
    else
        chartarea = "accVolumeChart" + Kiln;;
    chart = new CanvasJS.Chart(chartarea,
        {
            zoomEnabled: true,
            animationEnabled: true,
            backgroundColor: "white",
            theme: "theme3",
            exportEnabled: false,
            zoomType: "x",
            interactivityEnabled: true,
            toolTip:
            {
                shared: true,

            },

            legend: {
                cursor: "pointer",
                verticalAlign: "top",
                horizontalAlign: "center",
                fontColor: "black",
                FontWeight: "bolder",
                FontSize: 15,
                itemMaxWidth: 1000,
                itemclick: toggleDataSeries
            },

            axisX:
            {
                gridThickness: 1,
                tickColor: "white",
                lineColor: "black",
                titleFontColor: "black",
                labelFontColor: "black",
                labelFontSize: "14",
                titleFontSize: "14",
                titleFontWeight: "bold",
                labelFontWeight: "normal",
                tickColor: "#ffffff",
                title: "TC",
                //interval:5

            },

            axisY: [

                {
                    gridThickness: 1,
                    tickColor: "white",
                    title: "ACCRETION VOLUME (%)",
                    lineColor: "black",
                    titleFontColor: "black",
                    labelFontColor: "black",
                    labelFontSize: "14",
                    titleFontSize: "14",
                    titleFontWeight: "bold",
                    labelFontWeight: "normal",
                    tickColor: "black",
                    //minimum: 0.00,
                    //maximum: 1500,
                    //interval: 200

                }],
            data: [{
                lineThickness: 2,
                type: "line",
                name: "ACC VOLUME",
                showInLegend: true,
                dataPoints: volList

            }]
        });

    chart.render();

    function toggleDataSeries(e) {
        if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
            e.dataSeries.visible = false;
        }
        else {
            e.dataSeries.visible = true;
        }
        chart.render();
    }

}
//=============================================================================================================================

function getTCWiseTrend(value, kiln) {
    //debugger;
    //$("#acc2DSelKiln"+kiln).change(function(){
    //    //debugger;
    //var acc2DSel = document.getElementById('acc2DSelKiln'+kiln).value;
    if (kiln != "") {
        acc2DProfileGraph(acc2DProfileData, kiln);
    }
    //})
}

function getReportData(KilnNo) {
    debugger;
    //if(KilnNo==1)
    // {
    var selectedValue = document.getElementById('idSelect').value;
    var fromDate = document.getElementById('FromDate').value;
    var toDate = document.getElementById('ToDate').value;
    //}
    //if(KilnNo==2)
    //{
    //    var selectedValue=document.getElementById('idSelect2').value;
    //    var fromDate = document.getElementById('FromDate2').value;
    //    var toDate = document.getElementById('ToDate2').value;
    //}
    //if(KilnNo==3)
    //{
    //    var selectedValue=document.getElementById('idSelect3').value;
    //    var fromDate = document.getElementById('FromDate3').value;
    //    var toDate = document.getElementById('ToDate3').value;
    //}

    $.ajax({
        type: "POST",
        url: "DRIService.asmx/getReportData",
        //data:"{'kiln':'" +kiln +"'}",
        data: "{ 'KILN':'" + KilnNo + "','FromDate':'" + fromDate + "','ToDate':'" + toDate + "','Selection':'" + selectedValue + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {
            // document.getElementById('acc2DProfileTitleKiln'+kiln).innerHTML="KILN-"+kiln+" ACCERATION 2D PROFILE FROM "+ acc2DDate;
            debugger;
            var table = document.getElementById('idProcessParameter');
            table.innerHTML = "";
            if (response.d == null || response.d[0] == "" || response.d.length == 0) {
               // alert("No data found");
            }
            if (response.d[0] != null && response.d[0] != "" && response.d.length != 0) {
                //  var  data = response.d;
                var data = JSON.parse(response.d[0]);

                var thead = document.createElement('thead');
                thead.className = "bg-black2 sticky-lg-top";
                var headerRow = document.createElement('tr');
                headerRow.className = "text-offwhite";
                var keys = Object.keys(data[0]);
                for (var i = 0; i < keys.length; i++) {
                    var headerCell = document.createElement('th');
                    headerCell.style.padding = '7px';
                    // headerCell.style.margin='10px';
                    //headerCell.style='width:1150px;overflow-y:auto;';
                    headerCell.textContent = keys[i];
                    headerRow.appendChild(headerCell);
                }
                thead.appendChild(headerRow);
                table.appendChild(thead);
                var tbody = document.createElement('tbody');
                for (var i = 0; i < data.length; i++) {
                    var obj = data[i];
                    var row = document.createElement('tr');

                    for (var j = 0; j < keys.length; j++) {
                        var value = String(obj[keys[j]]);
                        value = value.replace("T", " ")
                        var cell = document.createElement('td');

                        cell.style.textAlign = 'center';
                        cell.textContent = value
                        row.appendChild(cell);
                    }
                    tbody.appendChild(row);
                    //tbody.style="overflow-y:auto; height:400px; width:100%;position:absolute;background-color:white;";
                }
                table.appendChild(tbody);

            }

        },
        error: function (jqxhr) {
            debugger;
            alert(jqxhr.responseText);
        },
    });
}

//---------------------------------------------------------ManualModule---------------------------------------------//

function InsertAllHtmlManual(rowsmanual) {


    // var date = 'neeraj';

    $.ajax({
        type: "POST",
        url: "ManualDataService.asmx/InsertUpdateManualData",
        //data: "{'data':'" + rowsmanual + "'}",
        data: JSON.stringify({ data: rowsmanual }),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {

            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {
            debugger;
            if (response.d == null || response.d == "") {
                alert("Error in updating.");
            }
            else {
                alert("Data has been updated!");

            }

        }
    });





}

function InsertManualData(KilnNo) {
    debugger;
    var header = [];
    var rowsmanual = [];

    $("#tblManualData tr th").each(function (i, th) {
        header.push($(th).html());
    });

    $("#tblManualData tr:has(td)").each(function (i, tr) {
        var row = {};
        $(tr).find('td').each(function (j, td) {
            row[header[j]] = $(td).html();
        });
        rowsmanual.push(row);


    });
    InsertAllHtmlManual(rowsmanual);
}
























function getManualData(kilnNo)
{
    debugger;

    debugger;

    var Date = document.getElementById('DateManual').value;

    $.ajax({
        type: "POST",
        url: "ManualDataService.asmx/GetManualDataShift",

        data: "{ 'KILN':'" + kilnNo + "','Date':'" + Date + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {

            x = document.getElementById("loading-image");
            x.style.display = "none";
        },



        success: function (response) {
            if (response.d == null || response.d == "") {
                var tbody = $("#tblManualData > tbody");
                tbody[0].innerHTML = "";
                //alert("No Records found for selected dates");

            }
            else {
                debugger;
                var tableData = response.d;
                fillManual_Data(tableData);
            }
        }







    });
}
function fillManual_Data(response) {

    debugger;
    var tbody = $("#tblManualData > tbody");
    tbody[0].innerHTML = "";

    for (var i = 0; i < response.length; i++) {
        var obj = response[i];
        var row = "<tr><td>" + document.getElementById('DateManual').value + "</td><td>" + obj.ID_SEQ_MANUAL_DATA + "</td><td>" + obj.ID_KILN + "</td><td>" + obj.DESC_MANUAL_DATA + "</td><td>" + obj.MAX_VALUE + "</td><td>" + obj.MIN_VALUE + "</td><td contenteditable='true'>" + obj.ShiftA + "</td><td contenteditable='true' class=allownumeric>" + obj.ShiftB + "</td><td contenteditable='true'>" + obj.ShiftC + "</td><td>" + obj.UNIT + "</td></tr>";
        tbody.append(row);
        //tbody.style="overflow-y:auto; height:400px; width:100%;position:absolute;background-color:white;";
    }
}          

//---------------------------------------------------------ManualModule---------------------------------------------//
//-----------------------------------------------------------------ACTIONMODULE----------------------------------------------//
function fillddlDateTime(kiln)
{
    debugger;
    //alert(kiln);
    $.ajax({
        type: "POST",
        url: "ActionService.asmx/FillDDlEntryTime1",
        data: "{'KILN':'" + kiln + "'}",
        contentType: "application/json; charset=utf-8",
        async: false,
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {

            debugger;
            if (response.d == null || response.d == "") {
                $("#ddlEntryTime")[0].innerHTML = "";
                //alert("No dates fetched for Entry Time.");
            }
            else {
                debugger;
                var ddlData = response.d;
                $("#ddlEntryTime")[0].innerHTML = "";
                $.each(ddlData, function () {
                    $("#ddlEntryTime").append('<option value="' + this + '">' + this + '</option>');
                });
                // return true;
            }
        }
    });
}
function getLogTableData(KilnNo) {
    debugger;
    // alert(kilnNo);
    var fromDate = $("#FromDateLB")[0].value;
    var toDate = $("#ToDateLB")[0].value;
    var kiln = KilnNo;
    // alert(fromDate);
    $.ajax({
        type: "POST",
        url: "ActionService.asmx/fetchLogBookData",
        data: "{'fromDate':'" + fromDate + "','toDate':'" + toDate + "','KILN':'" + kiln + "'}",
        contentType: "application/json; charset=utf-8",
        async: false,
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {
            if (response.d == null || response.d == "") {
                var tbody = $("#tblLogBook > tbody");
                tbody[0].innerHTML = "";
                alert("No Records found for selected dates");

            }
            else {
                debugger;
                var tableData = response.d;
                filltableData_LogBook(tableData);
            }
        }
    });
}
function saveLogBookData(kilnNo) {

    debugger;


    var date = $("#ddlEntryTime :selected").val();
    var action = $("#txt_action")[0].value;
    var remarks = $("#txt_remarks")[0].value;
    //alert(kilnNo);
    $.ajax({
        type: "POST",
        url: "ActionService.asmx/insertLogData",
        data: "{'datetime':'" + date + "','action':'" + action + "','remarks':'" + remarks + "','kiln':'" + KilnNo + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {
            debugger;
            if (response.d == null || response.d == "") {
                alert("Error in updating.");
            }
            else {
                alert(response.d);
                $("#txt_action")[0].value = "";
                $("#txt_remarks")[0].value = "";
                //  $("#ddlParameters").val("select").change();
                getLogTableData(kilnNo);
            }

        }
    });
}
function filltableData_LogBook(data)
{

    debugger;
    var tbody = $("#tblLogBook > tbody");
    tbody[0].innerHTML = "";

    for (var i = 0; i < data.length; i++) {
        var obj = data[i];
        var row = "<tr><td>" + obj.Date + "</td><td>" + obj.FEM_PREDICTED + "</td><td>" + obj.FEM_ACTUAL + "</td><td>" + obj.ACTION_TAKEN + "</td><td>" + obj.REMARKS + "</td></tr>";
        tbody.append(row);
        //tbody.style="overflow-y:auto; height:400px; width:100%;position:absolute;background-color:white;";
    }
}

function filltableData_LogBook(data) {

    debugger;
    var tbody = $("#tblLogBook > tbody");
    tbody[0].innerHTML = "";

    for (var i = 0; i < data.length; i++) {
        var obj = data[i];
        var row = "<tr><td>" + obj.Date + "</td><td>" + obj.FEM_PREDICTED + "</td><td>" + obj.FEM_ACTUAL + "</td><td>" + obj.ACTION_TAKEN + "</td><td>" + obj.REMARKS + "</td></tr>";
        tbody.append(row);
        //tbody.style="overflow-y:auto; height:400px; width:100%;position:absolute;background-color:white;";
    }
}






//-----------------------------------------------------------------ACTIONMODULE----------------------------------------------//

//-----------------------------------------------------------------DCSMODULE----------------------------------------------//


function ChangeddlDataSource(KilnNo) {
    fillddlShowDataGroup(KilnNo);
    fillddlShowDataName(KilnNo);
}
function ChangeddlDataGroup(KilnNo) {
    fillddlShowDataName(KilnNo);


}






function fillddlShowDataSource(kilnNo) {
    // alert(kilnNo);
    //var Datagroup = $("#ddlDataGroup :selected").val();
    //  KILN = KilnNo;
    debugger;
    // alert(kiln);
    $.ajax({
        type: "POST",
        url: "DCSService.asmx/FillddlShowDataSource",
        data: "{'KILN':'" + kilnNo + "'}",
        contentType: "application/json; charset=utf-8",
        async: false,
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {

            debugger;
            if (response.d == null || response.d == "") {

                //alert("No dates fetched for Entry Time.");
            }
            else {
                debugger;

                var ddlData = response.d;
                $("#ddlDataSource")[0].innerHTML = "";
                $.each(ddlData, function () {
                    $("#ddlDataSource").append('<option value="' + this + '">' + this + '</option>');
                });
            }
        }
    });
}
function fillddlShowDataGroup(kiln) {
    debugger;
    var Datasource = $("#ddlDataSource :selected").val();

    // alert(kiln);
    $.ajax({
        type: "POST",
        url: "DCSService.asmx/FillddlShowDataGroup",
        data: "{'Datasource':'" + Datasource + "','KILN':'" + kiln + "'}",
        contentType: "application/json; charset=utf-8",
        async: false,
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {

            debugger;
            if (response.d == null || response.d == "") {

                //alert("No dates fetched for Entry Time.");
            }
            else {
                debugger;

                var ddlData = response.d;
                $("#ddlDataGroup")[0].innerHTML = "";
                $.each(ddlData, function () {
                    $("#ddlDataGroup").append('<option value="' + this + '">' + this + '</option>');
                });
            }
        }
    });
}

function fillddlShowDataName(kilnNo) {

    //alert(kilnNo);
    var Datagroup = $("#ddlDataGroup :selected").val();
    var Datasource = $("#ddlDataSource :selected").val();

    debugger;
    // alert(kiln);
    $.ajax({
        type: "POST",
        url: "DCSService.asmx/FillddlShowDataName",
        data: "{'Datagroup':'" + Datagroup + "',  'Datasource':'" + Datasource + "', 'KILN':'" + kilnNo + "'}",
        contentType: "application/json; charset=utf-8",
        async: false,
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {

            debugger;
            if (response.d == null || response.d == "") {

                //alert("No dates fetched for Entry Time.");
            }
            else {
                debugger;

                var ddlData = response.d;
                $("#ddlDataName")[0].innerHTML = "";
                $.each(ddlData, function () {
                    $("#ddlDataName").append('<option value="' + this + '">' + this + '</option>');
                });
            }
        }
    });
}




function PlotDcsGraph(KilnNo) {
    debugger;
    var fromDate = "";
    var toDate = "";

    var Dataname = $("#ddlDataName :selected").val();
    fromDate = document.getElementById("FromDateDcs").value;
    toDate = document.getElementById("ToDateDcs").value;;

    debugger;
    $.ajax({
        type: "POST",
        url: "DCSService.asmx/GetDCSGraphData",
        data: "{'KILN':'" + KilnNo + "','fromDate':'" + fromDate + "','toDate':'" + toDate + "','Dataname':'" + Dataname + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {
            debugger;
            var datadcs = response.d;
           // console.log(datadcs);
           
            drawGraphDcs(datadcs, KilnNo, Dataname);
            







        },
        error: function (jqxhr) {
            alert(jqxhr.responseText);
        },
    });

}




function drawGraphDcs(datadcs, KilnNo, Dataname) 
{


    var lstTAG_VALUE = [];
      



   
    debugger;

    for (var i = 0; i < datadcs.length; i++) 
    {
        var Datalist = datadcs[i];
        lstTAG_VALUE.push({
            label: Datalist.DATE_TIME,
            value: Datalist.TAG_VALUE,

        });
    }

 
    
    debugger;

    const jsonStringdata = JSON.stringify(lstTAG_VALUE);
    console.log(jsonStringdata);




    FusionCharts.ready(function () {

        var myChart = new FusionCharts({
            type: 'line',
           
            renderAt: 'chartContainerdcs',
            width: '100%',
            height: '590',
            dataFormat: 'json',
            dataSource: {
               
                chart: {
                    "theme": "fusion",
                    "caption": Dataname,
                    "subCaption": "DCS TAG vs DATE",
                    "xAxisName": "DATE",
                    "yAxisName": "TAG_VALUE",
                  /*  "numberPrefix": "$",*/
                    "lineThickness": "0.1",
                    "flatScrollBars": "1",
                    "scrollheight": "10",
                    "numVisiblePlot": "12",
                   
                    "labelFontColor": "0075c2",
                    "labelFontSize": "15",
                    "labelFontBold": "3",
                    "lableFontItalic": "3"
                  

                },
                "extensions": ["GoogleAnnot"],

               
               // data: [{ "label": "3/1/2024 6:33:01 PM", "value": "12420.2350" }, { "label": "3/1/2024 6:34:00 PM", "value": "12412.8650" }, { "label": "3/1/2024 6:35:00 PM", "value": "12408.16" }, { "label": "3/1/2024 6:36:00 PM", "value": "12399.30" }, { "label": "3/1/2024 6:37:00 PM", "value": "12415" }, { "label": "3/1/2024 6:38:00 PM", "value": "12414.5750" }, { "label": "3/1/2024 6:39:01 PM", "value": "12414.7850" }, { "label": "3/1/2024 6:40:00 PM", "value": "12417.03" }, { "label": "3/1/2024 6:41:00 PM", "value": "12409.8750" }, { "label": "3/1/2024 6:42:00 PM", "value": "12406.67" }]
                data:lstTAG_VALUE
                
            },

            

           
        });

     
        myChart.render();
    });


}
//function drawGraphDcs(datadcs, KilnNo, Dataname) {
//    var lstTAG_VALUE = [];

   

//    for (var i = 0; i < datadcs.length; i++) {
//        var Datalist = datadcs[i];
//        lstTAG_VALUE.push([Datalist.DATE_TIME]);
//    }

//    const series = [{ name: 'TAG_VALUE', data: lstTAG_VALUE }];
//    const options = {
//        title: {
//            text: Dataname,
//            align: 'center',
//            floating: true,
//            style: {
//                fontWeight: 'bold',
//                fontSize: '18px',
//                color: '#0075c2'
//            },
//            xaxis: {
//                type: 'datetime',
//                labels: {
//                    rotate: -45,
//                    style: {
//                        colors: "#0075c2",
//                        fontFamily: '"Roboto","Helvetica Neue", Helvetica, sans-serif',
//                        fontSize: "15px"
//                    }
//                },
//                tickAmount: 10,
//            },
//        },
//        stroke: {
//            curve: 'smooth'
//        },
//        grid: {
//            borderColor: '#eee',
//            row: {
//                colors: ['transparent'],
//                opacity: 0.5
//            }
//        },
//        xaxis: {
//            categories: lstTAG_VALUE
//        },
//        tooltip: {
//            intersect: false
//        },
//        labels: {
//            style: {
//                colors: "#0075c2",
//                fontFamily: '"Roboto","Helvetica Neue", Helvetica, sans-serif',
//                fontSize: "15px"
//            }
//        },
//        legend: {
//            show: false
//        },
//        chart: {
//            type: 'line'
//        }
//    };

//    var chart = new ApexCharts(document.querySelector("#chartContainerdcs"), options);
//   // chart.series.add(series[0]);
//    chart.render();
//}
    //-----------------------------------------------------------------DCSMODULE----------------------------------------------//



 //-----------------------------------------------------------------TCMODULE----------------------------------------------//


function PlotTcTable(KilnNo) {
    debugger;
    var fromDate = "";
    var toDate = "";
    var Date = "";

   // var Dataname = $("#ddlDataName :selected").val();
    Date = document.getElementById("ToDateTc").value; //simple date
   // toDate = document.getElementById("ToDateTC").value;;

    debugger;
    $.ajax({
        type: "POST",
        url: "TCService.asmx/GetTCTableData",
        data: "{'KILN':'" + KilnNo + "','Date':'" + Date + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {
            debugger;
            var datadTC = response.d;


            FillTableTC(datadTC, KilnNo, fromDate,toDate);








        },
        error: function (jqxhr) {
            alert(jqxhr.responseText);
        },
    });

}
function FillTableTC(datadTC, KilnNo, fromDate, toDate) {
    debugger;
   // Console.log(datadTC);
    let row = '';

    $('#tble_TcDetails_list').html('');

    if (datadTC != null && datadTC != undefined) {

        if (datadTC.length > 0) {
            row += `<thead>`;
            row += `<tr style="background-color: lightskyblue;">`;

            row += `<th rowspan='2'> THERMOCOUPLE NO: </th>`;
            for (var j = 0; j < datadTC.length; j++) {
                row += `<th colspan = '3'>${datadTC[j].DATA_TIME} </th>`;
            }
            row += `</tr>`;
            row += `<tr style="background-color: lightblue;">`;
            for (var j = 0; j < datadTC.length; j++) {
                row += `<th style = " font-size:16px;" >MAX</th>`;

                row += `<th style = " font-size:16px;" >MIN</th>`;

                row += `<th style = " font-size:16px;" >AVG</th>`;
            }
                    row += `</tr>`;
            row += `</thead>`;
            for (var j = 0; j < 11; j++) {
                           row += `<tr>`;

                row += `<td style="text-align:left; font-size:15px;">TC-${j+1}</td>`;

                for (var i = 0; i < datadTC.length; i++)
                {
                    if (datadTC[i].lstTCdata != null && datadTC[i].lstTCdata.length > j)
                    {
                      
                     
                        let tcminvalue = parseFloat(datadTC[i].lstTCdata[j].MINVALUE || '0');

                      
                        let tcmaxvalue = parseFloat(datadTC[i].lstTCdata[j].MAXVALUE || '0');
                        let tcAVGValue = parseFloat(datadTC[i].lstTCdata[j].AVGVALUE || '0'); // Ensure MINVALUE is converted to number type
                        
                        let min_Value = parseFloat(datadTC[i].lstTCdata[j].min_value || '0'); // Ensure MINVALUE is converted to number type
                        let max_Value = parseFloat(datadTC[i].lstTCdata[j].max_value || '0'); // Ensure MINVALUE is converted to number type

                        

                        if (tcmaxvalue > max_Value ) {



                            row += `<td style="background-color:red">${datadTC[i].lstTCdata[j].MAXVALUE != null ? datadTC[i].lstTCdata[j].MAXVALUE : '-'}</td>`;
                        }
                        if (tcmaxvalue < min_Value) {

                            row += `<td style="background-color:yellow">${datadTC[i].lstTCdata[j].MAXVALUE != null ? datadTC[i].lstTCdata[j].MAXVALUE : '-'}</td>`;
                        }

                        if (tcmaxvalue >= min_Value && tcmaxvalue <= max_Value) {

                            row += `<td>${datadTC[i].lstTCdata[j].MAXVALUE != null ? datadTC[i].lstTCdata[j].MAXVALUE : '-'}</td>`;
                        }

                        if (tcminvalue > max_Value) {



                            row += `<td style="background-color:red">${datadTC[i].lstTCdata[j].MINVALUE != null ? datadTC[i].lstTCdata[j].MINVALUE : '-'}</td>`;
                        }
                        if (tcminvalue < min_Value) {

                            row += `<td style="background-color:yellow">${datadTC[i].lstTCdata[j].MINVALUE != null ? datadTC[i].lstTCdata[j].MINVALUE : '-'}</td>`;
                        }

                        if (tcminvalue >= min_Value && tcminvalue <= max_Value) {

                            row += `<td>${datadTC[i].lstTCdata[j].MINVALUE != null ? datadTC[i].lstTCdata[j].MINVALUE : '-'}</td>`;
                        }


                        if (tcAVGValue > max_Value) {



                            row += `<td style="background-color:red">${datadTC[i].lstTCdata[j].AVGVALUE != null ? datadTC[i].lstTCdata[j].AVGVALUE : '-'}</td>`;
                        }
                        if (tcAVGValue < min_Value) {

                            row += `<td style="background-color:yellow">${datadTC[i].lstTCdata[j].AVGVALUE != null ? datadTC[i].lstTCdata[j].AVGVALUE : '-'}</td>`;
                        }

                        if (tcAVGValue >= min_Value && tcAVGValue <= max_Value)
                        {

                            row += `<td>${datadTC[i].lstTCdata[j].AVGVALUE != null ? datadTC[i].lstTCdata[j].AVGVALUE : '-'}</td>`;
                        }







                        //row += `<td>${datadTC[i].lstTCdata[j].MINVALUE != null ? datadTC[i].lstTCdata[j].MINVALUE : '-'}</td>`;

                        //row += `<td>${datadTC[i].lstTCdata[j].AVGVALUE != null ? datadTC[i].lstTCdata[j].AVGVALUE : '-'}</td>`;
                    }
                }
                row += `</tr>`;
            }
            
        }

        else {

            row += `<tr>`;

            row += `<td>No data to display </td>`;

            row += `</tr>`;

        }

    }

    else {

        $('#tble_TcDetails_list').html('No data to display..');

    }

    $('#tble_TcDetails_list').html(row);
}

    








 //-----------------------------------------------------------------TCMODULE----------------------------------------------//


function PlotEBookTable(KilnNo)
{
    debugger;
    var fromDate = "";
    var toDate = "";
   var Date = "";
 
    // var Dataname = $("#ddlDataName :selected").val();
   Date = document.getElementById("ToDateLog").value; //simple date

    console.log(Date);

    debugger;
    $.ajax({
        type: "POST",
        url: "LogBookService.asmx/GetLogbookTableData",
        data: "{'KILN':'" + KilnNo + "','Date':'" + Date + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {
            debugger;
            var dataeBook = response.d;


            FillEbook(dataeBook);








        },
        error: function (jqxhr) {
            alert(jqxhr.responseText);
        },
    });

}



//------------------------------------------------------------------------------------START MMEBOOK----------------------------------------------
function PlotMMEBookTable(KilnNo) {
    debugger;
    var fromDate = "";
    var toDate = "";
    var Date = "";

    // var Dataname = $("#ddlDataName :selected").val();
    Date = document.getElementById("ToDateMMLog").value; //simple date

    console.log(Date);

    debugger;
    $.ajax({
        type: "POST",
        url: "LogBookService.asmx/GetMMLogbookTableData",
        data: "{'KILN':'" + KilnNo + "','Date':'" + Date + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {
            debugger;
            var dataeBook = response.d;


            FillMMEbook(dataeBook);








        },
        error: function (jqxhr) {
            alert(jqxhr.responseText);
        },
    });

}
function FillMMEbook(dataeBook) {
    //    let row = '';
    debugger;
    console.log(dataeBook);


    
    if (dataeBook.length > 0) {


        const tbody = document.getElementById("tblbodyeMMlogbook");
        tbody.innerHTML = "";
        debugger;
        dataeBook.forEach((item, index) => {





            const rowspan = item.lstDataGroup.reduce((acc, curr) => acc + curr.lstDataName.length, 0);

            item.lstDataGroup.forEach((group, groupIndex) => {

                group.lstDataName.forEach((name, nameIndex) => {


                    const row = document.createElement('tr');
                    if (groupIndex == 0 && nameIndex === 0) {

                        const datasourcecell = document.createElement('td');

                        datasourcecell.textContent = item.DATA_SOURCE;
                        datasourcecell.setAttribute('rowspan', rowspan);
                        // datsourcecell.setAttribute('color','green')

                        datasourcecell.style.textAlign = "center";

                        if (index % 2 === 0) {

                            datasourcecell.setAttribute("style", "background-color: #ffe6e6;width:30px;");
                        }

                        else {

                            datasourcecell.setAttribute("style", "background-color: #f2d9f2;width:30px;");
                        }
                        datasourcecell.classList.add('larger-font');
                        datasourcecell.style.verticalAlign = "middle";
                        row.appendChild(datasourcecell);


                    }

                    if (nameIndex === 0) {

                        const groupcell = document.createElement('td');

                        groupcell.textContent = group.DATA_GROUP.replace(/_/g, ' ');
                        groupcell.setAttribute('rowspan', group.lstDataName.length);
                        groupcell.setAttribute("style", "width:30px;");
                        groupcell.style.verticalAlign = "middle";

                        groupcell.classList.add('larger-font');
                        row.appendChild(groupcell);

                    }

                    const namecell = document.createElement('td');
                    const shifAcell = document.createElement('td');
                    const shifBcell = document.createElement('td');
                    const shifCcell = document.createElement('td');
                    const ondatecell = document.createElement('td');
                    const todatecell = document.createElement('td');
                    namecell.textContent = name.DATA_NAME;
                    namecell.setAttribute("style", "width:30px;");
                    shifAcell.textContent = name.SHIFT_A;
                    shifBcell.textContent = name.SHIFT_B;
                    shifCcell.textContent = name.SHIFT_C;
                    ondatecell.textContent = name.ON_DATE;
                    todatecell.textContent = name.TO_DATE
                    row.appendChild(namecell);
                    row.appendChild(shifAcell);
                    row.appendChild(shifBcell);
                    row.appendChild(shifCcell);
                    row.appendChild(ondatecell);
                    row.appendChild(todatecell);
                    tbody.appendChild(row);


                });



            });
        });





    }











}

//----------------------------------------------------------------END MMEBOOK-------------------------------------------------
//-----------------------------------------------------START-----QUALITY LOGBOOK-----------------------------------------------------------------------------------------------------------------------------------------------------------------
function PlotQualityEBookTable(KilnNo) {
    debugger;
   
    var Date = "";

    
    Date = document.getElementById("DateLogQuality").value; //simple date

    console.log(Date);

    debugger;
    $.ajax({
        type: "POST",
        url: "LogBookService.asmx/GetQualityTableData",
        data: "{'KILN':'" + KilnNo + "','Date':'" + Date + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
           
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {
            debugger;
            var dataeBook = response.d;


            FillQualityEbook(dataeBook);








        },
        error: function (jqxhr) {
            alert(jqxhr.responseText);
        },
    });

}
function FillQualityEbook(dataeBook) {

    debugger;
    console.log(dataeBook);



    if (dataeBook.length > 0) {




        var tableBody = document.getElementById('tblbodyQualityelogbook');
        tableBody.innerHTML = "";
        dataeBook.forEach(function (item, i) {
            item.lstDataGroup.forEach(function (listItem, index) {
                var row = document.createElement('tr');

                // Only add the material cell for the first item in the list
                if (index === 0) {
                    var MaterialCell = document.createElement('td');
                    MaterialCell.textContent = item.TABLE_NAME;

                    MaterialCell.rowSpan = item.lstDataGroup.length;  // Set the rowspan attribute
                    MaterialCell.style.backgroundColor = i % 2 !== 0 ? "lightblue" : "lightgreen";
                    row.appendChild(MaterialCell);
                }

                var MaterialDescCell = document.createElement('td');
                var SHIFTACell = document.createElement('td');
                var SHIFTBCell = document.createElement('td');
                var SHIFTCCell = document.createElement('td');
                var ONdateCell = document.createElement('td');
                var TodateCell = document.createElement('td');
                MaterialDescCell.textContent = listItem.DESC_LAB_DATA;
                SHIFTACell.textContent = listItem.SHIFTA;
                SHIFTBCell.textContent = listItem.SHIFTB;
                SHIFTCCell.textContent = listItem.SHIFTC;
                 ONdateCell.textContent = listItem.ON_DATE;
                 TodateCell.textContent = listItem.TO_DATE;  
                row.appendChild(MaterialDescCell);
                row.appendChild(SHIFTACell);
                row.appendChild(SHIFTBCell);
                row.appendChild(SHIFTCCell);
                row.appendChild(ONdateCell);
                row.appendChild(TodateCell);
                tableBody.appendChild(row);
            });
        });
    }







}
//-------------------------------------------------------------------------------------------END QUALITY LOGBOOK----------------------------------------------------------------------------------------------------------------------
function FillEbook(dataeBook)
     {
    //    let row = '';
    debugger;
    console.log(dataeBook);


   

    if (dataeBook.length > 0) {
      

        const tbody = document.getElementById("tblbodyelogbook");
        tbody.innerHTML = "";
        debugger;
        dataeBook.forEach((item, index) => {

          



            const rowspan = item.lstDataGroup.reduce((acc, curr) => acc + curr.lstDataName.length, 0);

            item.lstDataGroup.forEach((group, groupIndex) => {

                group.lstDataName.forEach((name, nameIndex) => {


                    const row = document.createElement('tr');
                    if (groupIndex == 0 && nameIndex === 0) {

                        const datasourcecell = document.createElement('td');

                        datasourcecell.textContent = item.DATA_SOURCE;
                        datasourcecell.setAttribute('rowspan', rowspan);
                       // datsourcecell.setAttribute('color','green')
                      
                        datasourcecell.style.textAlign = "center";
                        
                        if (index % 2 === 0)
                        {
                           
                            datasourcecell.setAttribute("style", "background-color: #ffe6e6;width:30px;");
                        }

                        else
                        {
                          
                            datasourcecell.setAttribute("style", "background-color: #f2d9f2;width:30px;");
                        }
                        datasourcecell.classList.add('larger-font');
                        datasourcecell.style.verticalAlign = "middle";
                        row.appendChild(datasourcecell);


                    }

                    if (nameIndex === 0) {

                        const groupcell = document.createElement('td');
                      
                        groupcell.textContent = group.DATA_GROUP.replace(/_/g, ' ');
                        groupcell.setAttribute('rowspan', group.lstDataName.length);
                        groupcell.setAttribute("style", "width:30px;");
                        groupcell.style.verticalAlign = "middle";

                        groupcell.classList.add('larger-font');
                        row.appendChild(groupcell);
                       
                    }

                    const namecell = document.createElement('td');
                    const shifAcell = document.createElement('td');
                    const shifBcell = document.createElement('td');
                    const shifCcell = document.createElement('td');
                    const ondatecell = document.createElement('td');
                    const todatecell = document.createElement('td');
                    namecell.textContent = name.DATA_NAME;
                    namecell.setAttribute("style", "width:30px;");
                    shifAcell.textContent = name.SHIFT_A;
                    shifBcell.textContent = name.SHIFT_B;
                    shifCcell.textContent = name.SHIFT_C;
                    ondatecell.textContent = name.ON_DATE;
                    todatecell.textContent=name.TO_DATE
                    row.appendChild(namecell);
                    row.appendChild(shifAcell);
                    row.appendChild(shifBcell);
                    row.appendChild(shifCcell);
                    row.appendChild(ondatecell);
                    row.appendChild(todatecell);
                    tbody.appendChild(row);


                });



            });
        });




            
       }







        



    }
//--------------------------------------------------------------START IEMEBOOK-----------------------------------------------------
function PlotIEMEBookTable(KilnNo) {
    debugger;
    var fromDate = "";
    var toDate = "";
    var Date = "";

    // var Dataname = $("#ddlDataName :selected").val();
    Date = document.getElementById("ToDateIEMLog").value; //simple date

    console.log(Date);

    debugger;
    $.ajax({
        type: "POST",
        url: "LogBookService.asmx/GetLogbookIEMTableData",
        data: "{'KILN':'" + KilnNo + "','Date':'" + Date + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {
            debugger;
            var dataeBook = response.d;


            FillIEMEbook(dataeBook);








        },
        error: function (jqxhr) {
            alert(jqxhr.responseText);
        },
    });

}
function FillIEMEbook(dataeBook) {
    //    let row = '';
    debugger;
    console.log(dataeBook);


   

    if (dataeBook.length > 0) {


        const tbody = document.getElementById("tblbodyIEMelogbook");
        tbody.innerHTML = "";
        debugger;
        dataeBook.forEach((item, index) => {





            const rowspan = item.lstDataGroup.reduce((acc, curr) => acc + curr.lstDataName.length, 0);

            item.lstDataGroup.forEach((group, groupIndex) => {

                group.lstDataName.forEach((name, nameIndex) => {


                    const row = document.createElement('tr');
                    if (groupIndex == 0 && nameIndex === 0) {

                        const datasourcecell = document.createElement('td');

                        datasourcecell.textContent = item.DATA_SOURCE;
                        datasourcecell.setAttribute('rowspan', rowspan);
                        // datsourcecell.setAttribute('color','green')

                        datasourcecell.style.textAlign = "center";

                        if (index % 2 === 0) {

                            datasourcecell.setAttribute("style", "background-color: #ffe6e6;width:30px;");
                        }

                        else {

                            datasourcecell.setAttribute("style", "background-color: #f2d9f2;width:30px;");
                        }
                        datasourcecell.classList.add('larger-font');
                        datasourcecell.style.verticalAlign = "middle";
                        row.appendChild(datasourcecell);


                    }

                    if (nameIndex === 0) {

                        const groupcell = document.createElement('td');
                        groupcell.textContent = group.DATA_GROUP.replace(/_/g, ' ');
                       // groupcell.textContent = group.DATA_GROUP;
                        groupcell.setAttribute('rowspan', group.lstDataName.length);
                        groupcell.setAttribute("style", "width:30px;");
                        groupcell.style.verticalAlign = "middle";

                        groupcell.classList.add('larger-font');
                        row.appendChild(groupcell);

                    }

                    const namecell = document.createElement('td');
                    const shifAcell = document.createElement('td');
                    const shifBcell = document.createElement('td');
                    const shifCcell = document.createElement('td');
                    const ondatecell = document.createElement('td');
                    const todatecell = document.createElement('td');
                    namecell.textContent = name.DATA_NAME;
                    namecell.setAttribute("style", "width:30px;");
                    shifAcell.textContent = name.SHIFT_A;
                    shifBcell.textContent = name.SHIFT_B;
                    shifCcell.textContent = name.SHIFT_C;
                    ondatecell.textContent = name.ON_DATE;
                    todatecell.textContent = name.TO_DATE
                    row.appendChild(namecell);
                    row.appendChild(shifAcell);
                    row.appendChild(shifBcell);
                    row.appendChild(shifCcell);
                    row.appendChild(ondatecell);
                    row.appendChild(todatecell);
                    tbody.appendChild(row);


                });



            });
        });





    }











}
//-------------------------------------------------------------------------END IEMEBOOK
















    
//----------------------------------------------------START LMONITORING--------------------------------

function PlotLMonitoringTable(KilnNo)
{
   // alert("hi");
    debugger;
  
    var Date = "2024-04-14";

   



    debugger;
    $.ajax({
        type: "POST",
        url: "LogBookService.asmx/GetLMonitoringTableData",
        data: "{'KILN':'" + KilnNo + "','Date':'" + Date + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {
            debugger;
            var dataLMonitoring = response.d;


            FillLMonitoringTableData(dataLMonitoring);








        },
        error: function (jqxhr) {
            alert(jqxhr.responseText);
        },
    });

}



function FillLMonitoringTableData(dataLMonitoring) {
    //    let row = '';
    debugger;
    console.log(dataLMonitoring);
   

    

    if (dataLMonitoring.length > 0) {

        document.getElementById("datemax").innerHTML = "UPDATED TIME" + " " + dataLMonitoring[0].lstDataGroup[0].lstDataName[0].DATA_TIME + " " + "KILN" + " " +  + KilnNo +"";
        const tbody = document.getElementById("tblbodyLMonitor");
        tbody.innerHTML = "";

        const tbodydeviation = document.getElementById("tblbodyLMonitorDeviation");
        tbodydeviation.innerHTML = "";
        //debugger;
        dataLMonitoring.forEach((item, index) => {





            const rowspan = item.lstDataGroup.reduce((acc, curr) => acc + curr.lstDataName.length, 0);

            item.lstDataGroup.forEach((group, groupIndex) => {

                group.lstDataName.forEach((name, nameIndex) => {


                    const row = document.createElement('tr');
                    
                    if (groupIndex == 0 && nameIndex === 0) {

                        const datasourcecell = document.createElement('td');

                        datasourcecell.textContent = item.DATA_SOURCE;
                        datasourcecell.setAttribute('rowspan', rowspan);
                        // datsourcecell.setAttribute('color','green')

                        datasourcecell.style.textAlign = "center";

                        if (index % 2 === 0) {

                            datasourcecell.setAttribute("style", "background-color: #ffe6e6;width:30px;");
                        }

                        else {

                            datasourcecell.setAttribute("style", "background-color: #f2d9f2;width:30px;");
                        }
                        datasourcecell.classList.add('larger-font');
                        datasourcecell.style.verticalAlign = "middle";
                        row.appendChild(datasourcecell);


                    }

                    if (nameIndex === 0) {

                        const groupcell = document.createElement('td');
                       
                        groupcell.textContent = group.DATA_GROUP.replace(/_/g, ' ');
                        groupcell.setAttribute('rowspan', group.lstDataName.length);
                        groupcell.setAttribute("style", "width:30px;");
                        groupcell.style.verticalAlign = "middle";

                        groupcell.classList.add('larger-font');
                        row.appendChild(groupcell);

                    }
                    //if (+tagvaluecell.textContent < +minvaluecell.textContent)
                    //{
                    //    const rowdeviation = document.createElement('tr');
                    //}
                    const namecell = document.createElement('td');
                    const tagvaluecell = document.createElement('td');
                    const minvaluecell = document.createElement('td');
                    const maxvaluecell = document.createElement('td');

                    const deviationParametercell = document.createElement('td');
                    const deviationtagvaluecell = document.createElement('td');
                    //const statuscell = document.createElement('td');

                    // Determine the color of the statuscell based on the tagvalue
                    
                    namecell.textContent = name.DATA_NAME;
                    const roundedValue = Math.round(parseFloat(name.TAG_VALUE) * 100) / 100;
                    tagvaluecell.textContent = roundedValue;
                    minvaluecell.textContent = name.MIN_VALUE,
                    maxvaluecell.textContent = name.MAX_VALUE;

                    let bgColor = "";
                    if (+tagvaluecell.textContent < +minvaluecell.textContent && +tagvaluecell.textContent!=0) {
                      
                        const rowdeviation = document.createElement('tr');
                        bgColor = "yellow";
                       // statuscell.textContent = "LOW";
                       // statuscell.style.backgroundColor = bgColor;
                        //tagvaluecell.style.backgroundColor = bgColor;
                        tagvaluecell.setAttribute("style", "background-color: " + bgColor + ";width:30px");
                        //const rowdeviation = document.createElement('tr');
                        deviationParametercell.textContent = name.DATA_NAME;
                        deviationtagvaluecell.textContent = roundedValue;
                        deviationtagvaluecell.setAttribute("style", "background-color: " + bgColor + ";width:30px;");
                        rowdeviation.appendChild(deviationParametercell);
                        rowdeviation.appendChild(deviationtagvaluecell);
                        tbodydeviation.appendChild(rowdeviation);
                        //applyDynamicSortingForTBodyDeviation(tbodydeviation);
                    }
                    if (+tagvaluecell.textContent > +maxvaluecell.textContent)
                    {
                        const rowdeviation = document.createElement('tr');
                        bgColor = "Red";
                        //statuscell.textContent = "HIGH";
                        //statuscell.style.backgroundColor = bgColor;
                       // tagvaluecell.style.backgroundColor = bgColor;
                        tagvaluecell.setAttribute("style", "background-color: " + bgColor + ";width:30px;");
                        deviationParametercell.textContent = name.DATA_NAME;
                        deviationtagvaluecell.textContent = roundedValue;
                        deviationtagvaluecell.setAttribute("style", "background-color: " + bgColor + ";width:30px;");
                        rowdeviation.appendChild(deviationParametercell);
                        rowdeviation.appendChild(deviationtagvaluecell);
                        tbodydeviation.appendChild(rowdeviation);
                        //applyDynamicSortingForTBodyDeviation(tbodydeviation);
                    }
                    //else {
                    //    // Optional: Add other colors for when the tagvalue is between minvalue and maxvalue
                    //    bgColor = "white";
                    //    //statuscell.textContent = "NORMAL";
                    //    //statuscell.style.backgroundColor = bgColor;
                    //    //tagvaluecell.style.backgroundColor = bgColor;
                    //    tagvaluecell.setAttribute("style", "background-color: " + bgColor + ";width:20px;");
                    //}
                    minvaluecell.setAttribute("style", "width:20px;");
                    maxvaluecell.setAttribute("style", "width:20px;");
                    namecell.setAttribute("style", "width:20px;");
                    row.appendChild(namecell);
                    row.appendChild(tagvaluecell);
                    row.appendChild(minvaluecell);
                    row.appendChild(maxvaluecell);
                    
                    tbody.appendChild(row);
                    
                   
                });



            });
        });





    }



   







}




function applyDynamicSortingForTBodyDeviation(tableElement) {
    const tableRows = Array.from(tableElement.querySelectorAll('tr')).filter(x => x.id !== "");
    const sortedRows = tableRows.sort((a, b) => getComputedStyle(a).backgroundColor.localeCompare(getComputedStyle(b).backgroundColor));
    const fragment = document.createDocumentFragment();
    sortedRows.forEach(r => fragment.appendChild(r));
    tableElement.innerHTML = "";
    tableElement.appendChild(fragment);
}

//----------------------------------------END LMONITORING-----------------------------------
//const datatable = document.getElementById('tbllmonitor');
//const dataNameInput = document.getElementById("dataNameSearch");
//dataNameInput.addEventListener("input", () => {
//    const searchValue = dataNameInput.value.toLowerCase();
//    for (var i = 1; i < datatable.rows.length; i++) {

//        var row = datatable.rows[i];
//        var name = row.cells[0].textContent.toLowerCase();

//        if (name.includes(searchValue)) {

//            row.style.display = '';
//        }
//        else {

//            row.style.display = 'none';
//        }
//    }
//});
//   // alert("hi");
   
//  /*  Array.from(document.querySelectorAll("#tblbodyLMonitor tr")).forEach((row) => {*/
//        //const nameCells = row.getElementsByTagName("td")[2]; // Change the number according to the position of the Data Name column
//        //const nameText = nameCells ? nameCells.textContent.trim() : null;
//        //row.style.display = nameText?.toLowerCase().includes(searchValue) ? '' : 'none';


//        const nameCells = row.cell[2].textContent.toLowerCase();
//       // if(nameCells)
//        // Use the determined column index
//        row.style.display = nameCells && nameCells.textContent.toLowerCase().includes(searchValue) ? '' : 'none';
//    });
//});


//-----------------------------------------------------START LCONFIGURATION-----------------------
   function PlotLConfigurationTable(KilnNo)
    {
    //alert("hi");
    debugger;
    var fromDate = "";
    var toDate = "";
    var Date = "2024-04-14";

    



    debugger;
    $.ajax({
        type: "POST",
        url: "LogBookService.asmx/GetLConfigurationTableData",
        data: "{'KILN':'" + KilnNo + "','Date':'" + Date + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {
            debugger;
            var dataLConfiguration = response.d;


            FillLConfigurationTableData(dataLConfiguration);








        },
        error: function (jqxhr) {
            alert(jqxhr.responseText);
        },
    });

}

function FillLConfigurationTableData(dataLConfiguration) {
    //    let row = '';
    debugger;
    console.log(dataLConfiguration);




    if (dataLConfiguration.length > 0) {

        //document.getElementById("datemax").innerHTML = "DATE_TIME" + " " + dataLMonitoring[0].lstDataGroup[0].lstDataName[0].DATA_TIME;
        const tbody = document.getElementById("tblbodyLConfigurationData");
        tbody.innerHTML = "";
        debugger;
        dataLConfiguration.forEach((item, index) => {





            const rowspan = item.lstDataGroup.reduce((acc, curr) => acc + curr.lstDataName.length, 0);

            item.lstDataGroup.forEach((group, groupIndex) => {

                group.lstDataName.forEach((name, nameIndex) => {


                    const row = document.createElement('tr');
                    if (groupIndex == 0 && nameIndex === 0) {

                        const datasourcecell = document.createElement('td');

                        datasourcecell.textContent = item.DATA_SOURCE;
                        datasourcecell.setAttribute('rowspan', rowspan);
                        // datsourcecell.setAttribute('color','green')
                        datasourcecell.setAttribute("contenteditable", false);
                        datasourcecell.style.textAlign = "center";

                        if (index % 2 === 0) {

                            datasourcecell.setAttribute("style", "background-color: #ffe6e6;width:30px;");
                        }

                        else {

                            datasourcecell.setAttribute("style", "background-color: #f2d9f2;width:30px;");
                        }
                        datasourcecell.classList.add('larger-font');
                        datasourcecell.style.verticalAlign = "middle";
                        row.appendChild(datasourcecell);


                    }

                    if (nameIndex === 0) {

                        const groupcell = document.createElement('td');

                        groupcell.textContent = group.DATA_GROUP.replace(/_/g, ' ');
                        groupcell.setAttribute('rowspan', group.lstDataName.length);
                        groupcell.setAttribute("style", "width:30px;");
                        groupcell.style.verticalAlign = "middle";
                        groupcell.setAttribute("contenteditable", false);
                        groupcell.classList.add('larger-font');
                        row.appendChild(groupcell);

                    }

                    const namecell = document.createElement('td');
                    const minvaluecell = document.createElement('td');
                    const maxvaluecell = document.createElement('td');
                    const updatecell = document.createElement('td');
                    namecell.textContent = name.DATA_NAME;
                    namecell.setAttribute("style", "width:30px;");
                    minvaluecell.textContent = name.MIN_VALUE;
                    maxvaluecell.textContent = name.MAX_VALUE;
                    minvaluecell.setAttribute("contenteditable", true);
                    maxvaluecell.setAttribute("contenteditable", true);
                    namecell.setAttribute("contenteditable", false);
                  // minvaluecell.setAttribute("i")
                    const updateButton = document.createElement('button');
                    updateButton.type = 'button';
                    updateButton.classList.add('btn', 'btn-primary', 'updateBtn');
                    updateButton.textContent = 'Update';

                    updateButton.addEventListener('click', () =>
                    {
                       // const newdatasourceValue =datasourcecell.innerText;
                        const newdatanameValue = namecell.innerText;
                        //const newgroupValue = groupcell.innerText;
                        //const newMaxValue = parseFloat(maxvaluecell.innerText);
                        const newMinValue = parseFloat(minvaluecell.innerText);
                        const newMaxValue = parseFloat(maxvaluecell.innerText);

                        if (isNaN(newMinValue) || isNaN(newMaxValue)) {
                            alert('Invalid value entered.');
                            return;
                        }

                        if (newMinValue >= newMaxValue) {
                            alert('Minimum value should be less than maximum value.');
                            return;
                        }

                        UpdateConfiguration(newdatanameValue, newMinValue, newMaxValue);

                       //s
                    });









                    updatecell.appendChild(updateButton);
                
                  
                    row.appendChild(namecell);
                    row.appendChild(minvaluecell);
                    row.appendChild(maxvaluecell);
                    row.appendChild(updatecell);

                    tbody.appendChild(row);


                });



            });
        });





    }











}
//---------------------------------------------------END LCONFIGURATION
document.getElementById("mySelectlossbooktype").addEventListener("change", function ()
{
    var selectedValue = this.value; // get the selected value
    //console.log(selectedValue); // log the selected value to the console
    GetFeedTableData(KilnNo, selectedValue);
}
);



document.getElementById("Locselection").addEventListener("change", function ()
{
    var selectedValueLoc = this.value; // get the selected value
    // KilnNo = "6"
    //alert("hi");
    GetLossEQuipment(selectedValueLoc);
});








function GetLossEQuipment(selectedValueLoc)
{




    $("#Equipselection").empty();

    
   // const selectedValueLoc = $("#Locselection");
   // selectedValueLoc = selectedValueLoc.val;
    $.ajax({
        type: "POST",
        url: "LogBookService.asmx/GetLossEQuipment",
        data: "{'selectedValueLoc':'" + selectedValueLoc + "'}",
        contentType: "application/json; charset=utf-8",
        async: false,
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {
            if (response.d == null || response.d == "") {
                //var tbody = $("#tblFeedBook> tbody");
                //tbody[0].innerHTML = "";
               // alert("No Records found for selected location");

            }
            else {


                console.log(response);
                var ddlData = response.d;
              
                debugger;
                const optionElement = document.createElement("option");
                $.each(ddlData, function () {
                    $("#Equipselection").append('<option value="' + this.PARAM_ID + '">' + this.PARAM_NAME + '</option>');
                });
                Equipselection.appendChild(optionElement);

               
                //$("#ddlEntryTime")[0].innerHTML = "";
                //$.each(ddlData, function () {
                //    $("#ddlEntryTime").append('<option value="' + this + '">' + this + '</option>');
                //});
               

            }
        }
    });



}


function  GetParamConfigDropDownloss()
{


   // Equipselection = document.getElementById('Equipselection');
    Deptselection = document.getElementById('Deptselection');
    Delayselection = document.getElementById('myreasonselect');
    Locselection = document.getElementById('Locselection');
    Locselection.innerHTML = "";
    Deptselection.innerHTML = "";
    Delayselection.innerHTML = "";
    
        $.ajax({
            type: "POST",
            url: "DRIService.asmx/GetParamConfigDropDown",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                if (response && response.hasOwnProperty("d"))
                {
                    response.d.forEach(item => {
                        if (item.PARAM_DESC === "DEPARTMENT") {
                            const optionElement = document.createElement("option");
                            optionElement.value = item.PARAM_NAME;
                            optionElement.textContent = item.PARAM_NAME;

                            // Append the created option element to the select element
                            Deptselection.appendChild(optionElement);
                        }

                        //if (item.PARAM_DESC === "EQUIPMENT") {
                        //    const optionElement = document.createElement("option");
                        //    optionElement.value = item.PARAM_NAME;
                        //    optionElement.textContent = item.PARAM_NAME;

                        //    // Append the created option element to the select element
                        //    Equipselection.appendChild(optionElement);
                        //}

                        if (item.PARAM_DESC === "DELAY REASON") {
                            const optionElement = document.createElement("option");
                            optionElement.value = item.PARAM_NAME;
                            optionElement.textContent = item.PARAM_NAME;

                            // Append the created option element to the select element
                            Delayselection.appendChild(optionElement);
                        }

                        if (item.PARAM_DESC === "LOCATION") {
                            const optionElement = document.createElement("option");
                            optionElement.value = item.PARAM_ID;//locid
                            optionElement.textContent = item.PARAM_NAME;

                            // Append the created option element to the select element
                            Locselection.appendChild(optionElement);

                        }

                        if (item.PARAM_DESC === "SHIFT") {
                            const optionElement = document.createElement("option");
                            optionElement.value = item.PARAM_NAME;
                            optionElement.textContent = item.PARAM_NAME;

                            // Append the created option element to the select element
                            Shiftselection.appendChild(optionElement);
                        }
                    });
                }
                else
                {

                   
                }
            },
            error: function (jqxhr)
            {
               // reject(new Error(jqxhr.responseText));
            }
        });

}

function Submitfeedbook(KilnNo)
{
    debugger;
    lossselectiontype = document.getElementById('mySelectlossbooktype');
    Equipselection = document.getElementById('Equipselection');
    Deptselection = document.getElementById('Deptselection');
    Delayselection = document.getElementById('myreasonselect');
    if (Delayselection.value == "OTHER")
    {

        reason = document.getElementById('other-text').value + " " +"(OTHER)";
        //alert(reason);
    }
    else
    {

        reason = Delayselection.value;

    }

    // alert(selectiontype.value);
    fromDate = document.getElementById('FromDateFeed').value;
    toDate = document.getElementById('ToDateFeed').value;
    duration = document.getElementById('txt_feedduration').value;
   // equipment = document.getElementById('txt_feedequipment').value;
    //eparment = document.getElementById('txt_feeddept').value;
    //reason = document.getElementById('txt_feedreason').value;
    //alert("hi");

    debugger;
    $.ajax({
        type: "POST",
        url: "LogBookService.asmx/SubmitFeedBook",
        data: "{'KILN':'" + KilnNo + "','FromDate':'" + fromDate + "','ToDate':'" + toDate + "','Duration':'" + duration + "','EQUIPMENT':'" + Equipselection.value + "','DEPARTMENT':'" + Deptselection.value + "','REASON':'" + reason + "' ,'TYPE':'" + lossselectiontype.value +"'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response)
        {
            debugger;

            console.log(response);
            alert(response.d);
           
            GetFeedTableData(KilnNo, lossselectiontype.value);

          








        },
        error: function (jqxhr) {
            alert(jqxhr.responseText);
        },
    });

}



function GetFeedTableData(KilnNo,Type)
{
    debugger;
   
    var fromDate = $("#FromDateLB")[0].value;
    var toDate = $("#ToDateLB")[0].value;
    var kiln = KilnNo;
 
    $.ajax({
        type: "POST",
        url: "LogBookService.asmx/GetFeedTableData",
        data: "{'fromDate':'" + fromDate + "','toDate':'" + toDate + "','KILN':'" + kiln + "','TYPE':'" + Type + "'}",
        contentType: "application/json; charset=utf-8",
        async: false,
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response)
        {
            if (response.d == null || response.d == "")
            {
                var tbody = $("#tblFeedBook> tbody");
                tbody[0].innerHTML = "";
                alert("No Records found for selected dates");

            }
            else
            {
                debugger;
                var tableData = response.d;
                filltableData_feedBook(tableData);

            }
        }
    });
}
function filltableData_feedBook(data)
{
    console.log(data);
    debugger;
    var tbody = $("#tblFeedBook > tbody");
    tbody[0].innerHTML = "";

    for (var i = 0; i < data.length; i++) {
        var obj = data[i];
        var row = "<tr><td>" + obj.frmdate + "</td><td>" + obj.todate + "</td><td>" + obj.DURATION + "</td><td>" + obj.DEPARTMENT + "</td><td>" + obj.EQUIPMENT + "</td><td>" + obj.REASON + "</td></tr>";
        tbody.append(row);
       
    }
}
function UpdateConfiguration(newdatanameValue,newMinValue, newMaxValue)
{
    //alert(newdatasourceValue);

    debugger;
    $.ajax({
        type: "POST",
        url: "LogBookService.asmx/UpdateLConfigurationTableData",
        data: "{'KILN':'" + KilnNo + "','DataName':'" + newdatanameValue + "','Min':'" + newMinValue + "','Max':'" + newMaxValue + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {
            debugger;

            console.log(response);
            alert(response.d);


           // FillLConfigurationTableData(dataLConfiguration);








        },
        error: function (jqxhr) {
            alert(jqxhr.responseText);
        },
    });











}


function Validateuser()
{
   
    document.getElementById("myPopup").style.display = "block";
    
}

function GetAllThermalKilnGraph()
{
   
    dropdowntheramalkiln1 = document.getElementById('ddlEntryTimeThermal1');
    dropdowntheramalkiln2 = document.getElementById('ddlEntryTimeThermal2');
    dropdowntheramalkiln3 = document.getElementById('ddlEntryTimeThermal3');
    dropdowntheramalkiln4 = document.getElementById('ddlEntryTimeThermal4');
    dropdowntheramalkiln5 = document.getElementById('ddlEntryTimeThermal5');
    dropdowntheramalkiln6 = document.getElementById('ddlEntryTimeThermal6');
    GetThermalGraphData(1, dropdowntheramalkiln1.value);
    GetThermalGraphData(2, dropdowntheramalkiln2.value);
    GetThermalGraphData(3, dropdowntheramalkiln3.value);
    GetThermalGraphData(4, dropdowntheramalkiln4.value);
    GetThermalGraphData(5, dropdowntheramalkiln5.value);
    GetThermalGraphData(6, dropdowntheramalkiln6.value);
}

document.getElementById("ddlEntryTimeThermal1").addEventListener("change", function ()
{
    //alert("hi");
    var selectedValue = this.value; // get the selected value
    KilnNo="1"
    GetThermalGraphData(KilnNo, selectedValue);
}
);
document.getElementById("ddlEntryTimeThermal2").addEventListener("change", function () {
    var selectedValue = this.value; // get the selected value
    KilnNo = "2"
    GetThermalGraphData(KilnNo, selectedValue);
}
);
document.getElementById("ddlEntryTimeThermal3").addEventListener("change", function () {
    var selectedValue = this.value; // get the selected value
    KilnNo = "3"
    GetThermalGraphData(KilnNo, selectedValue);
}
);
document.getElementById("ddlEntryTimeThermal4").addEventListener("change", function () {
    var selectedValue = this.value; // get the selected value
    KilnNo = "4"
    GetThermalGraphData(KilnNo, selectedValue);
}
);
document.getElementById("ddlEntryTimeThermal5").addEventListener("change", function () {
    var selectedValue = this.value; // get the selected value
    KilnNo = "5"
  GetThermalGraphData(KilnNo, selectedValue);
}
);
document.getElementById("ddlEntryTimeThermal6").addEventListener("change", function () {
    var selectedValue = this.value; // get the selected value
    KilnNo = "6"
   GetThermalGraphData(KilnNo, selectedValue);
}
);
function fillddlShowDateThermal(kiln)
{
    debugger;
    //alert(kiln);
    $.ajax({
        type: "POST",
        url: "ThermalService.asmx/FillddlDateThermal",
        data: "{'KILN':'" + kiln + "'}",
        contentType: "application/json; charset=utf-8",
        async: false,
        dataType: "json",
        beforeSend: function () {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function () {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response) {

            debugger;
            if (response.d == null || response.d == "") {
                $("#ddlEntryTimeThermal")[0].innerHTML = "";
                alert("No dates fetched for Entry Time.");
            }
            else {

                console.log(response.d);
                debugger;
                //var ddlData = response.d;
                //$("#ddlEntryTimeThermal")[0].innerHTML = "";
                //$.each(ddlData, function () {
                //    $("#ddlEntryTimeThermal").append('<option value="' + this + '">' + this + '</option>');
                //});
                // return true;

                var filteredDatakiln1 = [];
                var filteredDatakiln2 = [];
                var filteredDatakiln3 = [];
                var filteredDatakiln4 = [];
                var filteredDatakiln5 = [];
                var filteredDatakiln6 = [];
                $.each(response.d, function (index, item)
                {  debugger
                    if (item.ID_KILN === '1')
                    {   // replace WITH THE DESIRED ID_KILN VALUE
                        filteredDatakiln1.push(item.DATE);
                    }

                    if (item.ID_KILN === '2')
                    { // replace WITH THE DESIRED ID_KILN VALUE
                        filteredDatakiln2.push(item.DATE);
                    }
                    if (item.ID_KILN === '3')
                    { // replace WITH THE DESIRED ID_KILN VALUE
                        filteredDatakiln3.push(item.DATE);
                    }
                    if (item.ID_KILN === '4')
                    { // replace WITH THE DESIRED ID_KILN VALUE
                        filteredDatakiln4.push(item.DATE);
                    }
                    if (item.ID_KILN === '5')
                    {  // replace WITH THE DESIRED ID_KILN VALUE
                        filteredDatakiln5.push(item.DATE);

                    }
                    if (item.ID_KILN === '6')
                    {  // replace WITH THE DESIRED ID_KILN VALUE
                        filteredDatakiln6.push(item.DATE);
                    }
                });
                console.log(filteredDatakiln5);

                $("#ddlEntryTimeThermal1")[0].innerHTML = "";
                $("#ddlEntryTimeThermal2")[0].innerHTML = "";
                $("#ddlEntryTimeThermal3")[0].innerHTML = "";
                $("#ddlEntryTimeThermal4")[0].innerHTML = "";
                $("#ddlEntryTimeThermal5")[0].innerHTML = "";
                $("#ddlEntryTimeThermal6")[0].innerHTML = "";
                $.each(filteredDatakiln1, function () {
                    $("#ddlEntryTimeThermal1").append("<option value='" + this + "'>" + this + "</option>");
                });
                $.each(filteredDatakiln2, function () {
                    $("#ddlEntryTimeThermal2").append("<option value='" + this + "'>" + this + "</option>");
                });
                $.each(filteredDatakiln3, function () {
                    $("#ddlEntryTimeThermal3").append("<option value='" + this + "'>" + this + "</option>");
                });
                $.each(filteredDatakiln4, function () {
                    $("#ddlEntryTimeThermal4").append("<option value='" + this + "'>" + this + "</option>");
                });
                $.each(filteredDatakiln5, function () {
                    $("#ddlEntryTimeThermal5").append("<option value='" + this + "'>" + this + "</option>");
                });
                $.each(filteredDatakiln6, function ()
                {
                    $("#ddlEntryTimeThermal6").append("<option value='" + this + "'>" + this + "</option>");
                });

                






            }
        }
    });
}
function GetThermalGraphData(kilnNo,selectedvalue)
{

    debugger;


   
   
   
    $.ajax({
        type: "POST",
        url: "ThermalService.asmx/GetThermalScannerData",
        data: "{'Date':'" + selectedvalue + "','KILN':'" + kilnNo + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        beforeSend: function ()
        {
            x = document.getElementById("loading-image");
            x.style.display = "block";
        },
        complete: function ()
        {
            // Hide image container
            x = document.getElementById("loading-image");
            x.style.display = "none";
        },
        success: function (response)
        {
            debugger;
            if (response.d == null || response.d == "") {
               //alert("Error in loading.");
            }
            else
            {
                console.log(response.d);
                PlotGraphThermal(response.d, kilnNo);
            }

        }
    });
}



function PlotGraphThermal(lsttTHERMALs,kilnno)
{
     datalist = lsttTHERMALs[0];
     const values = [];
     for (let entry in datalist)
     {
        if (entry >= 'Z1' && entry <= 'Z9')
        {
            const numValue = parseFloat(datalist[entry]);
            values.push(numValue);
        }
     }
    
    var options =
    {
    series: [{
        name: "Temprature",
        data: values
    }],
    chart: {
        height: 350,
        type: 'line',
        zoom: {
            enabled: false
        }
    },
    dataLabels: {
        enabled: false
    },
    stroke: {
        curve: 'straight'
    },
    title: {
        text: 'Temprature By Zone',
        align: 'left'
    },
    grid: {
        row: {
            colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
            opacity: 0.5
        },
    },
    xaxis: {
        categories: ["Z1", "Z2", "Z3", "Z4", "Z5", "Z6", "Z7", "Z8", "Z9"],
        title: {
            text: "Zone",
        },
    },
    yaxis: {
        title: {
            text: "Temperature (°C)",
        },
    },
};
   
    if (kilnno == "1")
    {
        $("#chartContainerThermalParameter1").empty();
        var chart = new ApexCharts(document.querySelector("#chartContainerThermalParameter1"), options);
    }
    if (kilnno == "2")
    {
        $("#chartContainerThermalParameter2").empty();
        var chart = new ApexCharts(document.querySelector("#chartContainerThermalParameter2"), options);
    }
    if (kilnno == "3")
    {
        $("#chartContainerThermalParameter3").empty();
        var chart = new ApexCharts(document.querySelector("#chartContainerThermalParameter3"), options);
    }
    if (kilnno == "4")
    { 
        $("#chartContainerThermalParameter4").empty();
        var chart = new ApexCharts(document.querySelector("#chartContainerThermalParameter4"), options);
    }
    if (kilnno == "5")
    {
        $("#chartContainerThermalParameter5").empty();
        var chart = new ApexCharts(document.querySelector("#chartContainerThermalParameter5"), options);
    }
    if (kilnno == "6")
    {
        $("#chartContainerThermalParameter6").empty();
        var chart = new ApexCharts(document.querySelector("#chartContainerThermalParameter6"), options);
    }
  chart.render();
    








}
   



   



function downLoadLogBook() {
    $today1 = new Date();

    var data1 = document.getElementById('tblLogBook');
    var fp = XLSX.utils.table_to_book(data1, { sheet: "sheet1" });
    XLSX.write(fp, { bookType: 'xlsx', type: 'base64' });
    XLSX.writeFile(fp, 'LogBook_' + KilnNo + '_' + $today1.getDate() + '_' + ($today1.getMonth() + 1) + '_' + $today1.getFullYear() + '_' + $today1.getHours() + '_' + $today1.getMinutes() + '.xlsx');

}
function downLoadFeedBook() {

   // alert("hi");
    $today1 = new Date();

    var data1 = document.getElementById('tblFeedBook');
    var fp = XLSX.utils.table_to_book(data1, { sheet: "sheet1" });
    XLSX.write(fp, { bookType: 'xlsx', type: 'base64' });
    XLSX.writeFile(fp, 'FeedBook_' + KilnNo + '_' + $today1.getDate() + '_' + ($today1.getMonth() + 1) + '_' + $today1.getFullYear() + '_' + $today1.getHours() + '_' + $today1.getMinutes() + '.xlsx');

}


function downLoadOperationBook() {

    // alert("hi");
    $today1 = new Date();

    var data1 = document.getElementById('tble_Ebook_list');
    var fp = XLSX.utils.table_to_book(data1, { sheet: "sheet1" });
    XLSX.write(fp, { bookType: 'xlsx', type: 'base64' });
    XLSX.writeFile(fp, 'OperationEBook_' + KilnNo + '_' + $today1.getDate() + '_' + ($today1.getMonth() + 1) + '_' + $today1.getFullYear() + '_' + $today1.getHours() + '_' + $today1.getMinutes() + '.xlsx');

}
// SideBarModule

function GetSidebarData(response) {
    // var jsonarr = parse.JSON(response);

    // alert(jsonarr[0]);

    //console.log(response);

    const urlParams = new URLSearchParams(window.location.search);
    const tabParam = urlParams.get("tab");
    const navigationType = performance.getEntriesByType('navigation')[0].type;
    var i = 0;
    var j = 0;
    var dropid = 0;


    var layout1 = "<div class='sidenav'>";
    for (i; i < response.length; i++) {
        j = 0;


        if (response[i].FormDetails === null) {


            console.log(response[i].MODULE_NAME);


            if (response[i].MODULE_NAME === 'QUALITY MODEL')
            {

                layout1 = layout1 + "<button class='dropdown-btn sidebarButton active' id='" + response[i].MODULE_URL + "-tab" + "' data-bs-toggle='pill' data-bs-target='" + "#" + response[i].MODULE_URL + "' type='button' role='tab' aria-controls='" + response[i].MODULE_URL + "' aria-selected='false'><small>" + response[i].MODULE_NAME + "</small></button>";
               
                //getControlPara(KilnNo);

            }
            //if (response[i].MODULE_NAME === 'QUALITY MODEL' && tabParam == "Quality" && navigationType != "reload") {

            //    layout1 = layout1 + "<button class='dropdown-btn sidebarButton active' id='" + response[i].MODULE_URL + "-tab" + "' data-bs-toggle='pill' data-bs-target='" + "#" + response[i].MODULE_URL + "' type='button' role='tab' aria-controls='" + response[i].MODULE_URL + "' aria-selected='false'><small>" + response[i].MODULE_NAME + "</small></button>";
            //    alert("2");

            //}
            //if (response[i].MODULE_NAME != 'QUALITY MODEL' && tabParam != "Quality" && navigationType == "reload") {

            //    layout1 = layout1 + "<button class='dropdown-btn sidebarButton active' id='" + response[i].MODULE_URL + "-tab" + "' data-bs-toggle='pill' data-bs-target='" + "#" + response[i].MODULE_URL + "' type='button' role='tab' aria-controls='" + response[i].MODULE_URL + "' aria-selected='false'><small>" + response[i].MODULE_NAME + "</small></button>";
            //    alert("3");
            //}
            else
            {
                var modulelevel = response[i].MODULE_LEVEL;

                layout1 = layout1 + "<button  class='dropdown-btn sidebarButton' onclick='fun1(" + modulelevel + ")'  data-bs-target='" + "#" + response[i].MODULE_URL + "' id='" + response[i].MODULE_URL + "-tab" + "' data-bs-toggle='pill'  type='button' role='tab' aria-controls='" + response[i].MODULE_URL + "' aria-selected='false'><small>" + response[i].MODULE_NAME + "</small></button>";
            }
        }
        else {
            console.log(response[i].MODULE_NAME);

            layout1 =
                layout1 + "<Dropdown class='dropdown-btn sidebarButton' onclick='toggleDropdown(" + dropid + ")'" +
                " > <small> " + response[i].MODULE_NAME + "</small><i class='fa fa-angle-down myfa'></i></Dropdown>" +
                "<div class='dropdown-container' id='dropdown" + dropid + "'>";
            for (j; j < response[i].FormDetails.length; j++) {

                var frmlevel = response[i].FormDetails[j].FORM_LEVEL;
                layout1 = layout1 + "<button  class='dropdown-btn sidebarButtonh'  onclick='fun1(" + frmlevel + ")'  id='" + response[i].FormDetails[j].FORM_URL + "-tab" + "' data-bs-toggle='pill' data-bs-target='" + "#" + response[i].FormDetails[j].FORM_URL + "' type='button' role='tab' aria-controls='" + response[i].FormDetails[j].FORM_URL + "' aria-selected='false'><small>" + response[i].FormDetails[j].FORM_NAME + "</small></button>";








            }
            layout1 = layout1 + "</div>";
            dropid++;

        }


        layout1 = layout1 + "</div>";
        document.getElementById('ContainerdynamicSidebar').innerHTML = layout1;


    }




}





    

    









    function downLoad() {
        //if(KilnNo==1)
        var selectedValue = document.getElementById('idSelect').value;
        //else if(KilnNo==2)
        //    var selectedValue=document.getElementById('idSelect2').value;
        //     else if(KilnNo==3)
        //         var selectedValue=document.getElementById('idSelect3').value;
        $today1 = new Date();
        //if(KilnNo==1)
        var data1 = document.getElementById('idProcessParameter');
        //else if(KilnNo==2)
        //    var data1 = document.getElementById('idProcessParameter2');

        //else if(KilnNo==3)
        //    var data1 = document.getElementById('idProcessParameter3');
        //debugger;
        var fp = XLSX.utils.table_to_book(data1, { sheet: "sheet1" });
        XLSX.write(fp, { bookType: 'xlsx', type: 'base64' });
        if (selectedValue == 'pr_Para')
            XLSX.writeFile(fp, 'Process_Parameter' + $today1.getDate() + '_' + ($today1.getMonth() + 1) + '_' + $today1.getFullYear() + '_' + $today1.getHours() + '_' + $today1.getMinutes() + '.xlsx');
        else if (selectedValue == 'Mo_Out')
            XLSX.writeFile(fp, 'Model_Output' + $today1.getDate() + '_' + ($today1.getMonth() + 1) + '_' + $today1.getFullYear() + '_' + $today1.getHours() + '_' + $today1.getMinutes() + '.xlsx');

    }

    function openModal(id) {
        debugger;
        document.getElementById('graphModal').style.display = "block";
        graphModal = 1;
        if (id == 1)
            //FeMvsTimeGraph(graphdata_1, KilnNo);
            drawPlotlyFemVsTime(graphdata_1, KilnNo);
        if (id == 2)
            // FeMvsTimeGraph(graphdata_2, KilnNo);
            drawPlotlyFemVsTime(graphdata_2, KilnNo);
        if (id == 3)
            // FeMvsTimeGraph(graphdata_3, KilnNo);
            drawPlotlyFemVsTime(graphdata_3, KilnNo);
        if (id == 4)
            drawGraphFemVsLength(FemData_1, KilnNo);
        if (id == 5)
            drawGraphFemVsLength(FemData_2, KilnNo);
        if (id == 6)
            drawGraphFemVsLength(FemData_3, KilnNo);

        if (id == 7)
            drawGraphBedHeightVsLength(BHData_1, KilnNo);
        if (id == 8)
            drawGraphBedHeightVsLength(BHData_2, KilnNo);
        if (id == 9)
            drawGraphBedHeightVsLength(BHData_3, KilnNo);
        if (id == 10)
            drawGraphPressure(graphdata_Pressure_1, KilnNo);
        if (id == 11)
            drawGraphPressure(graphdata_Pressure_2, KilnNo);
        if (id == 12)
            drawGraphPressure(graphdata_Pressure_3, KilnNo);

        if (id == 13 || id == 14 || id == 15)
            acc2DProfileGraph(acc2DProfileData, KilnNo);
        if (id == 16 || id == 17 || id == 18)
            draw_3D_Graph1(ThreeD_Data, KilnNo);
        if (id == 19 || id == 20 || id == 21) {
            TC = document.getElementById(KilnNo).value;
            tcTrendGraph(tcTrendData, TC, KilnNo)
        }
        if (id == 22 || id == 23 || id == 24)
            acc2DVolumeGraph(acc2DVolData, KilnNo)

    }

    function modalClose() {
        document.getElementById('graphModal').style.display = "none";
        graphModal = 0;
    }








    //=========================ACCRETION 3D GRAPHS ===============================\\
    //function  get_3D_Data(kilnNo)
    //{
    //    $.ajax({
    //        type: "POST",
    //        url: "DRIService.asmx/get_3D_data",
    //        //data:"{'KILN':'" +kilnNo +"'}",
    //        contentType: "application/json; charset=utf-8",
    //        dataType: "json",
    //        success: function (response) {
    //            ////debugger;
    //            ThreeD_Data = response.d;
    //            draw_3D_Graph(ThreeD_Data,kilnNo);
    //        },
    //        error: function (jqxhr) {
    //            alert(jqxhr.responseText);
    //        },
    //    });

    //}
    //function draw_3D_Graph(ThreeD_Data,kilnNo){

    //    var chartContainer;
    //    var wdt;
    //    if(  graphModal==1)
    //    {
    //        chartContainer="chartContainer";
    //        wdt=1000;
    //    }
    //    else
    //    {
    //        wdt=500;
    //        if (kilnNo == 1)
    //            chartContainer="chartContainer3D";
    //        else if (kilnNo == 2)
    //            chartContainer = "chartContainer3D_2";
    //        else if (kilnNo == 3)
    //            chartContainer = "chartContainer3D_3";
    //    }
    //    debugger;

    //    var z1 = new Array(ThreeD_Data.length);

    //    for(var row=0;row<ThreeD_Data.length;row++)
    //    {
    //        var dataList=ThreeD_Data[row];
    //        z1[row] = new Array(dataList.length);
    //        for(var col=0;col<dataList.length;col++)
    //        {
    //            z1[row][col] = (dataList[col]);
    //        }
    //        var x1 = []; var y1 = [];
    //        for (var i = 0; i < 348; i++)
    //            x1.push(48 / 348 * i);

    //        for (var i = 0; i < 90; i++)
    //            y1.push(13.36 / 90 * i);

    //    }

    //    //var length = ThreeD_Data.length;
    //    //var width = ThreeD_Data[0].length;
    //    //var z1 = new Array(width);


    //    //for (var row = 0; row < width; row++)
    //    //z1[row] = new Array(length);

    //    //for (var row = 0; row < width; row++)
    //    //{
    //    //    //var dataList=ThreeD_Data[row];

    //    //    for(var col=0;col<length;col++)
    //    //    {
    //    //        z1[row][col] = ThreeD_Data[col][row];
    //    //    }

    //    //}

    //    debugger;

    //    var data_z1 = {x:x1,y:y1,z: z1,
    //        zmin: 0,
    //        zmax: 200,
    //        colorscale: [[0, 'rgb(0,0,255)'], [0.5, 'rgb(0,255,255)'], [0.5, 'rgb(255,255,0)'], [1, 'rgb(255,0,0)']],


    //        type: 'surface'};

    //    var layout = {
    //        scene: {

    //            aspectmode:"manual",
    //            aspectratio: {
    //                x:1,y:0.5,z:0.5

    //            },
    //            xaxis:{
    //                title:'KILN LENGTH (m)'
    //            },
    //            yaxis:{
    //                title:'CIRCUMFERENCE (m)'
    //            },
    //            zaxis:{
    //                title:'ACCRETION THICKNESS (mm)'
    //            },
    //        },

    //        autosize: false,
    //        width:wdt,
    //        height: 600,
    //        margin: {
    //            l:0,
    //            r: 0,
    //            b: 0,
    //            t: 0,
    //        },
    //        padding: {
    //            l: 0,
    //            r: 0,
    //            b: 0,
    //            t: 0,

    //        },

    //    };

    //    Plotly.newPlot(chartContainer, [data_z1],layout);
    //}
    //function draw_3D_Graph1(ThreeD_Data,kilnNo){

    //    var chartContainer;
    //    var wdt;
    //    if(  graphModal==1)
    //    {
    //        chartContainer="chartContainer";
    //        //  wdt=1000;
    //    }
    //    else
    //    {
    //        wdt=500;
    //        if (kilnNo == 1)
    //            chartContainer="chartContainer3D";
    //        else if (kilnNo == 2)
    //            chartContainer = "chartContainer3D_2";
    //    }
    //    debugger;

    //    var z1 = new Array(ThreeD_Data.length);

    //    for(var row=0;row<ThreeD_Data.length;row++)
    //    {
    //        var dataList=ThreeD_Data[row];
    //        z1[row] = new Array(dataList.length);
    //        for(var col=0;col<dataList.length;col++)
    //        {
    //            z1[row][col] = (dataList[col]);
    //        }
    //        var x1 = []; var y1 = [];
    //        for (var i = 0; i < 348; i++)
    //            x1.push(48 / 348 * i);

    //        for (var i = 0; i < 90; i++)
    //            y1.push(13.36 / 90 * i);

    //    }

    //    //var length = ThreeD_Data.length;
    //    //var width = ThreeD_Data[0].length;
    //    //var z1 = new Array(width);


    //    //for (var row = 0; row < width; row++)
    //    //z1[row] = new Array(length);

    //    //for (var row = 0; row < width; row++)
    //    //{
    //    //    //var dataList=ThreeD_Data[row];

    //    //    for(var col=0;col<length;col++)
    //    //    {
    //    //        z1[row][col] = ThreeD_Data[col][row];
    //    //    }

    //    //}

    //    debugger;


    //    var data_z1 = {x:x1,y:y1,z: z1,
    //        zmin: 0,
    //        zmax: 200,
    //        colorscale: [[0, 'rgb(0,0,255)'], [0.5, 'rgb(0,255,255)'], [0.5, 'rgb(255,255,0)'], [1, 'rgb(255,0,0)']],


    //        type: 'surface'};
    //    var layout = {
    //        scene: {

    //            aspectmode:"manual",
    //            aspectratio: {
    //                x:1,y:0.5,z:0.5

    //            },
    //            xaxis:{
    //                title:'KILN LENGTH (m)'
    //            },
    //            yaxis:{
    //                title:'CIRCUMFERENCE (m)'
    //            },
    //            zaxis:{
    //                title:'ACCRETION THICKNESS (mm)'
    //            },
    //        },

    //        autosize: false,
    //        width:1200,
    //        height: 600,
    //        margin: {
    //            l: 0,
    //            r: 0,
    //            b: 0,
    //            t: 0,
    //        },
    //        padding: {
    //            l: 0,
    //            r: 0,
    //            b: 0,
    //            t: 0,

    //        },
    //        xaxis: {
    //            // range:[0,48] //14
    //            //    autotick: false,
    //            //    ticks: 'outside',
    //            //    tick0: 0,
    //            //    dtick: 0.13,
    //            //    ticklen: 48,
    //            //    tickwidth: 4,
    //        },
    //        yaxis: {
    //            //range: [0, 13] //4
    //            //autotick: false,
    //            //ticks: 'outside',
    //            //tick0: 0,
    //            //dtick: 0.13,
    //            //ticklen: 13.36,
    //            //tickwidth: 4,
    //        }
    //    };

    //    Plotly.newPlot(chartContainer, [data_z1],layout);



    //}

// SideBarModule
